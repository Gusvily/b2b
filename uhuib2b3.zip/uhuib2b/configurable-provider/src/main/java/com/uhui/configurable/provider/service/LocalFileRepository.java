package com.uhui.configurable.provider.service;

import com.google.common.io.Files;
import com.uhui.configurable.api.service.FileRepository;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.MultivaluedMap;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Created by Fidel on 2017/4/20.
 */
@Service
public class LocalFileRepository implements FileRepository {

    public static final String TEMPORARY_DIR = "temp" + File.separator;
    private static final Logger LOGGER = Logger.getLogger(LocalFileRepository.class);
    @Autowired
    @Qualifier("uploadFileRoot")
    private File uploadFileRoot;

    @Override
    public String store(String type, String[] subTypes, MultipartFormDataInput input, String field, String fileName) {
        Map<String, List<InputPart>> uploadForm = input.getFormDataMap();
        try {
            InputPart inputPart = uploadForm.get(field).get(0);
            //convert the uploaded file to inputstream
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            byte[] bytes = IOUtils.toByteArray(inputStream);
            String randomFileName = createFileName();
            String ext = Files.getFileExtension(fileName);
            String randomFileNameWithExtension = randomFileName + "." + ext;
            StringBuffer subPath = new StringBuffer();
            if (null != subTypes && subTypes.length != 0) {
                for (String s : subTypes) {
                    subPath.append(s).append(File.separator);
                }
            }
            String filePath = TEMPORARY_DIR + type + File.separator + subPath.toString() + createPathBasedData() + File.separator + randomFileNameWithExtension;
            File saveFile = new File(this.uploadFileRoot, filePath);
            FileUtils.writeByteArrayToFile(saveFile, bytes);
            return saveFile.getAbsolutePath().replace(uploadFileRoot.getAbsolutePath() + File.separator, "");
        } catch (IOException e) {
            LOGGER.error("Store local file failed. File name: " + fileName, e);
            return null;
        }
    }

    public String confirm(String realFilePath) {
        File realFile = new File(this.uploadFileRoot, realFilePath);
        if (!realFile.exists()) {
            BusinessException.throwBusinessException(BusinessExceptionType.RESOURCE,
                    "File is not exist in local file repository, file path: " + realFilePath);
        }
        String confirmedPath = realFilePath.replace(TEMPORARY_DIR, "");
        File confirmedFile = new File(this.uploadFileRoot, confirmedPath);
        try {
            FileUtils.moveFile(realFile, confirmedFile);
        } catch (IOException e) {
            LOGGER.error("Confirm local file failed. File name: " + realFilePath, e);
            BusinessException.throwBusinessException(BusinessExceptionType.RESOURCE,
                    "File is not exist in local file repository, file path: " + realFilePath);
        }
        return confirmedPath;
    }

    private String createFileName() {
        DateFormat dateFormat = new SimpleDateFormat("HH-mm-ss");
        Random random = new Random();
        return dateFormat.format(new Date()) + random.nextLong();
    }


    private String createPathBasedData() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        return dateFormat.format(new Date());
    }


    private String getRealFileName(MultivaluedMap<String, String> header) {
        String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
        for (String filename : contentDisposition) {
            if ((filename.trim().startsWith("filename"))) {
                String[] name = filename.split("=");
                String finalFileName = name[1].trim().replaceAll("\"", "");
                return finalFileName;
            }
        }
        return "unknown";
    }

}
