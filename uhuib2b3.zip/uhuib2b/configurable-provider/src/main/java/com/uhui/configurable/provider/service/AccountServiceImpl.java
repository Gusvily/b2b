package com.uhui.configurable.provider.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.uhui.configurable.api.Permission.cache.Cache;
import com.uhui.configurable.api.Permission.cache.CacheConstant;
import com.uhui.configurable.api.Permission.cache.CacheManager;
import com.uhui.configurable.api.Permission.exception.AuthenticationFailedException;
import com.uhui.configurable.api.Permission.exception.LockedAccountException;
import com.uhui.configurable.api.Permission.exception.PasswordNotMatchException;
import com.uhui.configurable.api.Permission.exception.PasswordRetryLimitExceedException;
import com.uhui.configurable.api.Permission.exception.PermissionException;
import com.uhui.configurable.api.Permission.exception.UnknownAccountException;
import com.uhui.configurable.api.facade.AccountService;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.service.DBRepository;
import com.uhui.configurable.api.service.RedisService;
import com.uhui.configurable.api.workflow.ProcessingResult;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/5/8.
 */
@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private PermissionProvider permissionProvider;
    @Autowired
    private RedisService redisService;
    @Autowired
    private MessageService messageService;
    @Autowired
    private DBRepository dbRepository;
    @Autowired
    private CacheManager cacheManager;

    @Override
    public ProcessingResult requestSecurityCode(String mobilePhoneNumber) {
        String securityCode = permissionProvider.generateSecurityCode();
        redisService.setex("SECURITY_CODE_" + mobilePhoneNumber, 600, securityCode);
        messageService.sendSmsSecurityCode(mobilePhoneNumber, securityCode);
        return ProcessingResult.succeeded();
    }

    @Override
    public ProcessingResult login(Map<String, Object> params) {
        ProcessingResult result = null;
        try {
            String username = (String) params.get("username");
            String password = (String) params.get("password");
            User user = dologin(username, password);
            Cache cache = cacheManager.getCache(CacheConstant.USER_CACHE_PREFIX_KEY + user.getId());
            cache.put(CacheConstant.CACHE_CURRENT_USER_KEY, user);
            List<String> permissions = doLoadPermission(user.getId());
            cache.put(CacheConstant.CACHE_CURRENT_USER_PERMISSIONS_KEY, permissions);
            result = ProcessingResult.succeeded(user);
//            result = ProcessingResult.succeeded("User login successful.");
        } catch (Throwable t) {
            result = ProcessingResult.failed(String.format(
                    "User login failed. %s %s", System.getProperty("line.separator"), ExceptionUtils.getStackTrace(t)));
        }
        return result;
    }

    @Override
    public ProcessingResult logout(String mobilePhoneNumber) {
        //TODO
        return ProcessingResult.succeeded("User logout successful.");
    }


    private List<String> doLoadPermission(Long userId) {
        List<String> result = new ArrayList();
        String sql = "select " +
                "concat(p.module,':',p.action,':',p.operation,':',p.operation_details) as permission " +
                "from user as u " +
                "inner join user_role ur on u.id = ur.user_id " +
                "inner join role r on ur.role_id = r.id " +
                "inner join role_privilege rp on r.id = rp.role_id " +
                "inner join privilege p on rp.privilege_id = p.id " +
                "where u.logic_deleted = 0 " +
                "and ur.logic_deleted = 0 " +
                "and r.logic_deleted = 0 " +
                "and rp.logic_deleted = 0 " +
                "and p.logic_deleted = 0 " +
                "and u.id = " + userId;
        List<Map<String, Object>> queryRes = dbRepository.executeQuery(sql);
        for (Map<String, Object> row : queryRes) {
            result.add((String) row.get("permission"));
        }
        return result;
    }

    private User dologin(String username, String password) throws PermissionException {
        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
            throw new UnknownAccountException();
        }
        //密码如果不在指定范围内 肯定错误
        if (password.length() < User.PASSWORD_MIN_LENGTH || password.length() > User.PASSWORD_MAX_LENGTH) {
            throw new PasswordNotMatchException();
        }

        User user = getUserByName(username);

        if (user == null) {
            user = getUserByEmail(username);
        }

        if (user == null) {
            user = getUserByMobilePhoneNumber(username);
        }

        if (user == null || Boolean.TRUE.equals(user.getLogicDeleted())) {
            throw new UnknownAccountException();
        }

        validate(user, password);

        if (User.USER_STATUS_INACTIVE.equals(user.getStatus())) {
            throw new LockedAccountException();
        }

        if (User.USER_STATUS_FROZEN.equals(user.getStatus())) {
            throw new LockedAccountException();
        }
        return user;
    }

    private User getUserByName(String username) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`name` = '%s'", username)));
    }

    private User getUserByEmail(String email) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`email` = '%s'", email)));
    }

    private User getUserByMobilePhoneNumber(String mobilePhoneNumber) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`mobile_phone` = '%s'", mobilePhoneNumber)));
    }

    private void validate(User user, String password) throws AuthenticationFailedException {
        String username = user.getName();

        int retryCount = 0;


        Cache loginRecordCache = cacheManager.getCache(CacheConstant.PASSWORD_RETRY_CACHE_KEY);

        Object cacheRetryCount = loginRecordCache.get(username);
        if (cacheRetryCount != null) {
            retryCount = (Integer) cacheRetryCount;
            if (retryCount >= User.MAX_RETRY_COUNT) {
                throw new PasswordRetryLimitExceedException(User.MAX_RETRY_COUNT);
            }
        }

        if (!user.validatePassword(password)) {
            loginRecordCache.put(username, ++retryCount);
            throw new PasswordNotMatchException();
        } else {
            loginRecordCache.remove(username);
        }
    }

}
