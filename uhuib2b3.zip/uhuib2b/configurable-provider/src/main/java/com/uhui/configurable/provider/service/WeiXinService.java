package com.uhui.configurable.provider.service;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.model.external.WeiXinSignature;
import com.uhui.configurable.api.service.RedisService;
import com.uhui.configurable.provider.utils.HttpsClientUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.UUID;

/**
 * Created by Fidel on 2017/3/14.
 */
@Service
public class WeiXinService implements ApplicationListener<ContextRefreshedEvent> {
    public static final String WEIXIN_APP_ID = "wx04b8ac532c58b63d";
    public static final String WEIXIN_APP_SECRET = "67b75c50f926ed940c51ab9e63a6d67a";
    public static final String WEIXIN_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + WEIXIN_APP_ID + "&secret=" + WEIXIN_APP_SECRET;
    public static final String WEIXIN_JSAPI_TICKET_URL_PREFIX = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=";
    public static final String WEIXIN_JSAPI_TICKET_URL_SUFFIX = "&type=jsapi";

    public static final String CHARSET_UTF_8 = "UTF-8";
    public static final String ACCESS_TOKEN_RESULT_KEY = "access_token";
    public static final String JSAPI_TICKET_RESULT_KEY = "ticket";
    public static final String WEIXIN_ACCESS_TOKEN_REDIS_KEY = "weixin_access_token";
    public static final String WEIXIN_JSAPI_TICKET_REDIS_KEY = "weixin_jsapi_ticket";
    public static final int WEIXIN_REQUEST_RETRY_TIMES = 3;

    @Autowired
    private RedisService redisService;


    public void updateWeixinAccessTokenAndJsapiTicket() {
        boolean redisInvokeSuccessful = false;
        int retryTimes = 0;
        while (!redisInvokeSuccessful) {
            retryTimes = retryTimes + 1;
            if (retryTimes > WEIXIN_REQUEST_RETRY_TIMES) {
                //TODO
                //在此需要发消息通知到运维人员，由人工干预
            }
            if (retryTimes > 1) {
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                }
            }
            String accessToken = requestWeixinAccessToken();
            try {
                if (StringUtils.isNotEmpty(accessToken)) {
                    String jsapiTicket = requestWeixinJsapiTicket(accessToken);
                    if (StringUtils.isNotEmpty(jsapiTicket)) {
                        redisService.set(WEIXIN_ACCESS_TOKEN_REDIS_KEY, accessToken);
                        redisService.set(WEIXIN_JSAPI_TICKET_REDIS_KEY, jsapiTicket);
                        redisInvokeSuccessful = true;
                    }
                }
            } catch (Exception e) {
                redisInvokeSuccessful = false;
            }
        }
    }

    public String requestWeixinAccessToken() {
        try {
            HttpsClientUtil clientUtil = new HttpsClientUtil();
            String token_result = clientUtil.doGet(WEIXIN_ACCESS_TOKEN_URL, CHARSET_UTF_8);
            JSONObject json = JSON.parseObject(token_result);
            return json.getString(ACCESS_TOKEN_RESULT_KEY);
        } catch (Exception e) {
            return null;
        }
    }

    public String requestWeixinJsapiTicket(String accessToken) {
        try {
            HttpsClientUtil clientUtil = new HttpsClientUtil();
            String token_result = clientUtil.doGet(WEIXIN_JSAPI_TICKET_URL_PREFIX + accessToken + WEIXIN_JSAPI_TICKET_URL_SUFFIX, CHARSET_UTF_8);
            JSONObject json = JSON.parseObject(token_result);
            return json.getString(JSAPI_TICKET_RESULT_KEY);
        } catch (Exception e) {
            return null;
        }
    }

    public WeiXinSignature sign(String jsapiTicket, String url) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        String nonceStr = createNonceStr();
        String timestamp = createTimestamp();
        String string1;
        String signature = "";

        //注意这里参数名必须全部小写，且必须有序
        string1 = "jsapi_ticket=" + jsapiTicket +
                "&noncestr=" + nonceStr +
                "&timestamp=" + timestamp +
                "&url=" + url;
        System.out.println(string1);

        MessageDigest crypt = MessageDigest.getInstance("SHA-1");
        crypt.reset();
        crypt.update(string1.getBytes("UTF-8"));
        signature = byteToHex(crypt.digest());

        WeiXinSignature signatureResult = new WeiXinSignature();
        signatureResult.setUrl(url);
        signatureResult.setNonceStr(nonceStr);
        signatureResult.setTimestamp(timestamp);
        signatureResult.setSignature(signature);

        return signatureResult;
    }

    private String byteToHex(final byte[] hash) {
        Formatter formatter = new Formatter();
        for (byte b : hash) {
            formatter.format("%02x", b);
        }
        String result = formatter.toString();
        formatter.close();
        return result;
    }

    private String createNonceStr() {
        return UUID.randomUUID().toString();
    }

    private String createTimestamp() {
        return Long.toString(System.currentTimeMillis() / 1000);
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        updateWeixinAccessTokenAndJsapiTicket();
    }
}
