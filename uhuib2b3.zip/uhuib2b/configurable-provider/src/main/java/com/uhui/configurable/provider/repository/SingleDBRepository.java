package com.uhui.configurable.provider.repository;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.uhui.configurable.api.Permission.Permission;
import com.uhui.configurable.api.Permission.model.RoleModel;
import com.uhui.configurable.api.model.BaseModel;
import com.uhui.configurable.api.service.DBRepository;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import com.uhui.configurable.api.workflow.utils.BeanUtils;
import com.uhui.configurable.api.workflow.utils.Pagination;
import com.uhui.configurable.provider.repository.dao.CommonDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/27.
 */
@Repository
public class SingleDBRepository implements DBRepository {

    @Autowired
    private CommonDao commonDao;

    public <T extends BaseModel> T getById(Class<T> clz, Integer id) {
        return getById(clz, Long.parseLong(id.toString()));
    }

    public <T extends BaseModel> T getById(Class<T> clz, Integer id, boolean logicDeleted) {
        return getById(clz, Long.parseLong(id.toString()), false);
    }


    public <T extends BaseModel> T getById(Class<T> clz, Long id) {
        return getById(clz, id, false);
    }

    public <T extends BaseModel> T getById(Class<T> clz, Long id, boolean logicDeleted) {
        String table = null;
        try {
            table = clz.newInstance().getTable();
        } catch (Exception e) {
        }
        if (table == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Extract table failed from class " + clz.getName());
        }
        return new BeanUtils().mapToObject(commonDao.getById(table, id, logicDeleted), clz, BeanUtils.UNDERLINE);
    }

    public <T extends BaseModel> T getByOthers(Class<T> clz, List<String> where) {
        List<T> result = simpleQuery(clz, where);
        if (result == null) {
            return null;
        }
        int resultSize = result.size();
        switch (resultSize) {
            case 0:
                return null;
            case 1:
                return result.get(0);
            default:
                throw new BusinessException(BusinessExceptionType.LOGIC, "The result is not unique.");
        }
    }

    public Long create(BaseModel model) {
        return create(model.getTable(), model);
    }

    public Long create(String table, BaseModel model) {
        if (table == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Table must be not null.");
        }
        if (model == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Model must be not null.");
        }
        model.setCreateDate(new Date());
        model.setUpdateDate(null);
        Map<String, Object> modelMap = new BeanUtils().objectToMap(model, BeanUtils.UNDERLINE);
        commonDao.create(table, modelMap);
        Long id = Long.parseLong(modelMap.get("id").toString());
        model.setId(id);
        return id;
    }

    public int update(Long id, BaseModel model) {
        if (id == null || id < 1) {
            return 0;
        }
        if (model == null) {
            return 0;
        }
        if (model.getLogicDeleted() == null) {
            model.setLogicDeleted(false);
        }
        if (model.getLogicDeleted()) {
            return 0;
        }
        model.setId(null);
        model.setCreateDate(null);
        model.setUpdateDate(null);
        return commonDao.update(id, new BeanUtils().objectToMap(model, BeanUtils.UNDERLINE));
    }

    public int updateColumn(Long id, String tableName, String columnName, Object columnValue) {
        if (id == null || id <= 0 || StringUtils.isEmpty(tableName) || StringUtils.isEmpty(columnName)) {
            return 0;
        }
        if ("logic_deleted".equals(columnName)) {
            BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Sensitive column should not be update.");
        }
        return commonDao.updateColumn(id, tableName, columnName, columnValue, false);
    }

    public int delete(Long id, String tableName) {
        if (id == null || id <= 0 || StringUtils.isEmpty(tableName)) {
            return 0;
        }
        return commonDao.updateColumn(id, tableName, "logic_deleted", true, false);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select) {
        return simpleQuery(clz, select, null, null, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, Permission permission, RoleModel instance) {
        return simpleQuery(clz, select, null, null, permission, instance);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where) {
        return simpleQuery(clz, select, where, null, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, Permission permission, RoleModel instance) {
        return simpleQuery(clz, select, where, null, permission, instance);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, String[] orderBy) {
        return simpleQuery(clz, select, null, orderBy, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, String[] orderBy, Permission permission, RoleModel instance) {
        return simpleQuery(clz, select, null, orderBy, permission, instance);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where) {
        return simpleQuery(clz, null, where, null, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, Permission permission, RoleModel instance) {
        return simpleQuery(clz, null, where, null, permission, instance);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, String[] orderBy) {
        return simpleQuery(clz, null, where, orderBy, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, String[] orderBy, Permission permission, RoleModel instance) {
        return simpleQuery(clz, null, where, orderBy, permission, instance);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, String[] orderBy) {
        return simpleQuery(clz, null, where, orderBy, null, null);
    }

    public <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, String[] orderBy, Permission permission, RoleModel instance) {
        String table = null;
        try {
            BaseModel model = clz.newInstance();
            table = model.getTable();
            if (permission != null && instance != null) {
                String dataLevelCondition = model.doDataLevelControl(permission, instance);
                if (where == null) {
                    where = new ArrayList<>();
                }
                where.add(dataLevelCondition);
            }
        } catch (Exception e) {
        }
        if (table == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Extract table failed from class " + clz.getName());
        }
        where = handleWhere(where);
        List<Map<String, Object>> resultsMap = commonDao.simpleQuery(table, select, where, orderBy);
        List<T> resultsList = new ArrayList<>();
        BeanUtils beanuUtils = new BeanUtils();
        for (Map<String, Object> map : resultsMap) {
            resultsList.add(beanuUtils.mapToObject(map, clz, BeanUtils.UNDERLINE));
        }
        return resultsList;
    }

    private List<String> handleWhere(List<String> where) {
        String logicDeletedCondition = "`logic_deleted` = 0";
        if (where == null) {
            return Arrays.asList(logicDeletedCondition);
        }
        boolean needToAddLogicDeleted = true;
        for (String whereStr : where) {
            try {
                if (whereStr.contains("logic_deleted")) {
                    needToAddLogicDeleted = false;
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (needToAddLogicDeleted) {
            ArrayList<String> result = new ArrayList<>(where);
            result.add(logicDeletedCondition);
            return result;
        } else {
            return where;
        }
    }

    public <T> Pagination<T> query(Pagination<T> page, String table, String[] select, Map<String, String> leftJoin, List<String> where, String[] groupBy, String[] orderBy) {
        if (page.getCurrentPage() == null) {
            page.setCurrentPage(1);
        }
        if (page.getTotalCount() == null) {
            List<Map<String, Object>> countResult = commonDao.query(table, new String[]{"count(1) as count"}, leftJoin, where, groupBy, orderBy, null, null);
            Long totalCount = (Long) countResult.get(0).get("count");
            page.setTotalCount(totalCount);
            page.setTotalPage(Double.valueOf(Math.ceil(totalCount / (page.getPageSize() * 1.0))).intValue());
        }
        List<Map<String, Object>> resultsMap = commonDao.query(table, select, leftJoin, where, groupBy, orderBy, (page.getCurrentPage() - 1) * page.getPageSize(), page.getPageSize());
        BeanUtils beanuUtils = new BeanUtils();
        if (Map.class.isAssignableFrom(page.getClz())) {
            List<Map<String, Object>> resultsList = new ArrayList<>();
            for (Map<String, Object> map : resultsMap) {
                resultsList.add(beanuUtils.convertMap(map, BeanUtils.UNDERLINE));
            }
            page.setDatas((List<T>) resultsList);
        } else {
            List<T> resultsList = new ArrayList<>();
            for (Map<String, Object> map : resultsMap) {
                resultsList.add(beanuUtils.mapToObject(map, page.getClz(), BeanUtils.UNDERLINE));
            }
            page.setDatas(resultsList);
        }
        return page;
    }

    public List<Map<String, Object>> executeQuery(String sql) {
        return commonDao.executeQuery(sql);
    }

}
