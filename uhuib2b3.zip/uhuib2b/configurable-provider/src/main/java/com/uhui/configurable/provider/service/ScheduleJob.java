package com.uhui.configurable.provider.service;

/**
 * Created by Fidel on 2017/4/25.
 */
public class ScheduleJob {


}
