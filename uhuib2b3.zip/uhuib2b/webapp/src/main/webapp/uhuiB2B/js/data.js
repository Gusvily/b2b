/**
 * Created by Administrator on 2017/5/26.
 */
$(function () {
   var todayData = $('.todayData span');
   var yesterdayData = $('.yesterdayData span');
   var totalData = $('.totalData span');
    // var wwww = { name: "John", lang: "JS" };
    var arr = [];
    $.ajax({
        type: "GET",
        url : 'aaa' + '?callback=?',
        data:{B2Bdata:11},
        datatype:"json",
        success:function (json) {
            for (var i = 0; i<4; i++){
                $.each( json[i], function(i, n){
                    arr.push(n)
                });
                todayData[i].innerHTML = arr[i];
                yesterdayData[i].innerHTML = i;
                totalData[i].innerHTML = i;
            }
        },
        error:function () {

        }
    })
});