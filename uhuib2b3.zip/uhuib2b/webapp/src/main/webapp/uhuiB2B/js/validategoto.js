$(function () {
    //点击边框变红
    $('.content button').click(function () {
        $(this).parent().addClass("border");
        $(this).parent().siblings().removeClass("border");
    });
    $('.top,.bottom').click(function () {
        $(this).addClass("border");
        $(this).siblings().removeClass("border");
    });
    //邮箱找回跳转
    $('.top button').click(function () {
        window.location.href = 'forgetemail.html'
    });
    //手机号找回跳转
   $('.bottom button').click(function () {
       window.location.href = 'forgetphone.html'
   });

});