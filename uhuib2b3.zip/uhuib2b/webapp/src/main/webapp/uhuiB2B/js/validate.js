/**
 * Created by Administrator on 2017/6/5.
 */
    var fromValidator = {
        rules: {
            email: {
                required: true,
                email: true
            },
            phoneNumber:{
                required: true,
                isPhoneNumber:true
            },
            code: {
                required: true,
                isPhoneCode:true
            },
            cipher: {
                required: true,
                isPassword: true
            },
            oldPassword: {
                required: true,
                isPassword: true,
                minlength: 8,
                maxlength: 20
            },
            password: {
                required: true,
                minlength: 8,
                maxlength: 20,
                isPassword: true
            },
            rePassword: {
                required: true,
                minlength: 8,
                maxlength: 20,
                equalTo:'#password',
                isPassword: true
            }
        },
        errorElement: "span",
        errorPlacement: function (error, element) {
            element.parent().siblings('.validate-container').addClass('validate-error').removeClass('validate-ok');
            element.parent().addClass("has-feedback");

            if (!$(element).parent().siblings('.validate-container').find("span")[0]) {
                $(element).parent().siblings('.validate-container').append("<span class='glyphicon glyphicon-ok-sign'></span>&nbsp;&nbsp;");
            }

            if (element.prop("type") === "checkbox") {
                error.insertAfter(element.parent("label"));
            } else {
                $(element).parent().siblings('.validate-container').append(error);
            }
        },
        success: function (label, element) {
            $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
            if (!$(element).parent().next().find("span").eq(0)) {
                $(element).parent().next().append($("<span class='glyphicon glyphicon-ok-sign'></span>&nbsp;&nbsp;"));
            }
        },
        highlight: function (element, errorClass, validClass) {
            $(element).parent().addClass("has-error").removeClass("has-success");
            $(element).parent().siblings('.validate-container').addClass('validate-error').removeClass('validate-ok');
            if (element.parentElement.className.indexOf("date form_time") < 0)
                $(element).next("span").addClass("glyphicon-remove").removeClass("glyphicon-ok");
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).parent().addClass("has-success").removeClass("has-error");
            $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
            if (element.parentElement.className.indexOf("date form_time") < 0)
                $(element).next("span").addClass("glyphicon-ok").removeClass("glyphicon-remove");
        },
        submitHandler: function (form) {
            var data = $(form).serializeJson();
            console.log(data);
        }
    };
    jQuery.validator.addMethod("isPassword", function (value, element) {
        var reg = /^[0-9A-Za-z]{8,20}$/;
        return this.optional(element) || (reg.test(value));
    }, "8~20位字符，包含字母和数字");
    jQuery.validator.addMethod("isPhoneNumber", function (value, element) {
        var reg = /^((13[0-9])|(15[^4])|(18[0-9])|(17[0-8])|(147,145))\d{8}$/;
        return this.optional(element) || (reg.test(value));
    }, "请输入中国合法手机号");
    jQuery.validator.addMethod("isPhoneCode", function (value, element) {
        var reg = /^\d{6}$/ig;
        return this.optional(element) || (reg.test(value));
    }, "请输入6位验证码");

    $('.Email').validate(fromValidator);
    $('.passWord').validate(fromValidator);
    $('.Phone').validate(fromValidator);
    $('.code').validate(fromValidator);
    //验证码过期时间设置
    var time = 5;
    var timer = null;
    $('.bt').click(function () {
        var email=$("#email").val();
        var phoneNumber=$("#phoneNumber").val();
        var regEmail = /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
        var regPhone = /^1(3|4|5|7|8)\d{9}$/g;
        var phone = $('.phone-num').text();
        var emailNum = $('.email-num').text();
        var data = {};
        //每次进入把原来timer清除掉
        clearInterval(timer);
        console.log(regEmail.test(email));
        if(regEmail.test(email)){
            data.email = email;
        }else if(regPhone.test(phoneNumber)){
            data.phoneNumber = phoneNumber;
        }else if(phone){
            data.phone = phone;
        }else {
            data.emailNum = emailNum;
        }
        if(regEmail.test(email) || regPhone.test(phoneNumber) || phone || emailNum){
            /*$.ajax({
             type: "POST",
             url: "##",
             data: data,
             success: function(msg){
                 if (msg==1) {
                     $(this).next().empty();
                     $(this).next().removeClass('validate-error').addClass('validate-ok')
                         .append($("<span class='glyphicon glyphicon-ok-sign'>&nbsp;验证码已发送</span>"));
                    }
                }
             });*/
            $(".bt").attr("disabled","true");
            $(".bt").text(time+"s后重新发送");
            timer=setInterval(function (){
                if(time==0){
                    clearInterval(timer);
                    timer=null;
                    time = 5;
                    $(".bt").removeAttr("disabled");
                    $(".bt").text("发送验证码");
                }
                else{
                    time--;
                    $(".bt").text(time+"s后重新发送");
                }
            }, 1000);
        }
    });

