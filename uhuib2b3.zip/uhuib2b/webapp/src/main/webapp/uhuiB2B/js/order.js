$(function(){
	var currentPageNumber = 1;
	$('#exampleInputName2').datetimepicker({
		language: "zh-CN",
	    format: 'yyyy-mm-dd hh:ii',
	    todayBtn: true,
	    clearBtn: true,
	    autoclose: true,
	    minView: 0,
	    minuteStep:1
	}).on("click",function(){
	        $("#exampleInputName2").datetimepicker("setEndDate",$("#exampleInputEmail2").val());
	    });
	$('#exampleInputEmail2').datetimepicker({
		language: "zh-CN",
	    format: 'yyyy-mm-dd hh:ii',
	    todayBtn: true,
	    clearBtn: true,
	    autoclose: true,
	    minView: 0,
	    minuteStep:1
	}).on("click",function(){
	        $("#exampleInputEmail2").datetimepicker("setStartDate",$("#exampleInputName2").val());
	   });
	//分页
	$("nav").find("li a").on('click', function () {
	        var lis = $("nav li");
	        var index = lis.index($(this).parent());
	        if ($(this).parent().hasClass('disabled')) {
	            return;
	        }
	        if (index !== currentPageNumber + 1) {
	            if (index >= 2 && index < lis.length - 2) {
	                currentPageNumber = index - 1;
	            } else {
	                if (index === 0) {
	                    currentPageNumber = 1;
	                } else if (index === 1) {
	                    currentPageNumber--;
	                } else if (index === lis.length - 1) {
	                    currentPageNumber = lis.length - 4
	                } else if (index === lis.length - 2) {
	                    currentPageNumber++;
	                }
	            }
	            if (currentPageNumber === 1) {
	                $("nav li:lt(2)").addClass('disabled')
	            } else {
	                $("nav li:lt(2)").removeClass('disabled')
	            }
	            var gtIndex = lis.length - 3;
	            if (currentPageNumber === lis.length - 4) {
	                $("nav li:gt(" + gtIndex + ")").addClass('disabled')
	            } else {
	                $("nav li:gt(" + gtIndex + ")").removeClass('disabled')
	            }
	            lis.removeClass('selected-page');
	            lis.eq(currentPageNumber + 1).addClass('selected-page');
	            $("#pageNumber").html(currentPageNumber);
				console.log(firstRun)
	        }
			var page = {};
			page.pageNum = currentPageNumber;
			page.pageRow = 16;
			ajax(page);
		});
	//淡入淡出
	$(".track").click(function(){
		$(".orderWrap").hide();
		$(".order-detail").fadeIn();
	});
	$(".order-detail-head span").click(function(){
		$(".orderWrap").fadeIn();
		$(".order-detail").hide();
	});
	//tab切换
	$(".navBtn div").click(function(){
		var i = $(this).index();
		$(this).addClass('active1').siblings().removeClass('active1');
		$("#orderTable table").eq(i).show().siblings().hide();
	})
	//按钮全选全不选
	$('#checkedAllBtn').click(function () {
		$('.ipt').prop('checked', this.checked);
	});
	//同步更新checkedAllBtn
	$('.ipt').click(function () {
		$('#checkedAllBtn').prop('checked', $('.ipt:not(:checked)').length===0);
	});
	// 滚动条
	$(".goods-wrap").mCustomScrollbar({
        theme: "minimal-dark"
    });
    var innerHeight = $('body').innerHeight()-290;
    $('.goods-wrap').height(innerHeight);
	//ajax  交互
	$('.searchBtn').click(function () {
		var iptVal = $.trim($('.form-control').val());
		var reg = /^[0-9]\d{9,20}$/;
		console.log(reg.test(iptVal));

		if(reg.test(iptVal) && iptVal){
			console.log(666);
			var iptVal = {orderID : iptVal};
			ajax(iptVal);
		}else {
			// $('.ddh').attr('value','请输入10位有效数字');
			console.log("请输入10位有效数字");
		}
	});
	//筛选
	$('.filter').click(function () {
		var start = $('#exampleInputName2').val();
		var end = $('#exampleInputEmail2').val();
		var orderTime = {
			start:start,
			end : end
		};
		console.log(orderTime);
		// var bbb = 'bbb'+'?callback=?';
		ajax(orderTime);
	});
	//点击订单详情
	$('.track').click(function () {
		var index = $('.track').index($(this));
		var num = $('.goodsContent span:first-child').eq(index).text();
		console.log(num);
		var regNum = /\d+/g;
		var orderID = num.match(regNum).toString();
		console.log(orderID);
		console.log(index);
		var orderDetail = {};
		orderDetail.orderID=orderID ;
		console.log(orderDetail);
		ajax(orderDetail);
		// var ccc = 'ccc'+'?callback=?';
	});
	//navBtn  ajax
	$('.cutTab div').click(function () {
		var number = $(this).index()
		var navBtnNum = {};
		navBtnNum.navBtnID = number;
		ajax(navBtnNum);
	});
	//点击退货按钮的X
	//-------
	var firstRun = {
		currentPageNumber:currentPageNumber,
		pageSize : 16
	};
	// ajax(firstRun);

	function ajax(obj) {
		var url = '/services/order/list';
		$.ajax({
			type: "GET",
			url: url,
			data:obj,
			datatype:"json",
			success: function(result){
				//首次请求
				if(firstRun){
					return;
				};
				//分页请求
				if ( page){
					alert(111);
					console.log(url)
				};
				//时间差请求
				if(orderTime){
						var len = 5;
						var str = '';
						for (var i=0; i<len ;i++){
							str += '<table class="goodsContent">'
								+'<tr>'
								+'<td><input class="ipt" type="checkbox" /></td>'
								+'<span>订单编号：'+7777121212121212121+'</span>|<span class="nbsp">下单时间："2017/04/27 16:27:25"</span>|<span>客户：'+'李四'+'</span></td>'
								+'</tr>'
								+'<tr class="goodsHead">'
								+'<td></td>'
								+'<td>'
								+'<img style="width: 38px;" src='+'"images/location_qiaopai.png"'+'/>'
								+'#92号汽油 国ＩＶ'
								+'</td>'
								+'<td>"￥5000"</td>'
								+'<td>"10"</td>'
								+'<td>"￥5,0000"</td>'
								+'<td>代付款</td>'
								+'<td>'
								+'<a href="javascript:;" class="track">'
								+'<span class="glyphicon glyphicon-search"></span> 订单详情'
								+'</a>'
								+'</td>'
								+'</tr>'
								+'</table>'
						}
						$('.goods-wrap').append(str);
				};
				//订单详情
				if(orderDetail){
						var detailTableStr = '';
						detailTableStr = '<table class="order-detail-table">'
							+'<tr>'
							+'<th>订单编号：</th>'
							+'<td>"1234567890123456789"</td>'
							+'</tr>'
							+'<tr>'
							+'<th>客户信息：</th>'
							+'<td>"壳牌公司"</td>'
							+'</tr>'
							+'<tr>'
							+'<th>下单时间：</th>'
							+'<td>'+'</td>'
							+'</tr>'
							+'<tr>'
							+'<th>支付时间：</th>'
							+'<td>'+'</td>'
							+'</tr>'
							+'<tr>'
							+'<th>完成时间：</th>'
							+'<td>'+'</td>'
							+'</tr>'
							+'</table>';
						var goodsTableStr = '';
						goodsTableStr = '<table class="order-goods-table">' +
							'<tr>' +
							'<th>商品图片</th>' +
							'<th>商品代码</th>' +
							'<th>种类</th>' +
							'<th>型号</th>' +
							'<th>单价</th>' +
							'<th>数量</th>' +
							'<th>支付金额</th>' +
							'<th>提货地</th>' +
							'<th></th>' +
							'</tr>' +
							'<tr>' +
							'<td><img style="width: 38px;" src='+"images/location_qiaopai.png"+'alt="" /></td>' +
							'<td>'+"12345678901"+'</td>' +
							'<td>"柴油"</td>' +
							'<td>"国IV+"</td>' +
							'<td>'+'￥5000'+'</td>' +
							'<td>'+10+'</td>' +
							'<td>'+'￥5,0000'+'</td>' +
							'<td>"天津市南开区"</td>' +
							'<td></td>' +
							'</tr>' +
							'</table>'
						var payTableStr = '';
						payTableStr = '<table class="order-pay-table">' +
							'<tr>' +
							'<th>支付时间</th>' +
							'<th>支付单号</th>' +
							'<th>支付方式</th>' +
							'<th>支付金额</th>' +
							'</tr>' +
							'<tr>' +
							'<td></td>' +
							'<td>'+"1234567890123456789"+'</td>' +
							'<td>"银行卡支付"</td>' +
							'<td>'+'￥5,0000'+'</td>' +
							'</tr>' +
							'</table>'
						var customerTableStr = '';
						customerTableStr = '<table class="order-customer-table">' +
							'<tr>' +
							'<th>公司名称：</th>' +
							'<td>壳牌公司</td>' +
							'</tr>' +
							'<tr>' +
							'<th>所在地：</th>' +
							'<td>'+"天津市南开区"+'</td>' +
							'</tr>' +
							'</table>'
						var detailTableStr = '';
						detailTableStr = '<table class="order-detail-table" style="display: none;">' +
							'<tr>' +
							'<th>配送方式：</th>' +
							'<td>'+"自提"+'</td>' +
							'</tr>' +
							'</table>'
						var orderTableStr = detailTableStr + customerTableStr + payTableStr + goodsTableStr + detailTableStr ;
						$('#orderTable').append(orderTableStr);
						console.log("ccc 接口成功");
				};
				//订单号请求
				if(iptVal){
					console.log(111145454)
				}
				//navBtn请求
				if(navBtnNum){

				}
			},
			error:function () {

			}
		});
	}
	console.log(currentPageNumber);
});