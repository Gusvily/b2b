System markdown
=============
The configurable server system 

### Bootstrap ###
	cd source_dir
	./gradlew

### Building ###
	./gradlew build

### Running unit tests ###
	./gradlew test

### Building a release tar package###
	./gradlew clean build releaseTarGz

### Publishing artifacts to nexus ###
	./gradlew -PnexusUsername=$NEXUS_USER -PnexusPassword=$NEXUS_PWD -PuhuiappVersion=$VERSION publish
