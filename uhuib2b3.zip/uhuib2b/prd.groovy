environments {
    prd {
        DB {
            JDBC_URL = 'jdbc:mysql://127.0.0.1:3306/uhuiapp?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true'
            USER = 'root'
            PASSWORD = 'root'
        }
        REDIS {
            HOST = 'localhost'
            PORT = '6379'
            EXPIRE = '1800'
        }
        DUBBO {
            REGISTRY {
                ADDRESS = 'zookeeper://127.0.0.1:2181'
            }
        }
        UPLOAD {
            FILE {
                ROOT = 'd:/FileRepositoryTest/'
            }
        }
        RESOURCE {
            PERMISSION {
                MAPPING {
                    PATH = 'resource-permission-mapping.json'
                }
            }
        }
    }
}