package com.uhui.configurable.api.Permission;

import com.uhui.configurable.api.Permission.checker.PermissionMatchType;

import java.io.Serializable;

/**
 * Created by Fidel on 2017/5/22.
 */
public class SimpleWildcardPermission implements Permission, Serializable {

    private PermissionMatchType permissionMatchType;

    private String userPermission;

    private String resourcePermission;

    public SimpleWildcardPermission() {
    }

    public SimpleWildcardPermission(PermissionMatchType permissionMatchType, String userPermission, String resourcePermission) {
        this.permissionMatchType = permissionMatchType;
        this.userPermission = userPermission;
        this.resourcePermission = resourcePermission;
    }

    @Override
    public PermissionMatchType getPermissionMatchType() {
        return permissionMatchType;
    }

    @Override
    public String getUserPermission() {
        return userPermission;
    }

    @Override
    public String getResourcePermission() {
        return resourcePermission;
    }

    public void setUserPermission(String userPermission) {
        this.userPermission = userPermission;
    }

    public void setResourcePermission(String resourcePermission) {
        this.resourcePermission = resourcePermission;
    }

    public String parseDataLevelPermission() {
        if (userPermission == null || resourcePermission == null) {
            return null;
        }
        return userPermission.substring(resourcePermission.length() + 1);
    }


}
