package com.uhui.configurable.api.Permission.cache;

/**
 * Created by Fidel on 2017/5/15.
 */
public interface Session {
}
