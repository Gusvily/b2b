package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/3/31.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class GasStation extends BaseModel {

    public static final String TABLE_NAME = "gas_station";

    private String source;
    private Long sourceId;
    private String name;
    private String area;
    private String areaName;
    private String address;
    private String brandName;
    private String type;
    private String discount;
    private String exhaust;
    private Double lon;
    private Double lat;
    private String fwlsmc;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
