package com.uhui.configurable.api.workflow.exception;

/**
 * Created by Fidel on 2017/4/10.
 */
public enum BusinessExceptionType {
    LOGIC("logic", "LOGIC means exception is logical business exception type."),
    RESOURCE("resource", "RESOURCE means exception is lack resource business exception type."),
    UNKNOWN("unknown", "unknown means real unknown...");

    private final String type;
    private final String description;

    BusinessExceptionType(String type, String description) {
        this.type = type;
        this.description = description;
    }

    public static BusinessExceptionType type(String type) {
        for (BusinessExceptionType businessExceptionType : BusinessExceptionType.values()) {
            if (businessExceptionType.type.equals(type)) {
                return businessExceptionType;
            }
        }
        return null;
    }
}
