package com.uhui.configurable.api.workflow;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by Fidel on 2017/3/1.
 */
public class SpringBean {

    public static final String STRING_BEAN_NAME_KEY = "beanName";
    public static final String STRING_BEAN_CLASS_KEY = "beanClass";

    @Setter
    @Getter
    private String beanName;
    @Setter
    @Getter
    private Class beanClass;
    @Setter
    @Getter
    private Object beanInstance;
}
