package com.uhui.configurable.api.workflow;

import lombok.Data;

/**
 * Created by Fidel on 2017/3/9.
 */
@Data
public class DubboConfigValue {

    private String name;
    private String value;

    public DubboConfigValue(String name, String value) {
        this.name = name;
        this.value = value;
    }

}
