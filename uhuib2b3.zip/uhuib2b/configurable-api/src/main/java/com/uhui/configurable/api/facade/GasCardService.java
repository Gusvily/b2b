package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/4/26.
 */
@Path("gasCard")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface GasCardService {
    /**
     * bind gas card
     *
     * @param params should include cardNo and cardType.
     * @return
     */
    @POST
    @Path("bindGasCard")
    ProcessingResult bindGasCard(@CookieParam("special_id") String specialId, Map<String, Object> params);

    /**
     * unbind gas card
     *
     * @param params should include cardNo and cardType.
     * @return
     */
    @POST
    @Path("unbindGasCard")
    ProcessingResult unbindGasCard(@CookieParam("special_id") String specialId, Map<String, Object> params);

    /**
     * unbind gas card
     *
     * @param params should include oldCardNo, oldCardType, newCardNo and newCardType.
     * @return
     */
    @POST
    @Path("modifyGasCard")
    ProcessingResult modifyGasCard(@CookieParam("special_id") String specialId, Map<String, Object> params);
}
