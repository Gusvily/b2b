package com.uhui.configurable.api.workflow;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Fidel on 2017/2/28.
 */
public class JsonDubboConfigurableWorkFlow extends DubboConfigurableWorkFlow {

    @Override
    public WorkFlowConfig initResource(String resourcePath) {
        if (resourcePath == null || resourcePath.length() == 0) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Resource path must be not null.");
        }
        try {
            InputStream resourceInputStream = this.getClass().getClassLoader().getResourceAsStream(resourcePath);
            String resourceContent = IOUtils.toString(resourceInputStream, "UTF-8");
            JSONObject json = JSON.parseObject(resourceContent);
            JSONObject workflow = json.getJSONObject(CONFIGURABLE_WORKFLOW_KEY);
            setName(workflow.getString("name"));
            initDubboConfig(workflow);
            initDependencies(workflow);
            initProcessors(workflow);
        } catch (Exception e) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Resource init failed, resource path: " + resourcePath, e);
        }
        return null;
    }

    private void initProcessors(JSONObject workflow) {
        JSONObject methodsJson = workflow.getJSONObject(CONFIGURABLE_WORKFLOW_KEY_METHODS);
        if (methodsJson == null && methodsJson.size() < 1) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, no method defined.");
        }
        Map<String, Processor> methods = new HashMap<>();
        for (Map.Entry<String, Object> entry : methodsJson.entrySet()) {
            ConfigurableProcessor processor = new ConfigurableProcessor();
            processor.setName(entry.getKey());
            JSONObject value = (JSONObject) entry.getValue();
            JSONArray jsonProcessingChain = value.getJSONArray(Processor.PROCESOR_PROCESSING_CHAIN_KEY);
            ProcessingChain processingChain = new ProcessingChain();
            for (int i = 0; i < jsonProcessingChain.size(); i++) {
                JSONObject jsonProcessingNode = jsonProcessingChain.getJSONObject(i);
                ProcessingNode processingNode = buildProcessingNode(jsonProcessingNode, i + "");
                processingChain.setNode(processingNode);
            }
            processor.setProcessingChain(processingChain);
            JSONArray inputs = value.getJSONArray(Processor.PROCESOR_INPUT_KEY);
            if (inputs != null) {
                processor.setInputNames(inputs.toArray(new String[0]));
            }
            processor.setOutputName(value.getString(Processor.PROCESOR_OUTPUT_KEY));
            Boolean jsonpMethod = value.getBoolean(Processor.PROCESOR_JSONP_METHOD_KEY);
            if (jsonpMethod == null) {
                processor.setJsonpMethod(false);
            } else {
                processor.setJsonpMethod(jsonpMethod);
            }
            methods.put(processor.getName(), processor);
        }
        setWorkFlowMethods(methods);
    }

    private ProcessingNode buildProcessingNode(JSONObject jsonProcessingNode, String indexSuffix) {
        ProcessingNode processingNode = new ProcessingNode();
        String processingNodeDependencyName = jsonProcessingNode.getString(ProcessingNode.PROCESSING_NODE_DEPENDENCY_KEY);
        if (processingNodeDependencyName == null) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing node dependency init unsuccessfully.");
        }
        String processingNodeInvokeName = jsonProcessingNode.getString(ProcessingNode.PROCESSING_NODE_INVOKE_KEY);
        if (processingNodeInvokeName == null) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing node invoke init unsuccessfully.");
        }
        String processingNodeName = jsonProcessingNode.getString(ProcessingNode.PROCESSING_NODE_NAME_KEY);
        if (processingNodeName == null) {
            processingNodeName = generateDefaultProcessingNodeName(processingNodeDependencyName, processingNodeInvokeName, indexSuffix);
        }
        JSONArray argumentsJsonArray = jsonProcessingNode.getJSONArray(ProcessingNode.PROCESSING_NODE_ARGUMENTS_KEY);
        JSONArray argumentClassesJsonArray = jsonProcessingNode.getJSONArray(ProcessingNode.PROCESSING_NODE_ARGUMENT_CLASSES_KEY);
        processingNode.setName(processingNodeName);
        processingNode.setDependencyName(processingNodeDependencyName);
        processingNode.setInvokeName(processingNodeInvokeName);
        if (argumentsJsonArray != null && argumentsJsonArray.size() > 0) {
            processingNode.setArguments(argumentsJsonArray.toArray(new String[0]));
        }
        if (argumentClassesJsonArray != null && argumentClassesJsonArray.size() > 0) {
            try {
                Class[] argumentClassesArray = new Class[argumentClassesJsonArray.size()];
                for (int j = 0; j < argumentClassesArray.length; j++) {
                    String className = argumentClassesJsonArray.getString(j);
                    argumentClassesArray[j] = Class.forName(className);
                }
                processingNode.setArgumentClasses(argumentClassesArray);
            } catch (Exception e) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, argument classes init unsuccessfully.", e);
            }
        }
        JSONObject resultJsonObject = jsonProcessingNode.getJSONObject(ProcessingNode.PROCESSING_NODE_RESULT_KEY);
        if (resultJsonObject != null) {
            ProcessingNodeResultAction processingNodeResultAction = ProcessingNodeResultAction.valueOf(
                    resultJsonObject.getString(ProcessingNodeResult.PROCESSING_NODE_RESULT_ACTION_KEY).toUpperCase());
            String processingNodeResultName = resultJsonObject.getString(ProcessingNodeResult.PROCESSING_NODE_RESULT_NAME_KEY);
            Integer processingNodeCode = resultJsonObject.getInteger(ProcessingNodeResult.PROCESSING_NODE_RESULT_CODE_KEY);
            ProcessingNodeResult processingNodeResult =
                    new ProcessingNodeResult(processingNodeResultAction, processingNodeResultName, processingNodeCode);
            processingNode.setProcessingNodeResult(processingNodeResult);
        }
        Boolean allowNullJsonValue = jsonProcessingNode.getBoolean(ProcessingNode.PROCESSING_NODE_ALLOW_NULL_KEY);
        if (allowNullJsonValue != null) {
            processingNode.setAllowNull(allowNullJsonValue);
        }
        JSONObject subNodeJsonObjects = jsonProcessingNode.getJSONObject(ProcessingNode.PROCESSING_NODE_SUB_NODE_KEY);
        if (subNodeJsonObjects != null) {
            for (String key : subNodeJsonObjects.keySet()) {
                JSONObject subNodeJsonObject = subNodeJsonObjects.getJSONObject(key);
                ProcessingNode subProcessingNode = buildProcessingNode(subNodeJsonObject, indexSuffix + "___" + key);
                processingNode.setSubNode(Integer.parseInt(key), subProcessingNode);
            }
        }
        return processingNode;
    }

    private String generateDefaultProcessingNodeName(String processingNodeDependencyName, String processingNodeInvokeName, String indexSuffix) {
        return new StringBuffer(processingNodeDependencyName)
                .append("_").append(processingNodeInvokeName).append("__").append(indexSuffix).toString();
    }

    private void initDependencies(JSONObject workflow) {
        JSONArray dependenciesJson = workflow.getJSONArray(CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES);
        if (dependenciesJson != null && dependenciesJson.size() > 0) {
            Map<String, SpringBean> springBeans = new HashMap<>();
            for (int i = 0; i < dependenciesJson.size(); i++) {
                JSONObject dependency = dependenciesJson.getJSONObject(i);
                String beanName = dependency.getString(SpringBean.STRING_BEAN_NAME_KEY);
                String beanClass = dependency.getString(SpringBean.STRING_BEAN_CLASS_KEY);
                Class beanClz;
                try {
                    beanClz = Class.forName(beanClass);
                } catch (ClassNotFoundException e) {
                    throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("Dependency init failed, bean name: %s, bean class: %s", beanName, beanClass), e);
                }
                SpringBean springBean = new SpringBean();
                springBean.setBeanName(beanName);
                springBean.setBeanClass(beanClz);
                springBeans.put(beanName, springBean);
            }
            setWorkFlowDependencies(springBeans);
        }
    }

    private void initDubboConfig(JSONObject workflow) {
        JSONObject dubboConfig = workflow.getJSONObject(CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG);
        for (Map.Entry<String, Object> entry : dubboConfig.entrySet()) {
            Class configType = DubboConfigMapping.getType(entry.getKey()).clz();
            if (configType == null) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig init failed, config name: %s, config value: %s", entry.getKey(), entry.getValue()));
            }
            initField(entry.getKey(), entry.getValue().toString());
        }
    }

}