package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/15.
 */
public class PasswordRetryLimitExceedException extends PermissionException {

    public PasswordRetryLimitExceedException(int maxRetryCount) {
        super("Password retry limit exceed. Max retry count: " + maxRetryCount);
    }

    public PasswordRetryLimitExceedException(int maxRetryCount, Throwable cause) {
        super("Password retry limit exceed. Max retry count: " + maxRetryCount, cause);
    }
}
