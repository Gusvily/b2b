package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/15.
 */
public class SessionException extends PermissionException {

    public SessionException() {
        super();
    }

    public SessionException(String message) {
        super(message);
    }

    public SessionException(Throwable cause) {
        super(cause);
    }

    public SessionException(String message, Throwable cause) {
        super(message, cause);
    }
}
