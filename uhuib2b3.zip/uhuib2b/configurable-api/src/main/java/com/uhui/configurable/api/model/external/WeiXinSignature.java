package com.uhui.configurable.api.model.external;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/3/15.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class WeiXinSignature {

    private String url;
    private String nonceStr;
    private String signature;
    private String timestamp;

}
