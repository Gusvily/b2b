package com.uhui.configurable.api.extension;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.uhui.configurable.api.Permission.Permission;
import com.uhui.configurable.api.Permission.PermissionConstant;
import com.uhui.configurable.api.Permission.SimpleWildcardPermission;
import com.uhui.configurable.api.Permission.cache.Cache;
import com.uhui.configurable.api.Permission.cache.CacheConstant;
import com.uhui.configurable.api.Permission.cache.CacheManager;
import com.uhui.configurable.api.Permission.cache.RedisCacheManager;
import com.uhui.configurable.api.Permission.cache.RedisManager;
import com.uhui.configurable.api.Permission.checker.JsonResourcePermissionResolver;
import com.uhui.configurable.api.Permission.checker.PermissionMatchType;
import com.uhui.configurable.api.Permission.checker.PermissionMatcher;
import com.uhui.configurable.api.Permission.checker.ResourcePermissionResolver;
import com.uhui.configurable.api.Permission.checker.WildcardPermissionChecker;
import com.uhui.configurable.api.Permission.model.DataLevelControlModel;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.workflow.ProcessingResult;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Created by Fidel on 2017/4/13.
 */
@Service
@Priority(Priorities.USER)
public class AuthenticationFilter implements ContainerRequestFilter, ContainerResponseFilter {

    public static String TOKEN_PREFIX = "token_";
    private static final Logger LOGGER = Logger.getLogger(AuthenticationFilter.class);
    private static final String SPECIAL_ID_COOKIE_KEY = "special_id";
    private static final String TOKEN_COOKIE_KEY = "__token__";
    private static final String LOGIN_PATH = "/services/account/login";

    private CacheManager cacheManager;
    private WildcardPermissionChecker permissionChecker;
    private ResourcePermissionResolver<String, String> resourcePermissionResolver;

    public void filter(ContainerRequestContext requestContext) throws IOException {
        try {
            String requestUri = requestContext.getUriInfo().getPath();
            if (StringUtils.isEmpty(requestUri)) {
                responseAuthenticationFailed(requestContext);
            }
            String permissionFromResource = getPermissionFromResource(requestUri);
            Long currentUserId = null;
            try {
                Map<String, Cookie> cookies = requestContext.getCookies();
                Cookie tokenCookie = cookies.get(TOKEN_COOKIE_KEY);
                String token = tokenCookie.getValue();
                Cache tokenCache = getTokenCache();
                currentUserId = (Long) tokenCache.get(token);
            } catch (Exception e) {
            }
            if (currentUserId == null) {
                if (!PermissionConstant.PERMISSION_ANONYMOUS.equals(permissionFromResource)) {
                    responseAuthenticationFailed(requestContext);
                }
            } else {
                Cache userCache = getUserCache(currentUserId);
                if (PermissionConstant.PERMISSION_AUTHENTICATION.equals(permissionFromResource)) {
                    User currentUser = (User) userCache.get(CacheConstant.CACHE_CURRENT_USER_KEY);
                    if (currentUser == null) {
                        responseAuthenticationFailed(requestContext);
                    }
                    List<String> currentUserPermissions = (List<String>) userCache.get(CacheConstant.CACHE_CURRENT_USER_PERMISSIONS_KEY);
                    PermissionMatcher permissionMatcher = checkPermission(currentUserPermissions, permissionFromResource);
                    userCache.put(CacheConstant.CACHE_CURRENT_ACTION_PERMISSION_KEY,
                            new SimpleWildcardPermission(permissionMatcher.getMatchType(),
                                    permissionMatcher.getPermission(), permissionFromResource));
                } else {
                    if (!PermissionConstant.PERMISSION_ANONYMOUS.equals(permissionFromResource)) {
                        List<String> currentUserPermissions = (List<String>) userCache.get(CacheConstant.CACHE_CURRENT_USER_PERMISSIONS_KEY);
                        PermissionMatcher permissionMatcher = checkPermission(currentUserPermissions, permissionFromResource);
                        if (permissionMatcher.getMatchType() == PermissionMatchType.MISMATCHING) {
                            responseAuthenticationFailed(requestContext);
                        } else {
                            userCache.put(CacheConstant.CACHE_CURRENT_ACTION_PERMISSION_KEY,
                                    new SimpleWildcardPermission(permissionMatcher.getMatchType(),
                                            permissionMatcher.getPermission(), permissionFromResource));
                        }
                    }
                }
            }
        } catch (Throwable t) {
            responseAuthenticationFailed(requestContext);
        }
    }

    public void filter(ContainerRequestContext containerRequestContext, ContainerResponseContext containerResponseContext) throws IOException {
        Object entity = containerResponseContext.getEntity();
        String oldToken = null;
        Cache tokenCache = getTokenCache();
        try {
            Map<String, Cookie> cookies = containerRequestContext.getCookies();
            Cookie tokenCookie = cookies.get(TOKEN_COOKIE_KEY);
            oldToken = tokenCookie.getValue();
        } catch (Exception e) {
        }
        ProcessingResult result = null;
        if (entity instanceof ProcessingResult) {
            result = (ProcessingResult) entity;
            String uri = containerRequestContext.getUriInfo().getPath();
            User currentUser = null;
            if (LOGIN_PATH.equals(uri)) {
                try {
                    currentUser = (User) result.getDatas().get(0);
                } catch (Exception e) {
                }
            } else {
                Long currentUserId = (Long) tokenCache.get(oldToken);
                currentUser = (User) getUserCache(currentUserId).get(CacheConstant.CACHE_CURRENT_USER_KEY);
                if (currentUser == null) {
                    if (ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS.equals(result.getStatus())) {
                        responseAuthenticationFailed(containerResponseContext);
                    }
                }
            }
            if (ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS.equals(result.getStatus())) {
                if (currentUser == null) {
                    responseAuthenticationFailed(containerResponseContext);
                }
                String token = currentUser.buildToken();
                tokenCache.put(token, currentUser.getId());
                containerResponseContext.getHeaders().add(TOKEN_COOKIE_KEY, token);
                if (!LOGIN_PATH.equals(uri)) {
                    List datas = result.getDatas();
                    Cache userCache = getUserCache(currentUser.getId());
                    Permission currentActionPermission = (Permission) userCache.get(CacheConstant.CACHE_CURRENT_ACTION_PERMISSION_KEY);
                    if (currentActionPermission.getPermissionMatchType() == PermissionMatchType.CONDITIONAL_MATCHING) {
                        for (Object data : datas) {
                            if (data instanceof DataLevelControlModel) {
                                DataLevelControlModel model = (DataLevelControlModel) data;
                                if (!model.doDataLevelCheck(currentActionPermission, currentUser)) {
                                    responseDataLevelCheckFailed(containerResponseContext);
                                }
                            } else {
                                responseDataLevelCheckFailed(containerResponseContext);
                            }
                        }
                    }
                }
            }
        }
        tokenCache.remove(oldToken);

    }

    private void responseAuthenticationFailed(ContainerRequestContext requestContext) {
        LOGGER.info("authentication_failed happened.");
        ProcessingResult result = ProcessingResult.failed("authentication_failed");
        Response.ResponseBuilder builder = Response.ok(result, "application/json");
        requestContext.abortWith(builder.build());
    }

    private void responseAuthenticationFailed(ContainerResponseContext containerResponseContext) {
        LOGGER.info("authentication_failed happened.");
        ProcessingResult result = ProcessingResult.failed("authentication_failed");
        containerResponseContext.setEntity(result);
    }

    private void responseDataLevelCheckFailed(ContainerResponseContext containerResponseContext) {
        LOGGER.info("data_level_check_failed happened.");
        ProcessingResult result = ProcessingResult.failed("data_level_check_failed");
        containerResponseContext.setEntity(result);
    }

    private PermissionMatcher checkPermission(List<String> currentUserPermissions, String permissionFromResource) throws IOException {
        if (permissionChecker == null) {
            buildPermissionChecker();
        }
        return permissionChecker.checkPermissions(currentUserPermissions, permissionFromResource);
    }

    private void buildPermissionChecker() throws IOException {
        permissionChecker = new WildcardPermissionChecker();
    }

    private String getPermissionFromResource(String resource) throws IOException {
        if (resourcePermissionResolver == null) {
            buildPermissionResolver();
        }
        return resourcePermissionResolver.resolvePermission(resource);
    }

    private void buildPermissionResolver() throws IOException {
        Properties properties = buildProperties();
        String resourcePermissionMappingPath = properties.getProperty("RESOURCE.PERMISSION.MAPPING.PATH");
        resourcePermissionResolver = new JsonResourcePermissionResolver(resourcePermissionMappingPath);
    }

    private Cache getUserCache(Long userId) throws IOException {
        return getCache(CacheConstant.USER_CACHE_PREFIX_KEY + userId);
    }

    private Cache getTokenCache() throws IOException {
        return getCache(CacheConstant.REDIS_TOKEN_CACHE_KEY);
    }

    private Cache getCache(String key) throws IOException {
        if (cacheManager == null) {
            buildCacheManager();
        }
        return cacheManager.getCache(key);
    }

    private void buildCacheManager() throws IOException {
        Properties properties = buildProperties();
        String redisHost = properties.getProperty("REDIS.HOST");
        String redisPort = properties.getProperty("REDIS.PORT");
        String redisExpire = properties.getProperty("REDIS.EXPIRE");
        if (StringUtils.isEmpty(redisHost)) {
            redisHost = "127.0.0.1";
        }
        if (StringUtils.isEmpty(redisPort)) {
            redisPort = "6379";
        }
        if (StringUtils.isEmpty(redisExpire)) {
            redisPort = "1800";
        }
//        JedisPoolConfig config = new JedisPoolConfig();
//        config.setMaxTotal(20);
//        config.setMaxIdle(10);
//        jedisPool = new JedisPool(config, redisHost, Integer.parseInt(redisPort));
        RedisManager redisManager = new RedisManager();
        redisManager.setHost(redisHost);
        redisManager.setPort(Integer.parseInt(redisPort));
        redisManager.setExpire(Integer.parseInt(redisExpire));
        RedisCacheManager cacheManager = new RedisCacheManager();
        cacheManager.setRedisManager(redisManager);
        this.cacheManager = cacheManager;
    }

    private Properties buildProperties() throws IOException {
        File dir = new File(System.getProperty("CONF_PATH"));
        File propertiesFile = new File(dir, "spring-base.properties");
        Properties properties = new Properties();
        properties.load(new FileInputStream(propertiesFile));
        return properties;
    }
}
