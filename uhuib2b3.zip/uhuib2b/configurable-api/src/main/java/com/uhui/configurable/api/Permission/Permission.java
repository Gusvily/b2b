package com.uhui.configurable.api.Permission;

import com.uhui.configurable.api.Permission.checker.PermissionMatchType;

/**
 * Created by Fidel on 2017/5/22.
 */
public interface Permission {

    PermissionMatchType getPermissionMatchType();

    String getUserPermission();

    String getResourcePermission();
}
