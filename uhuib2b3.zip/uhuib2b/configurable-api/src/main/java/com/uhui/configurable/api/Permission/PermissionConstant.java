package com.uhui.configurable.api.Permission;

/**
 * Created by Fidel on 2017/5/18.
 */
public interface PermissionConstant {

    String PERMISSION_ANONYMOUS = "anon";
    String PERMISSION_AUTHENTICATION = "authc";
    String PERMISSIONS_AUTHORIZATION = "perms";

    String DATA_LEVEL_OPERATION_ROW = "row";
    String DATA_LEVEL_OPERATION_ROW_DATAILS_GROUP = "group";
    String DATA_LEVEL_OPERATION_ROW_DATAILS_OWNER = "owner";

}
