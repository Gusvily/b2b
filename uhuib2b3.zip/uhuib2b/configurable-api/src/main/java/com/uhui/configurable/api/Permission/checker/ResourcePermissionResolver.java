package com.uhui.configurable.api.Permission.checker;

/**
 * Created by Fidel on 2017/5/16.
 */
public interface ResourcePermissionResolver<R, P> {

    P resolvePermission(R resource);
}
