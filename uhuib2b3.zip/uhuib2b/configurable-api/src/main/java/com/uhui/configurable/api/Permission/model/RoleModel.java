package com.uhui.configurable.api.Permission.model;

/**
 * Created by Fidel on 2017/5/23.
 */
public interface RoleModel {

    public abstract String getOwner();

    public abstract String getGroup();

}
