package com.uhui.configurable.api.model;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.Permission.PermissionConstant;
import com.uhui.configurable.api.Permission.model.RoleModel;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by Fidel on 2017/4/17.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Product extends BusinessModel {

    public static final String TABLE_NAME = "product";

    private String name;
    private String title;
    private Integer productStatus;
    private String specification;
    private Date publishDate;
    private Long publisherId;
    private Integer productType;
    private String imageUrl;
    private BigDecimal price;
    private BigDecimal perPrice;
    private Integer salePieceNum;
    private Long origin;
    private String sellArea;
    private String introduction;
    private Integer deliveryType;
    private Integer payType;
    private Integer sourceType;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }

    @Override
    protected String parseDataLevelCondition(RoleModel roleInstance, String action, String[] operationDetails) {
        if (PermissionConstant.DATA_LEVEL_OPERATION_ROW.equals(action)) {
            if (operationDetails.length == 0) {
                BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Missing action details in Product model.");
            }
            String operationDetail = operationDetails[0];
            if (PermissionConstant.DATA_LEVEL_OPERATION_ROW_DATAILS_GROUP.equals(operationDetail)) {
                return "group_id=" + roleInstance.getGroup();
            } else if (PermissionConstant.DATA_LEVEL_OPERATION_ROW_DATAILS_OWNER.equals(operationDetail)) {
                return "publisher_id=" + roleInstance.getOwner();
            }
        }
        return null;
    }

    @Override
    protected boolean checkDataLevelCondition(RoleModel roleInstance, String action, String[] operationDetails) {
        if (PermissionConstant.DATA_LEVEL_OPERATION_ROW.equals(action)) {
            if (operationDetails.length == 0) {
                BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Missing action details in Product model.");
            }
            String operationDetail = operationDetails[0];
            if (PermissionConstant.DATA_LEVEL_OPERATION_ROW_DATAILS_GROUP.equals(operationDetail)) {
                return Long.toString(getGroupId()).equals(roleInstance.getGroup());
            } else if (PermissionConstant.DATA_LEVEL_OPERATION_ROW_DATAILS_OWNER.equals(operationDetail)) {
                return Long.toString(publisherId).equals(roleInstance.getOwner());
            }
        }
        return false;
    }

    public Integer getCashBackFromSpecification(Integer selectedMouth, Integer selectedAmount) {
        if (StringUtils.isEmpty(this.specification) || selectedMouth == null || selectedAmount == null) {
            return null;
        }
        JSONObject jsonSpecification = JSON.parseObject(this.specification);
        JSONArray monthlyCashBacks = jsonSpecification.getJSONArray("productSpecification");
        for (int i = 0; i < monthlyCashBacks.size(); i++) {
            JSONObject monthlyCashBack = monthlyCashBacks.getJSONObject(i);
            if (monthlyCashBack.getInteger("mouth") == selectedMouth) {
                JSONObject amountObject = monthlyCashBack.getJSONObject("amount");
                return amountObject.getInteger(selectedAmount.toString());
            }
        }
        return null;
    }
}
