package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/12.
 */
public class CacheException extends PermissionException {

    public CacheException() {
        super();
    }

    public CacheException(String message) {
        super(message);
    }

    public CacheException(Throwable cause) {
        super(cause);
    }

    public CacheException(String message, Throwable cause) {
        super(message, cause);
    }
}
