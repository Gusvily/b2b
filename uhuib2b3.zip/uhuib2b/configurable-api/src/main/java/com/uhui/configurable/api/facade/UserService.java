package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/7.
 */
@Path("user")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface UserService {

    @GET
    @Path("{id : \\d+}")
    ProcessingResult<User> getUser(@PathParam("id") @Min(1L) Long id);

    /**
     * register user
     *
     * @param params should include username and password
     * @return
     */
    @POST
    @Path("register")
    ProcessingResult<Integer> registerUser(Map<String, Object> params);

    @POST
    @Path("modify/{id : \\d+}")
    ProcessingResult<Integer> modifyUser(@PathParam("id") @Min(1L) Long id, User user);

    @POST
    @Path("delete/{id : \\d+}")
    ProcessingResult<Integer> deleteUser(@PathParam("id") @Min(1L) Long id);

    @GET
    @Path("query")
    ProcessingResult<Integer> queryUser();

    @POST
    @Path("info/current")
    ProcessingResult<User> getCurrentUserInfo(@CookieParam("special_id") String specialId);

}
