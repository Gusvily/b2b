package com.uhui.configurable.api.Permission.model;

import com.uhui.configurable.api.Permission.Permission;
import com.uhui.configurable.api.Permission.SimpleWildcardPermission;
import com.uhui.configurable.api.Permission.checker.WildcardPermissionChecker;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;

/**
 * Created by Fidel on 2017/5/23.
 */
public abstract class DataLevelControlModel {

    public String doDataLevelControl(Permission permission, RoleModel roleInstance) {
        if (permission == null || roleInstance == null) {
            return null;
        }
        switch (permission.getPermissionMatchType()) {
            case MATCHING:
                break;
            case MISMATCHING:
                break;
            case CONDITIONAL_MATCHING:
                String dataLevelPermission = parseDataLevelPermission(permission);
                String[] dataLevelPermissionArray = dataLevelPermission.split(WildcardPermissionChecker.PART_DIVIDER_TOKEN, 2);
                String operation = dataLevelPermissionArray[0];
                String operationDetails = dataLevelPermissionArray[1];
                String[] operationDetailsArray = operationDetails.split(WildcardPermissionChecker.PART_DIVIDER_TOKEN);
                return parseDataLevelCondition(roleInstance, operation, operationDetailsArray);
        }
        return null;
    }

    public boolean doDataLevelCheck(Permission permission, RoleModel roleInstance){
        if (permission == null || roleInstance == null) {
            return false;
        }
        switch (permission.getPermissionMatchType()) {
            case MATCHING:
                return  true;
            case MISMATCHING:
                return  false;
            case CONDITIONAL_MATCHING:
                String dataLevelPermission = parseDataLevelPermission(permission);
                String[] dataLevelPermissionArray = dataLevelPermission.split(WildcardPermissionChecker.PART_DIVIDER_TOKEN, 2);
                String operation = dataLevelPermissionArray[0];
                String operationDetails = dataLevelPermissionArray[1];
                String[] operationDetailsArray = operationDetails.split(WildcardPermissionChecker.PART_DIVIDER_TOKEN);
                return checkDataLevelCondition(roleInstance, operation, operationDetailsArray);
            default:
                return false;
        }
    }

    protected abstract String parseDataLevelCondition(RoleModel roleInstance, String action, String[] operationDetails);

    protected abstract boolean checkDataLevelCondition(RoleModel roleInstance, String action, String[] operationDetails);

    private String parseDataLevelPermission(Permission permission) {
        if (permission instanceof SimpleWildcardPermission) {
            SimpleWildcardPermission simpleWildcardPermission = (SimpleWildcardPermission) permission;
            String dataLevelPermission = simpleWildcardPermission.parseDataLevelPermission();

            if (dataLevelPermission != null) {
                return dataLevelPermission;
            } else {
                BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Parse data level permission failed.");
            }
        }
        return null;
    }
}
