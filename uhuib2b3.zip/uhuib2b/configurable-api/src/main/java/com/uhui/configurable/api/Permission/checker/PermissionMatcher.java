package com.uhui.configurable.api.Permission.checker;

import lombok.Data;

/**
 * Created by Fidel on 2017/5/22.
 */
@Data
public class PermissionMatcher {

    public PermissionMatcher(PermissionMatchType matchType, String permission) {
        this.matchType = matchType;
        this.permission = permission;
    }

    private PermissionMatchType matchType;

    private String permission;
}
