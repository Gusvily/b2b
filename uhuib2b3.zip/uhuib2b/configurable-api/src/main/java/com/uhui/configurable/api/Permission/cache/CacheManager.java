package com.uhui.configurable.api.Permission.cache;


import com.uhui.configurable.api.Permission.exception.CacheException;

/**
 * Created by Fidel on 2017/5/12.
 */
public interface CacheManager {

    public <K, V> Cache<K, V> getCache(String name) throws CacheException;
}
