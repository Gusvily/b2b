package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * Created by Fidel on 2017/4/25.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class DeliveryOrder extends BaseModel {

    public static final String TABLE_NAME = "delivery_order";

    private Long orderId;
    private Integer deliveryType;
    private Integer deliveryStatus;
    private Long deliveryTargetId;
    private Integer deliveryNumber;
    private Date deliveryDate;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
