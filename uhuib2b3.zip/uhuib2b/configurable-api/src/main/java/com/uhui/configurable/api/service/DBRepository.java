package com.uhui.configurable.api.service;

import com.uhui.configurable.api.Permission.Permission;
import com.uhui.configurable.api.Permission.model.RoleModel;
import com.uhui.configurable.api.model.BaseModel;
import com.uhui.configurable.api.workflow.utils.Pagination;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/27.
 */
@Repository
public interface DBRepository {

    <T extends BaseModel> T getById(Class<T> clz, Integer id);

    <T extends BaseModel> T getById(Class<T> clz, Integer id, boolean logicDeleted);

    <T extends BaseModel> T getById(Class<T> clz, Long id);

    <T extends BaseModel> T getById(Class<T> clz, Long id, boolean logicDeleted);

    <T extends BaseModel> T getByOthers(Class<T> clz, List<String> where);

    Long create(BaseModel model);

    Long create(String table, BaseModel model);

    int update(Long id, BaseModel model);

    int updateColumn(Long id, String tableName, String columnName, Object columnValue);

    int delete(Long id, String tableName);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, Permission permission, RoleModel instance);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, Permission permission, RoleModel instance);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, String[] orderBy);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, String[] orderBy, Permission permission, RoleModel instance);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, Permission permission, RoleModel instance);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, String[] orderBy);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, String[] orderBy, Permission permission, RoleModel instance);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, String[] orderBy);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, String[] orderBy, Permission permission, RoleModel instance);

    /**
     * 复杂查询，须注意 现阶段使用者必须自己在查询条件中维护 logic_deleted 字段来保证结果的正确性
     */
    <T> Pagination<T> query(Pagination<T> page,
                            String table,
                            String[] select,
                            Map<String, String> leftJoin,
                            List<String> where,
                            String[] groupBy,
                            String[] orderBy);

    List<Map<String, Object>> executeQuery(String sql);

}
