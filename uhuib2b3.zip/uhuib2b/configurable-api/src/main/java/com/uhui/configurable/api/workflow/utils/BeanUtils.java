package com.uhui.configurable.api.workflow.utils;

import com.alibaba.dubbo.common.utils.StringUtils;
import org.apache.log4j.Logger;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Fidel on 2017/3/27.
 */
public class BeanUtils {
    public static final String UNDERLINE = "_";
    private static final Logger LOGGER = Logger.getLogger(BeanUtils.class);

    public <T> T mapToObject(Map<String, Object> map, Class<T> beanClass, String keySeparator) {
        try {
            return mapToObject(map, beanClass.newInstance(), keySeparator);
        } catch (Exception e) {
            LOGGER.error("Map object can't cast to target Bean.", e);
            return null;
        }
    }

    public <T> T mapToObject(Map<String, Object> map, T instance, String keySeparator) {
        if (map == null) {
            return null;
        }
        if (instance == null) {
            return null;
        }
        try {
            Map<String, Object> convertedMap = new HashMap();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (StringUtils.isNotEmpty(keySeparator)) {
                    key = convertToSetKey(key, keySeparator);
                }
                convertedMap.put(key, value);
            }
            CastUtils castUtils = new CastUtils();
            for (Method method : instance.getClass().getMethods()) {
                Object value = convertedMap.get(method.getName());
                if (value != null) {
                    Class paramClass = method.getParameterTypes()[0];
                    if (!value.getClass().equals(paramClass)) {
                        value = castUtils.cast(paramClass, value);
                    }
                    method.invoke(instance, value);
                }
            }
            return instance;
        } catch (Exception e) {
            LOGGER.error("Map object can't cast to target Bean.", e);
            return null;
        }
    }

    public Map<String, Object> objectToMap(Object obj, String keySeparator) {
        return objectToMap(obj, keySeparator, false);
    }

    public Map<String, Object> objectToMap(Object obj, String keySeparator, boolean convertNullValue) {
        if (obj == null)
            return null;
        try {
            Map<String, Object> map = new HashMap<>();
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();
                if (key.compareToIgnoreCase("class") == 0) {
                    continue;
                }
                Method getter = property.getReadMethod();
                Object value = getter != null ? getter.invoke(obj) : null;
                if (convertNullValue || value != null) {

                    map.put(convertToColumn(key, keySeparator), value);
                }
            }
            return map;
        } catch (Exception e) {
            LOGGER.error("Bean can't cast to map.", e);
            return null;
        }
    }

    public Map<String, Object> convertMap(Map<String, Object> map, String keySeparator) {
        return convertMap(map, keySeparator, HashMap.class);
    }

    public <T extends Map> T convertMap(Map<String, Object> map, String keySeparator, Class<T> beanClass) {
        if (map == null) {
            return null;
        }
        try {
            T convertedMap = beanClass.newInstance();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (StringUtils.isNotEmpty(keySeparator)) {
                    key = convertKey(key, keySeparator);
                }
                convertedMap.put(key, value);
            }
            return convertedMap;
        } catch (Exception e) {
            LOGGER.error("Map object can't convert to target map.", e);
            return null;
        }
    }

    private String convertKey(String key, String keySeparator) {
        if (StringUtils.isEmpty(key)) {
            return "";
        }
        StringBuilder sb = new StringBuilder(key);
        Matcher mc = Pattern.compile(keySeparator).matcher(key);
        int i = 0;
        while (mc.find()) {
            int position = mc.end() - (i++);
            sb.replace(position - 1, position + 1, sb.substring(position, position + 1).toUpperCase());
        }
        return sb.toString();
    }

    private String convertToColumn(String key, String keySeparator) {
        if (StringUtils.isEmpty(key)) {
            return "";
        }
        int len = key.length();
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char c = key.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(keySeparator);
                sb.append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private String convertToSetKey(String key, String keySeparator) {
        if (StringUtils.isEmpty(key)) {
            return "";
        }
        StringBuilder sb = new StringBuilder(key);
        Matcher mc = Pattern.compile(keySeparator).matcher(key);
        int i = 0;
        while (mc.find()) {
            int position = mc.end() - (i++);
            sb.replace(position - 1, position + 1, sb.substring(position, position + 1).toUpperCase());
        }
        sb.replace(0, 1, sb.substring(0, 1).toUpperCase());
        return "set" + sb.toString();
    }
}
