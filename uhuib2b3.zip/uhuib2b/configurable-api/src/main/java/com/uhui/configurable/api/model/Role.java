package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/5/15.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Role extends BaseModel {

    public static final String TABLE_NAME = "role";

    private Long companyId;
    private String name;
    private String description;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
