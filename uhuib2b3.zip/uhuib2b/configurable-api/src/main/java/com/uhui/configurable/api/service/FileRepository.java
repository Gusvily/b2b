package com.uhui.configurable.api.service;

import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

/**
 * Created by Fidel on 2017/4/20.
 */
public interface FileRepository {

    String store(String type, String[] subTypes, MultipartFormDataInput input, String field, String fileName);

    String confirm(String realFilePath);
}
