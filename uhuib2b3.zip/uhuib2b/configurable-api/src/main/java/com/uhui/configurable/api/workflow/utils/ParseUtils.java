package com.uhui.configurable.api.workflow.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Fidel on 2017/3/21.
 */
public class ParseUtils {

    public static final String PARSE_OBJECT_SEPARATOR = "\\.";
    public static final String PARSE_CONSTANT_SEPARATOR = ":";
    public static final String PARSE_SPECIAL_SEPARATOR = "#";
    public static final String PARSE_SPECIAL_NOT_NULL_SEPARATOR = "\\|";

    public static final String PARSE_SPECIAL_TYPE_STRING = "string";
    public static final String PARSE_SPECIAL_TYPE_CLASS = "class";
    public static final String PARSE_SPECIAL_TYPE_ARRAY = "array";
    public static final String PARSE_SPECIAL_TYPE_LIST = "list";
    public static final String PARSE_SPECIAL_TYPE_MAP = "map";
    public static final String PARSE_SPECIAL_TYPE_NULL = "null";
    public static final String PARSE_SPECIAL_TYPE_REF = "ref";
    public static final String PARSE_SPECIAL_TYPE_INT = "int";
    public static final String PARSE_SPECIAL_TYPE_NOT_NULL = "notNull";
    public static final String PARSE_SPECIAL_TYPE_LOCAL = "local";

    public static final Pattern PATTERN_PARSE_SPECIAL_REF = Pattern.compile("REF\\{([^}]+)\\}");

    public Object parseSpecialField(String complexKey, Map<String, Object> processingStack) {
        if (complexKey == null) {
            return null;
        }
        if (complexKey.indexOf(PARSE_SPECIAL_SEPARATOR) < 0) {
            return null;
        }
        try {
            String[] keyValueArray = complexKey.split(PARSE_SPECIAL_SEPARATOR, 2);
            switch (keyValueArray[0]) {
                case PARSE_SPECIAL_TYPE_STRING:
                    return parseSpecialRef(keyValueArray[1], processingStack);
                case PARSE_SPECIAL_TYPE_CLASS:
                    return Class.forName(keyValueArray[1]);
                case PARSE_SPECIAL_TYPE_ARRAY:
                    JSONArray jsonArray = JSON.parseArray(keyValueArray[1]);
                    if (jsonArray.size() == 0) {
                        throw new BusinessException(BusinessExceptionType.LOGIC,
                                "Parse array failed, missed array content, array size = 0.");
                    }
                    Class arrayClass = jsonArray.get(0).getClass();
                    Object array = Array.newInstance(arrayClass, jsonArray.size());
                    for (int i = 0; i < jsonArray.size(); i++) {
                        Object item = jsonArray.get(i);
                        if (item instanceof String) {
                            String itemStr = (String) item;
                            if (itemStr.startsWith(PARSE_SPECIAL_TYPE_REF + PARSE_SPECIAL_SEPARATOR)) {
                                item = parseSpecialField(itemStr, processingStack);
                            }
                        }
                        if (item instanceof String) {
                            String itemStr = (String) item;
                            item = parseSpecialRef(itemStr, processingStack);
                        }
                        Array.set(array, i, item);
                    }
                    return array;
                case PARSE_SPECIAL_TYPE_LIST:
                    JSONArray jsonList = JSON.parseArray(keyValueArray[1]);
                    List list = new ArrayList();
                    for (int i = 0; i < jsonList.size(); i++) {
                        Object item = jsonList.get(i);
                        if (item instanceof String) {
                            String itemStr = (String) item;
                            if (itemStr.startsWith(PARSE_SPECIAL_TYPE_REF + PARSE_SPECIAL_SEPARATOR)) {
                                item = parseSpecialField(itemStr, processingStack);
                            }
                        }
                        if (item instanceof String) {
                            String itemStr = (String) item;
                            item = parseSpecialRef(itemStr, processingStack);
                        }
                        list.add(item);
                    }
                    return list;
                case PARSE_SPECIAL_TYPE_MAP:
                    Map map = JSON.parseObject(keyValueArray[1], Map.class);
                    for (Object entryObject : map.entrySet()) {
                        if (entryObject instanceof Map.Entry) {
                            Map.Entry entry = (Map.Entry) entryObject;
                            Object value = entry.getValue();
                            if (value instanceof String) {
                                String itemStr = (String) value;
                                if (itemStr.startsWith(PARSE_SPECIAL_TYPE_REF + PARSE_SPECIAL_SEPARATOR)) {
                                    value = parseSpecialField(itemStr, processingStack);
                                    map.put(entry.getKey(), value);
                                }
                            }
                            if (value instanceof String) {
                                String valueStr = (String) value;
                                value = parseSpecialRef(valueStr, processingStack);
                                map.put(entry.getKey(), value);
                            }
                        }
                    }
                    return map;
                case PARSE_SPECIAL_TYPE_NULL:
                    return null;
                case PARSE_SPECIAL_TYPE_REF:
                    Object result = null;
                    try {
                        result = parseStaticField(keyValueArray[1]);
                    } catch (Exception e) {
                    }
                    if (result == null) {
                        try {
                            result = parseObject(processingStack, keyValueArray[1]);
                        } catch (Exception e) {
                        }
                    }
                    return result;
                case PARSE_SPECIAL_TYPE_INT:
                    return Integer.valueOf(keyValueArray[1]);
                case PARSE_SPECIAL_TYPE_NOT_NULL:
                    if (keyValueArray[1] != null) {
                        String[] valueNames = keyValueArray[1].split(PARSE_SPECIAL_NOT_NULL_SEPARATOR);
                        for (int i = 0; i < valueNames.length; i++) {
                            Object value = parseObject(processingStack, valueNames[i]);
                            if (value != null) {
                                return value;
                            }
                        }
                        return null;
                    }
                case PARSE_SPECIAL_TYPE_LOCAL:
                    return processingStack.get(keyValueArray[1]);
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public String parseSpecialRef(String string, Map<String, Object> processingStack) {
        Matcher matcher = PATTERN_PARSE_SPECIAL_REF.matcher(string);
        StringBuffer su = new StringBuffer();
        while (matcher.find()) {
            String value = null;
            try {
                value = parseStaticField(matcher.group(1)).toString();
            } catch (Exception e) {
            }
            if (value == null) {
                try {
                    value = parseObject(processingStack, matcher.group(1)).toString();
                } catch (Exception e) {
                }
            }
            matcher.appendReplacement(su, value);
        }
        matcher.appendTail(su);
        return su.toString();
    }

    public Object parseStaticField(String complexKey) {
        if (complexKey == null) {
            return null;
        }
        if (complexKey.indexOf(PARSE_CONSTANT_SEPARATOR) < 0) {
            return null;
        }

        try {
            String[] constantKeyArray = complexKey.split(PARSE_CONSTANT_SEPARATOR);
            Class targetClass = null;
            for (int i = 0; i < constantKeyArray.length; i++) {
                if (i == 0) {
                    String className = constantKeyArray[i];
                    targetClass = Class.forName(className);
                    continue;
                }
                String fieldName = constantKeyArray[i];
                Field targetField = targetClass.getField(fieldName);
                if (i == (constantKeyArray.length - 1)) {
                    return targetField.get(null);
                } else {
                    targetClass = targetField.get(null).getClass();
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public Object parseObject(Object targetObject, String complexKey) {
        if (targetObject == null || complexKey == null) {
            return targetObject;
        }
        String[] keyArray = complexKey.split(PARSE_OBJECT_SEPARATOR);
        Object result = targetObject;
        try {
            for (int i = 0; i < keyArray.length; i++) {
                Class resClass = result.getClass();
                if (resClass.isArray()) {
                    try {
                        int index = Integer.parseInt(keyArray[i]);
                        result = Array.get(result, index);
                        continue;
                    } catch (Exception e) {
                        return null;
                    }
                }
                Method getMethod = null;
                try {
                    getMethod = resClass.getMethod("get", int.class);
                } catch (NoSuchMethodException e) {
                }
                if (getMethod == null) {
                    try {
                        getMethod = resClass.getMethod("get", Object.class);
                    } catch (NoSuchMethodException e) {
                    }
                }
                if (getMethod == null) {
                    String getMethodName = "get" + keyArray[i].substring(0, 1).toUpperCase() + keyArray[i].substring(1);
                    for (Class<?> clazz = resClass; clazz != Object.class; clazz = clazz.getSuperclass()) {
                        try {
                            getMethod = clazz.getMethod(getMethodName);
                            break;
                        } catch (Exception e) {
                        }
                    }
                }
                if (getMethod == null) {
                    return null;
                }

                if (getMethod.getParameterTypes().length == 1) {
                    if (getMethod.getParameterTypes()[0].equals(int.class)) {
                        result = getMethod.invoke(result, Integer.parseInt(keyArray[i]));
                    } else {
                        result = getMethod.invoke(result, keyArray[i]);
                    }
                } else if (getMethod.getParameterTypes().length == 0) {
                    result = getMethod.invoke(result);
                }
            }
        } catch (Exception e) {
            return null;
        }
        return result;
    }
}
