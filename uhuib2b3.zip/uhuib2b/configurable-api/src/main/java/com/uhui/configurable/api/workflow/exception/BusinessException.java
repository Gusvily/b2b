package com.uhui.configurable.api.workflow.exception;

/**
 * Created by Fidel on 2017/4/10.
 */
public class BusinessException extends RuntimeException {
    private final BusinessExceptionType type;

    public BusinessException(String message) {
        super(message);
        this.type = BusinessExceptionType.UNKNOWN;
    }

    public BusinessException(BusinessExceptionType type, String message) {
        super(message);
        this.type = type;
    }

    public BusinessException(BusinessExceptionType type, String message, Throwable cause) {
        super(message, cause);
        this.type = type;
    }

    public BusinessExceptionType getType() {
        return this.type;
    }

    public static BusinessException buildBusinessException(String message) {
        return buildBusinessException(BusinessExceptionType.UNKNOWN, message);
    }

    public static BusinessException buildBusinessException(String type, String message) {
        return buildBusinessException(BusinessExceptionType.type(type), message);
    }

    public static BusinessException buildBusinessException(BusinessExceptionType type, String message) {
        return new BusinessException(type, message);
    }

    public static BusinessException buildBusinessException(String type, String message, Throwable cause) {
        return buildBusinessException(BusinessExceptionType.type(type), message, cause);
    }

    public static BusinessException buildBusinessException(BusinessExceptionType type, String message, Throwable cause) {
        return new BusinessException(type, message, cause);
    }

    public static void throwBusinessException(String message) {
        throw buildBusinessException(BusinessExceptionType.UNKNOWN, message);
    }

    public static void throwBusinessException(String type, String message) {
        throw buildBusinessException(BusinessExceptionType.type(type), message);
    }

    public static void throwBusinessException(BusinessExceptionType type, String message) {
        throw new BusinessException(type, message);
    }

    public static void throwBusinessException(String type, String message, Throwable cause) {
        throw buildBusinessException(BusinessExceptionType.type(type), message, cause);
    }

    public static void throwBusinessException(BusinessExceptionType type, String message, Throwable cause) {
        throw new BusinessException(type, message, cause);
    }
}
