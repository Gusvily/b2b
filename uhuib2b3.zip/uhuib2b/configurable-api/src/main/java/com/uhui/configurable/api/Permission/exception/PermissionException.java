package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/12.
 */
public class PermissionException extends RuntimeException {


    public PermissionException() {
        super();
    }

    public PermissionException(String message) {
        super(message);
    }

    public PermissionException(Throwable cause) {
        super(cause);
    }

    public PermissionException(String message, Throwable cause) {
        super(message, cause);
    }
}
