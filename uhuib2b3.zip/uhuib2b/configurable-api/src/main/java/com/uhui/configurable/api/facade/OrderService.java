package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/4/17.
 */
@Path("order")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface OrderService {

    /**
     * create order information
     *
     * @param params should include productId, selectedMouth and selectedAmount
     * @return
     */
    @POST
    @Path("createOrderInfo")
    ProcessingResult createOrderInfo(Map<String, Object> params);

    /**
     * create order
     *
     * @param params should include productId, selectedMouth，selectedAmount and all orderInfo fields if it's not null.
     * @return
     */
    @POST
    @Path("createOrder")
    ProcessingResult createOrder(@CookieParam("special_id") String specialId, Map<String, Object> params);

}
