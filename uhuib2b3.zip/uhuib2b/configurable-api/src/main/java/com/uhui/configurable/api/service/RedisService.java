package com.uhui.configurable.api.service;

import redis.clients.jedis.JedisCommands;

/**
 * Created by Fidel on 2017/3/15.
 */
public interface RedisService extends JedisCommands {

    String INSERT_LOCK_PREFIX = "insert_lock_";
    Integer INSERT_LOCK_LIFECYCLE = 5;

    Boolean addInsertLock(String specialId);

    Boolean hasInsertLock(String specialId);

    Boolean exists(byte[] key);

    String set(byte[] key, byte[] value);

    Long expire(byte[] key, int seconds);

    byte[] get(byte[] key);
}
