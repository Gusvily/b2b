package com.uhui.configurable.api.workflow;

import java.util.Map;

/**
 * Created by Fidel on 2017/2/28.
 */
public interface Processor {

    String PROCESOR_INPUT_KEY = "input";
    String PROCESOR_OUTPUT_KEY = "output";
    String PROCESOR_PROCESSING_CHAIN_KEY = "processingChain";
    String PROCESOR_JSONP_METHOD_KEY = "jsonpMethod";

    void setInputNames(String[] inputNames);

    Object process(final Map<String, SpringBean> dependencies, Object[] args);

}
