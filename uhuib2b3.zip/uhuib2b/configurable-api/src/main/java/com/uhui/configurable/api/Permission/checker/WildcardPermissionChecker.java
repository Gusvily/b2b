package com.uhui.configurable.api.Permission.checker;

import com.uhui.configurable.api.utils.CollectionUtils;
import lombok.Data;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Fidel on 2017/5/16.
 */
@Data
public class WildcardPermissionChecker implements PermissionChecker<String, String> {

    public static final String WILDCARD_TOKEN = "*";
    public static final String PART_DIVIDER_TOKEN = ":";
    public static final String SUBPART_DIVIDER_TOKEN = ",";
    public static final boolean DEFAULT_CASE_SENSITIVE = false;

    private boolean caseSensitive;

    public WildcardPermissionChecker() {
        this(DEFAULT_CASE_SENSITIVE);
    }

    public WildcardPermissionChecker(boolean caseSensitive) {
        this.caseSensitive = caseSensitive;
    }

    @Override
    public PermissionMatcher checkPermission(String permission, String resourcePermission) {
        PermissionMatchType permissionMatchType = implies(permission, resourcePermission);
        if (permissionMatchType != PermissionMatchType.MISMATCHING) {
            return new PermissionMatcher(permissionMatchType, permission);
        }
        return new PermissionMatcher(PermissionMatchType.MISMATCHING, null);
    }

    @Override
    public PermissionMatcher checkPermissions(List<String> permissions, String resourcePermission) {
        for (String permission : permissions) {
            PermissionMatchType permissionMatchType = implies(permission, resourcePermission);
            if (permissionMatchType != PermissionMatchType.MISMATCHING) {
                return new PermissionMatcher(permissionMatchType, permission);
            }
        }
        return new PermissionMatcher(PermissionMatchType.MISMATCHING, null);
    }

    public PermissionMatchType implies(String permission, String permissionFromResource) {

        List<Set<String>> permissionParts = buildParts(permission, caseSensitive);
        List<Set<String>> permissionFromResourceParts = buildParts(permissionFromResource, caseSensitive);

        int i = 0;
        for (Set<String> permissionFromResourcePart : permissionFromResourceParts) {
            // If this permission has less parts than the resource permission, everything after the number of parts contained
            // in this permission is automatically implied, so return true
            if (permissionParts.size() - 1 < i) {
                return PermissionMatchType.MATCHING;
            } else {
                Set<String> permissionPart = permissionParts.get(i);
                if (!permissionPart.contains(WILDCARD_TOKEN) && !permissionPart.containsAll(permissionFromResourcePart)) {
                    return PermissionMatchType.MISMATCHING;
                }
                i++;
            }
        }

        // If this permission has more parts than the resource permission, only imply it if all of the resource permission are wildcards
        for (; i < permissionParts.size(); i++) {
            Set<String> part = permissionParts.get(i);
            if (!part.contains(WILDCARD_TOKEN)) {
                return PermissionMatchType.CONDITIONAL_MATCHING;
            }
        }

        return PermissionMatchType.MATCHING;
    }

    private List<Set<String>> buildParts(String wildcardString, boolean caseSensitive) {
        if (wildcardString == null || wildcardString.trim().length() == 0) {
            throw new IllegalArgumentException("Wildcard string cannot be null or empty. Make sure permission strings are properly formatted.");
        }

        wildcardString = wildcardString.trim( );

        String[] originParts = wildcardString.split(PART_DIVIDER_TOKEN);

        List<Set<String>> parts = new ArrayList<>();
        for (String part : originParts) {
            Set<String> subParts = CollectionUtils.asSet(part.split(SUBPART_DIVIDER_TOKEN));
            if (!caseSensitive) {
                subParts = lowercase(subParts);
            }
            if (subParts.isEmpty()) {
                subParts.add(WILDCARD_TOKEN);
            }
            parts.add(subParts);
        }

        if (parts.isEmpty()) {
            throw new IllegalArgumentException("Wildcard string cannot contain only dividers. Make sure permission strings are properly formatted.");
        }
        return parts;
    }

    private Set<String> lowercase(Set<String> subparts) {
        Set<String> lowerCasedSubparts = new LinkedHashSet<String>(subparts.size());
        for (String subpart : subparts) {
            lowerCasedSubparts.add(subpart.toLowerCase());
        }
        return lowerCasedSubparts;
    }
}
