package com.uhui.configurable.api.workflow;

/**
 * Created by Fidel on 2017/2/27.
 */
public interface WorkFlow {

    Processor findProcessor(String methodName);

}
