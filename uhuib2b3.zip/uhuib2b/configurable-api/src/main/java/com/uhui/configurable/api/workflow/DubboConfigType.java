package com.uhui.configurable.api.workflow;

/**
 * Created by Fidel on 2017/3/10.
 */
public enum DubboConfigType {

    STRING("string", String.class),
    INT("int", Integer.class),
    BOOLEAN("boolean", Boolean.class),
    REFERENCE("reference", Object.class);

    private final String type;
    private final Class clz;

    DubboConfigType(String type, Class clz) {
        this.type = type;
        this.clz = clz;
    }

    public Class clz(){
        return this.clz;
    }

    public static Class clz(String type){
        for (DubboConfigType dubboConfigType : DubboConfigType.values()) {
            if (dubboConfigType.type.equals(type)) {
                return dubboConfigType.clz;
            }
        }
        return null;
    }
}
