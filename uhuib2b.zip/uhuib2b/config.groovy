environments {
    dev {
        DB {
            JDBC_URL = 'jdbc:mysql://127.0.0.1:3306/uhuiapp?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true'
            USER = 'root'
            PASSWORD = 'root'
        }
        REDIS {
            HOST = 'localhost'
            PORT = '6379'
        }
        DUBBO {
            REGISTRY {
                ADDRESS = 'zookeeper://127.0.0.1:2181'
            }
        }
        UPLOAD {
            FILE {
                ROOT = 'd:/FileRepositoryTest'
            }
        }
    }

    test {
        DB {
            JDBC_URL = 'jdbc:mysql://mysql.yfq.com:3306/test_uhuiapp?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true'
            USER = 'test_uhuser'
            PASSWORD = 'yfq2017yfq'
        }
        REDIS {
            HOST = 'redis-test.yfq.com'
            PORT = '6379'
        }
        DUBBO {
            REGISTRY {
                ADDRESS = 'zookeeper://zookeeper-test.yfq.com:2181'
            }
        }
        UPLOAD {
            FILE {
                ROOT = 'd:/FileRepositoryTest'
            }
        }
    }

    externaltest {
        DB {
            JDBC_URL = 'jdbc:mysql://127.0.0.1:3306/uhuiapp?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true'
            USER = 'uhuser'
            PASSWORD = 'YFQ2017@yfq'
        }
        REDIS {
            HOST = 'localhost'
            PORT = '6379'
        }
        DUBBO {
            REGISTRY {
                ADDRESS = 'zookeeper://localhost:2181'
            }
        }
        UPLOAD {
            FILE {
                ROOT = '/opt/wwwroot/images'
            }
        }
    }
}