/**
 * Created by Administrator on 2017/6/5.
 */
//验证码过期时间设置
    var time = 5;//验证码倒计时时间
    var timer = '';
    var regEmail = /^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/;
    var regPhone = /^1[34578]\d{9}$/;
    var phone = $('.phone-num').text();
    var emailNum = $('.email-num').text();
    var data = {};
    var dataUrl = {};
    //表示手机/邮箱是否可用  true/false
    var verifyCode = false;
    //表示验证码是否发送成功
    var flag = {};
    var fromValidator = {
        rules: {
            debug:true,
            email: {
                required: true,
                email: true
            },
            phoneNumber:{
                required: true,
                isPhoneNumber:true
            },
            emailCode: {
                required: true,
                isPhoneCode:true
            },
            phoneCode: {
                required: true,
                isPhoneCode:true
            },
            cipher: {
                required: true,
                isPassword: true
            },
            oldPassword: {
                required: true,
                isPassword: true,
                minlength: 8,
                maxlength: 20
            },
            password: {
                required: true,
                minlength: 8,
                maxlength: 20,
                isPassword: true
            },
            rePassword: {
                required: true,
                minlength: 8,
                maxlength: 20,
                equalTo:'#password',
                isPassword: true
            },
            companyName:{
                required: true
            }
        },
        invalidHandler:function () {
            return false;
        },
        submitHandler:function () {
            return false;
        },
        errorElement: "span",
        errorPlacement: function (error, element) {
            /*element.parent().siblings('.validate-container').addClass('validate-error').removeClass('validate-ok');
            element.parent().addClass("has-feedback");*/
            if (element.prop("type") === "checkbox") {
                error.insertAfter(element.parent("label"));
            } else {
                if ($('.validate-container').find("span")){
                    $(element).parent().siblings('.validate-container').append(error).find("span").addClass('glyphicon glyphicon-remove-sign');
                }
            }
        },
        //格式验证成功后验证重复
        success: function (label, element) {
            $(element).parent().siblings('.validate-container').find("span").addClass("glyphicon glyphicon-ok-sign");
            if ($("#email").val()){
                data.email = $("#email").val();
                dataUrl.url = '/services/user/check/available/email';
                //验证手机、邮箱是否可用
                ajax(dataUrl.url,data,function (ProcessingResult) {
                    if (ProcessingResult.data[0]==0){
                        $(element).parent().siblings('.validate-container').removeClass('validate-ok').addClass('validate-error');
                        if($("#email").val()){
                            $(element).parent().siblings('.validate-container').find('span').text('邮箱被占用');
                        }else {
                            $(element).parent().siblings('.validate-container').find('span').text('手机号被占用');
                        }
                    }else {
                        $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
                        $(element).parent().siblings('.validate-container').find("span").addClass("glyphicon glyphicon-ok-sign");
                        //表示邮箱/手机号可用
                        verifyCode = true;
                    }
                });
            }
            if ($("#companyName").val()){
                ajax('/services/user/check/available/mobile',{name : $("#companyName").val()},function (ProcessingResult) {
                    if (ProcessingResult.data[0]==0){
                        $(element).parent().siblings('.validate-container').removeClass('validate-ok').addClass('validate-error');
                        $(element).parent().siblings('.validate-container').find('span').text('公司简称被占用');
                    }else {
                        $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
                        $(element).parent().siblings('.validate-container').find("span").addClass("glyphicon glyphicon-ok-sign");
                        //表示邮箱/手机号可用
                        verifyCode = true;
                    }
                });
            }
            if ($("#phoneNumber").val()){
                data.mobilePhone = $("#phoneNumber").val();
                dataUrl.url = '/services/user/check/available/mobile';
                //验证手机、邮箱是否可用
                ajax(dataUrl.url,data,function (ProcessingResult) {
                    if (ProcessingResult.data[0]==0){
                        $(element).parent().siblings('.validate-container').removeClass('validate-ok').addClass('validate-error');
                        if($("#email").val()){
                            $(element).parent().siblings('.validate-container').find('span').text('邮箱被占用');
                        }else {
                            $(element).parent().siblings('.validate-container').find('span').text('手机号被占用');
                        }
                    }else {
                        $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
                        $(element).parent().siblings('.validate-container').find("span").addClass("glyphicon glyphicon-ok-sign");
                        //表示邮箱/手机号可用
                        verifyCode = true;
                    }
                });
            }
        },
        highlight: function (element, errorClass, validClass) {
            $(element).parent().addClass("has-error").removeClass("has-success");
            $(element).parent().siblings('.validate-container').find('span').removeClass('glyphicon-ok-sign').addClass('glyphicon-remove-sign');
            $(element).parent().siblings('.validate-container').addClass('validate-error').removeClass('validate-ok');
            /*if (element.parentElement.className.indexOf("date form_time") < 0)
                $(element).next("span").addClass("glyphicon-remove").removeClass("glyphicon-ok");*/
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).parent().addClass("has-success").removeClass("has-error");
            $(element).parent().siblings('.validate-container').find('span').removeClass('glyphicon-remove-sign').addClass('glyphicon-ok-sign');
            $(element).parent().siblings('.validate-container').addClass('validate-ok').removeClass('validate-error');
            /*if (element.parentElement.className.indexOf("date form_time") < 0)
                $(element).next("span").addClass("glyphicon-ok").removeClass("glyphicon-remove");*/
        }
        /*submitHandler: function (form) { //序列化表单提交
            var data = $(form).serializeJson();
            console.log(data);
        }*/
    };
    jQuery.validator.addMethod("isPassword", function (value, element) {
        var reg = /^[0-9A-Za-z]{8,20}$/;
        return this.optional(element) || (reg.test(value));
    }, '8~20位字符，包含字母和数字');
    jQuery.validator.addMethod("isPhoneNumber", function (value, element) {
        var reg = /^((13[0-9])|(15[^4])|(18[0-9])|(17[0-8])|(147,145))\d{8}$/;
        return this.optional(element) || (reg.test(value));
    }, '请输入中国合法手机号');
    jQuery.validator.addMethod("isPhoneCode", function (value, element) {
        var reg = /^\d{6}$/ig;
        return this.optional(element) || (reg.test(value));
    }, '请输入6位数字验证码');

    $('.form-horizontal').validate(fromValidator);
    $('.passWord').validate(fromValidator);
    $('.Phone').validate(fromValidator);
    $('.company').validate(fromValidator);
    //验证码倒计时
    function timeout () {
        //每次进入把原来timer清除掉
        //倒计时发送验证码
        clearInterval(timer);
        if(regEmail.test($("#email").val()) || regPhone.test($("#phoneNumber").val()) || phone || emailNum){
            $(".bt").attr("disabled","true");
            $(".bt").text(time+"s后重新发送");
            timer=setInterval(function (){
                if(time==0){
                    clearInterval(timer);
                    timer=null;
                    time = 5;
                    $(".bt").removeAttr("disabled");
                    $(".bt").text("发送验证码");
                }
                else{
                    time--;
                    $(".bt").text(time+"s后重新发送");
                }
            }, 1000);
        }
        //收集数据发ajax
        /*if(regEmail.test(email)){
            data.emailAddress = email;
            dataUrl.url = '/services/user/security/code/email';
        }else if(regPhone.test(phoneNumber)){
            data.mobilePhoneNumber = phoneNumber;
            dataUrl.url = '/services/user/security/code/mobile';
        }else if(phone){
            data.phone = phone;
        }else {
            data.emailNum = emailNum;
        }
        ajax(dataUrl.url,data,function (ProcessingResult) {
            code = ProcessingResult.code;
        })*/
    };
    //封装的ajax函数
    function ajax(url,data,successCallbak,errorCallback) {
        $.ajax({
            type: "POST",
            url: url,
            data: data,
            success: successCallbak,
            error:errorCallback
        });
    }
    //发送邮箱验证码请求
    $('.emailCode').click(function () {
        if (verifyCode){
            data.emailAddress = $("#email").val();
            dataUrl.url = '/services/user/security/code/email';
            ajax(dataUrl.url,data,function (ProcessingResult) {
                flag.email = ProcessingResult.data[0];
            });
            timeout ();
        }
    });
    //发送手机验证码请求
    $('.phoneCode').click(function () {
        if (verifyCode){
            data.mobilePhoneNumber = $("#phoneNumber").val();
            dataUrl.url = '/services/user/security/code/mobile';
            ajax(dataUrl.url,data,function (ProcessingResult) {
                flag.phone = ProcessingResult.data[0];
            });
            timeout ();
        }
    });
