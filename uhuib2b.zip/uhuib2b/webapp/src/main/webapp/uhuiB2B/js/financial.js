/**
 * Created by Administrator on 2017/5/23.
 */
$(function () {
    var currentPageNumber =1;
    var string = '';
    //分页
    $("nav").find("li a").on('click', function () {
        var lis = $("nav li");
        var index = lis.index($(this).parent());
        if ($(this).parent().hasClass('disabled')) {
            return;
        }
        if (index !== currentPageNumber + 1) {
            if (index >= 2 && index < lis.length - 2) {
                currentPageNumber = index - 1;
            } else {
                if (index === 0) {
                    currentPageNumber = 1;
                } else if (index === 1) {
                    currentPageNumber--;
                } else if (index === lis.length - 1) {
                    currentPageNumber = lis.length - 4
                } else if (index === lis.length - 2) {
                    currentPageNumber++;
                }
            }
            if (currentPageNumber === 1) {
                $("nav li:lt(2)").addClass('disabled')
            } else {
                $("nav li:lt(2)").removeClass('disabled')
            }
            var gtIndex = lis.length - 3;
            if (currentPageNumber === lis.length - 4) {
                $("nav li:gt(" + gtIndex + ")").addClass('disabled')
            } else {
                $("nav li:gt(" + gtIndex + ")").removeClass('disabled')
            }
            lis.removeClass('selected-page');
            lis.eq(currentPageNumber + 1).addClass('selected-page');
            $("#pageNumber").html(currentPageNumber);
            var page = {};
            page.pageNum = currentPageNumber;
            page.pageRow = 16;
            ajax(page);
        }
    });
    var tabBottomInnerH = $('body').innerHeight()- 400;
    $('.tab-bottom-inner').height(tabBottomInnerH);
    var tabBottomH = $('body').innerHeight()-292;
    $('.tab-bottom').height(tabBottomH);
    $(".tab-bottom-inner").mCustomScrollbar({
        theme: "minimal-dark"
    });
    for(var i = 0; i<20; i++){
        string += ' <tr><td>'+i+'</td><td>中国海油主营</td><td>2017/05/05 09:09:09</td><td>￥5000</td><td>收入</td></tr>'
    };
    $('.tab-bottom-inner table').append(string);
    $('.tab-bottom tr:even').addClass('border');
    //加载财务收入体现
    var zzz = {data:666};
    ajax(zzz);
    //加载第一页数据
    var firstRun = {
        currentPageNumber:currentPageNumber,
        pageSize : 16
    };
    ajax(firstRun);
    function ajax(obj) {
        $.ajax({
            type: "GET",
            url:'qqq',
            data:obj,
            datatype:'json',
            success:function (json) {
                var string = '';
                for (var i = 0; i<4; i++){
                    $.each( json[i], function(i, n){
                        arr.push(n)
                    });
                    todayData[i].innerHTML = arr[i];
                    yesterdayData[i].innerHTML = i;
                    totalData[i].innerHTML = i;
                }

                    $('.tab-left-right span').text('555');
                    $('.tab-right-top span').text("666");
                if (firstRun){
                    $('.tab-bottom-inner table').append(string);
                    firstRun = false;
                };
                if ( page){
                    alert(111);
                    console.log(url)
                };
            },
            error:function () {

            }
        })
    }
    //提现页面
    var withdrawalHeight = $('body').innerHeight()- 76;
    $('.withdrawal-content').height(withdrawalHeight);
    //左侧导航
    $('.sidebar li').on('click', function () {
        $('.sidebar li').removeClass('active');
        $(this).addClass('active');
    });
    // 点击提现按钮
    $('.deposit').click(function () {
        $('.debit').fadeIn();
        $('.debit').siblings().hide();
    });
    $('.glyphicon-arrow-left').click(function () {
        $('.withdrawal').hide();
        $('.financial-wrap').fadeIn();
    })
    //选择银行卡
    $('.td-wrap').click(function () {
        $('.td-wrap').removeClass('td-wrap-border');
        $(this).addClass('td-wrap-border');
        $('.rad').removeClass('rad-img');
        $(this).children('.rad').addClass('rad-img');
    })
    // 绑定银行卡跳转页面
    $('.debitBtn').click(function () {
        $('.withdrawal-bank').siblings().hide();
        $('.withdrawal-bank').show();
    })
    //点击提交获取信息
    $('.commit').click(function () {
        console.log($('.rad-img').parent().children('span').text());
        $('.successful').siblings().hide();
        $('.successful').fadeIn();
    })
});