/**
 * Created by Administrator on 2017/5/22.
 */
$(function(){
    var currentPageNumber = 1;
    $('#exampleInputName2').datetimepicker({
        language: "zh-CN",
        format: 'yyyy-mm-dd hh:ii',
        todayBtn: true,
        clearBtn: true,
        autoclose: true,
        minView: 0,
        minuteStep:1
    }).on("click",function(){
        $("#exampleInputName2").datetimepicker("setEndDate",$("#exampleInputEmail2").val());
    });
    $('#exampleInputEmail2').datetimepicker({
        language: "zh-CN",
        format: 'yyyy-mm-dd hh:ii',
        todayBtn: true,
        clearBtn: true,
        autoclose: true,
        minView: 0,
        minuteStep:1
    }).on("click",function(){
        $("#exampleInputEmail2").datetimepicker("setStartDate",$("#exampleInputName2").val());
    });
    //左侧导航
    $('.sidebar li').on('click', function () {
        $('.sidebar li').removeClass('active');
        $(this).addClass('active');
    });
    //分页1
    $(".paging1").find("li a").on('click', function () {
        var lis = $(".paging1 li");
        console.log(lis.size())
        var index = lis.index($(this).parent());
        if ($(this).parent().hasClass('disabled')) {
            return;
        }
        if (index !== currentPageNumber + 1) {
            if (index >= 2 && index < lis.length - 2) {
                currentPageNumber = index - 1;
            } else {
                if (index === 0) {
                    currentPageNumber = 1;
                } else if (index === 1) {
                    currentPageNumber--;
                } else if (index === lis.length - 1) {
                    currentPageNumber = lis.length - 4
                } else if (index === lis.length - 2) {
                    currentPageNumber++;
                }
            }
            if (currentPageNumber === 1) {
                $(".paging1 li:lt(2)").addClass('disabled')
            } else {
                $(".paging1 li:lt(2)").removeClass('disabled')
            }
            var gtIndex = lis.length - 3;
            if (currentPageNumber === lis.length - 4) {
                $(".paging1 li:gt(" + gtIndex + ")").addClass('disabled')
            } else {
                $(".paging1 li:gt(" + gtIndex + ")").removeClass('disabled')
            }
            lis.removeClass('selected-page');
            lis.eq(currentPageNumber + 1).addClass('selected-page');
            $(".pageNumber").html(currentPageNumber)
        }
        var page = {};
        page.pageNum = currentPageNumber;
        page.pageRow = 16;
        ajax(page);
    });
    //淡入淡出
    $(".detailsbtn").click(function(){
        $(".client,.client-head").hide();
        $(".client-deal").fadeIn();
    });
    $(".client-deal-head span").click(function(){
        $(".client-deal").hide();
        $(".client,.client-head").fadeIn();
    });
    //按钮全选全不选
    $('#checkedAllBtn').click(function () {
        $('.ipt').prop('checked', this.checked);
    });
    //同步更新checkedAllBtn
    $('.ipt').click(function () {
        $('#checkedAllBtn').prop('checked', $('.ipt:not(:checked)').length===0);
    });
    // 滚动条
    $(".clentSlider").mCustomScrollbar({
        theme: "minimal-dark"
    });
    $('.deal-log').height($('body').height()-500);
    $(".deal-log").mCustomScrollbar({
        theme: "minimal-dark"
    });
    //隔行变色
    $('.client-table-head tr:even').addClass('tr-bag');
    //搜索按钮
    $('.searchBtn').click(function () {
        // $.parseJSON( result );
        var iptVal = $.trim($('.form-control').val());
        var reg = /^[0-9]\d{9}$/;
        if(reg.test(iptVal) && iptVal){
            console.log(666);
            var iptVal = {orderID : iptVal};
            ajax(iptVal);
        }else {
            $('.ddh').attr('value','请输入10位有效数字');
            console.log("请输入10位有效数字");
        }
    });
    //筛选
    $('.screenBtn').click(function () {
        var start = $('#exampleInputName2').val();
        var end = $('#exampleInputEmail2').val();
        var orderTime = {
            start:start,
            end : end
        };
        ajax(orderTime);
    });
    //交易详情
    var firmName = '';
    $('.detailsbtn').click(function () {
        currentPageNumber = 1;
        var index = $('.detailsbtn').index($(this));
            firmName = $(this).parent().parent().find('td:eq(1)').text();
        console.log(firmName,111);
        console.log(index);
        var detailsbtn = {};
        detailsbtn.details=encodeURI(encodeURI(firmName));
        detailsbtn.currentPageNumber=currentPageNumber;
        console.log(detailsbtn);
        ajax(detailsbtn);
    });
    //分页2
    $(".paging2").find("li a").on('click', function () {
        var lis = $(".paging2 li");
        var index = lis.index($(this).parent());
        if ($(this).parent().hasClass('disabled')) {
            return;
        }
        if (index !== currentPageNumber + 1) {
            if (index >= 2 && index < lis.length - 2) {
                currentPageNumber = index - 1;
            } else {
                if (index === 0) {
                    currentPageNumber = 1;
                } else if (index === 1) {
                    currentPageNumber--;
                } else if (index === lis.length - 1) {
                    currentPageNumber = lis.length - 4
                } else if (index === lis.length - 2) {
                    currentPageNumber++;
                }
            }
            if (currentPageNumber === 1) {
                $(".paging2 li:lt(2)").addClass('disabled')
            } else {
                $(".paging2 li:lt(2)").removeClass('disabled')
            }
            var gtIndex = lis.length - 3;
            if (currentPageNumber === lis.length - 4) {
                $(".paging2 li:gt(" + gtIndex + ")").addClass('disabled')
            } else {
                $(".paging2 li:gt(" + gtIndex + ")").removeClass('disabled')
            }
            lis.removeClass('selected-page');
            lis.eq(currentPageNumber + 1).addClass('selected-page');
            $(".pageNumber").html(currentPageNumber);

        }
        console.log(firmName,666);
        var paging2 = {};
        paging2.currentPageNumber = currentPageNumber;
        paging2.pagesize = 16;
        paging2.firmName = firmName
        ajax(paging2);
    });
    //ajax交互
    function ajax(obj) {
        var url = 'rrr'+'?callback=?';
        $.ajax({
            type: "get",
            url: url,
            data:obj,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            datatype:"json",
            success: function(result){
                //首次请求
                if(firstRun){
                    return;
                };
                //分页请求
                if ( page){
                    alert(111);
                    console.log(url)
                };
                //时间差请求
                if(orderTime){
                    var len = 5;
                    var str = '';
                    for (var i=0; i<len ;i++){
                   var str = '<tr>'+
                        '<td>&nbsp;&nbsp;<input class="ipt" type="checkbox" /></td>'+
                            '<td><img src="images/location_qiaopai.png" alt="" style="width: 38px;">中国石油公司中国石公司</td>'+
                            '<td>10</td>'+
                            '<td>￥5,0000</td>'+
                        '<td>2017/04/27 16:27:25</td>'+
                        '<td>'+
                            '<button type="button" class="btn detailsbtn">'+
                                '<span class="glyphicon glyphicon-search"></span> 交易详情'+
                            '</button>'+
                       '</td>'+
                            '</tr>'
                    }
                    $('.client-table-head').append(str);
                };
                //订单号请求
                if(iptVal){

                }
                //navBtn请求
                if(detailsbtn){
                //     填充客户图片
                //    公司名称   客户编号  地区
                //    交易信息
                //    交易记录   首先要加载一页  然后填充
                }
            },
            error:function () {

            }
        });
    }
});