/**
 * Created by Administrator on 2017/6/4.
 */
$(function () {
   $('.leftBox ul').click(function () {
       $(this).addClass('bg').siblings().removeClass('bg');
   });




});
