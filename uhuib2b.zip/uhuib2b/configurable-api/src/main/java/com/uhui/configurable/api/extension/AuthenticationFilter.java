package com.uhui.configurable.api.extension;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.workflow.ProcessingResult;
import org.apache.log4j.Logger;
import org.jboss.resteasy.core.interception.PostMatchContainerRequestContext;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

/**
 * Created by Fidel on 2017/4/13.
 */
@Service
@Priority(Priorities.USER)
public class AuthenticationFilter implements ContainerRequestFilter {

    public static String TOKEN_PREFIX = "token_";
    private static final Logger LOGGER = Logger.getLogger(AuthenticationFilter.class);
    private static final String SPECIAL_ID_COOKIE_KEY = "special_id";
    private static final String[] EXCLUDING_URIS = new String[]{
            "/services/account/requestSecurityCode",
            "/services/account/login",
            "/services/WeiXin/signature",
            "/services/gas/price",
    };

    private JedisPool jedisPool;

    public void filter(ContainerRequestContext requestContext) throws IOException {
        try {
            PostMatchContainerRequestContext postMatchContainerRequestContext = (PostMatchContainerRequestContext) requestContext;
            String requestUri = postMatchContainerRequestContext.getHttpRequest().getUri().getPath();
            if (StringUtils.isEmpty(requestUri)) {
                responseAuthenticationFailed(requestContext);
            }
            if (!isExcludingURI(requestUri)) {
                Map<String, Cookie> cookies = requestContext.getCookies();
                Cookie specialIdCookie = cookies.get(SPECIAL_ID_COOKIE_KEY);
                String specialId = specialIdCookie.getValue();
                String userJsonString = jedisGet(specialId);
                String token = jedisGet(TOKEN_PREFIX + specialId);
                User user = JSON.parseObject(userJsonString, User.class);
                if (StringUtils.isEmpty(token) || user == null || !user.buildToken(specialId).equals(token)) {
                    responseAuthenticationFailed(requestContext);
                }
            }
        } catch (Throwable t) {
            responseAuthenticationFailed(requestContext);
        }
    }

    private boolean isExcludingURI(String requestUri) {
        for (int i = 0; i < EXCLUDING_URIS.length; i++) {
            if (requestUri.startsWith(EXCLUDING_URIS[i])) {
                return true;
            }
        }
        return false;
    }

    private void responseAuthenticationFailed(ContainerRequestContext requestContext) {
        LOGGER.info("authentication_failed happened.");
        ProcessingResult result = ProcessingResult.failed("authentication_failed");
        Response.ResponseBuilder builder = Response.ok(result, "application/json");
        requestContext.abortWith(builder.build());
    }

    private String jedisGet(String key) throws IOException {
        if (jedisPool == null) {
            buildRedisService();
        }
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.get(key);
        } catch (Exception e) {
            LOGGER.error("AuthenticationFilter read redis failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    private void buildRedisService() throws IOException {
        File dir = new File(System.getProperty("CONF_PATH"));
        File propertiesFile = new File(dir, "spring-base.properties");
        Properties properties = new Properties();
        properties.load(new FileInputStream(propertiesFile));
        String redisHost = properties.getProperty("REDIS.HOST");
        String redisPort = properties.getProperty("REDIS.PORT");
        if (StringUtils.isEmpty(redisHost)) {
            redisHost = "127.0.0.1";
        }
        if (StringUtils.isEmpty(redisPort)) {
            redisPort = "6379";
        }
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(20);
        config.setMaxIdle(10);

        jedisPool = new JedisPool(config, redisHost, Integer.parseInt(redisPort));
    }
}
