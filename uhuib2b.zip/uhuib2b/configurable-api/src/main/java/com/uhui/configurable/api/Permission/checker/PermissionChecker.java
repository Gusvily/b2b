package com.uhui.configurable.api.Permission.checker;

import java.util.List;

/**
 * Created by Fidel on 2017/5/16.
 */
public interface PermissionChecker<P, RP> {

    PermissionMatcher checkPermission(P permission, RP resourcePermission);

    PermissionMatcher checkPermissions(List<P> permissions, RP resourcePermission);
}
