package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by Fidel on 2017/6/2.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Company extends BaseModel {

    public static final String TABLE_NAME = "company";

    private Date approvalDate;
    private Long approvalUserId;
    private String name;
    private String nickname;
    private Integer type;
    private String businessScope;
    private Boolean disabled;
    private Integer status;
    private String legalPerson;
    private String businessLicenseNo;
    private BigDecimal registeredCapital;
    private String operationPerson;
    private String openingBank;
    private String accountName;
    private String account;
    private Long addressCity;
    private String addressDetail;
    private String zipCode;
    private Integer certificateStatus;
    private String logoImageUrl;
    private String businessLicenseImageUrl;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
