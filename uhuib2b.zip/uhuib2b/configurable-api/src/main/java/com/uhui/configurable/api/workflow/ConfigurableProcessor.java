package com.uhui.configurable.api.workflow;

import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by machenike on 2017/3/17.
 */
public class ConfigurableProcessor implements Processor {
    private static final Logger LOGGER = Logger.getLogger(ConfigurableProcessor.class);
    @Setter
    @Getter
    private String name;
    @Setter
    @Getter
    private String[] inputNames;
    @Setter
    @Getter
    private String outputName;
    @Setter
    @Getter
    private ProcessingChain processingChain;
    @Setter
    @Getter
    private boolean jsonpMethod;

    @Override
    public Object process(final Map<String, SpringBean> dependencies, Object[] args) {
        LOGGER.info(String.format("ConfigurableProcessor:%s Start.", name));
        Map<String, Object> localMethodStack = new HashMap<>();
        if (inputNames != null) {
            if (inputNames.length != args.length) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                        "Method invoke failed,input names don't match method arguments, processor name: %s", name));
            }
            for (int i = 0; i < inputNames.length; i++) {
                localMethodStack.put(inputNames[i], args[i]);
            }
        }
        ProcessingResult processorReturn;
        try {
            processorReturn = processingChain.invoke(dependencies, localMethodStack);
        } catch (Exception e) {
            processorReturn = ProcessingResult.failed(ExceptionUtils.getStackTrace(e));
        }
        if (jsonpMethod) {
            if (processorReturn.getStatus().equals(ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS)) {
                if (processorReturn.getDatas().size() != 1) {
                    LOGGER.info(String.format("ConfigurableProcessor:%s End.", name));
                    return ProcessingResult.failed(String.format(
                            "Method invoke failed, jsonp method must return only one result, processor name: %s, current result size: %s",
                            name, processorReturn.getDatas().size()));
                }
                LOGGER.info(String.format("ConfigurableProcessor:%s End.", name));
                return processorReturn.getDatas().get(0);
            } else {
                LOGGER.info(String.format("ConfigurableProcessor:%s End.", name));
                return processorReturn.toString();
            }
        } else {
            if (processorReturn.getStatus().equals(ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS) && outputName != null) {
                Object output = localMethodStack.get(outputName);
                if (output instanceof ProcessingResult) {
                    processorReturn = (ProcessingResult) output;
                } else {
                    processorReturn = ProcessingResult.succeeded(output);
                }
            }
            LOGGER.info(String.format("ConfigurableProcessor:%s End.", name));
            return processorReturn;
        }
    }
}
