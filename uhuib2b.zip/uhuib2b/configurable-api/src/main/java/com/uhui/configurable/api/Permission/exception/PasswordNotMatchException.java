package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/15.
 */
public class PasswordNotMatchException extends PermissionException{

    public PasswordNotMatchException() {
        super("Password not match.");
    }

    public PasswordNotMatchException(Throwable cause) {
        super("Password not match.", cause);
    }
}
