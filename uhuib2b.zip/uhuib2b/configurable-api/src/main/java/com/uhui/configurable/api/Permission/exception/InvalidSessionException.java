package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/15.
 */
public class InvalidSessionException extends SessionException {

    public InvalidSessionException() {
        super();
    }

    public InvalidSessionException(String message) {
        super(message);
    }

    public InvalidSessionException(Throwable cause) {
        super(cause);
    }

    public InvalidSessionException(String message, Throwable cause) {
        super(message, cause);
    }
}
