package com.uhui.configurable.api.workflow;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Fidel on 2017/2/24.
 */
@ToString
public class ProcessingResult<T> implements Serializable {

    public static final String PROCESSING_RESULT_STATUS_SUCCESS = "success";
    public static final String PROCESSING_RESULT_STATUS_FAILURE = "failure";
    public static final String PROCESSING_RESULT_STATUS_UNKNOWN = "unknown";

    public static final int PROCESSING_RESULT_CODE_FAILURE = 0;
    public static final int PROCESSING_RESULT_CODE_FULLY_SUCCESS = 1;
    public static final int PROCESSING_RESULT_CODE_FIRST_CONDITIONAL_SUCCESS = 2;
    public static final int PROCESSING_RESULT_CODE_UNKNOWN = 999;


    @Getter
    private String status;
    @Getter
    private List<T> datas;
    private int resultSize;
    @Getter
    private String errorMessage;
    /**
     * 0: failed
     * 1: success
     * 2 - 998: conditional success
     * 999: unknown
     */
    @Setter
    @Getter
    private int resultCode;

    public ProcessingResult() {
        status = PROCESSING_RESULT_STATUS_UNKNOWN;
        this.datas = new ArrayList<>();
    }

    private ProcessingResult(T data, String status, String errorMessage) {
        this.status = status;
        this.datas = new ArrayList<>();
        if (data != null) {
            datas.add(data);
        }
        this.errorMessage = errorMessage;
        initResultCode();
    }

    private void initResultCode() {
        if (PROCESSING_RESULT_STATUS_SUCCESS.equals(status)) {
            this.resultCode = PROCESSING_RESULT_CODE_FULLY_SUCCESS;
        } else if (PROCESSING_RESULT_STATUS_FAILURE.equals(status)) {
            this.resultCode = PROCESSING_RESULT_CODE_FAILURE;
        } else if (PROCESSING_RESULT_STATUS_UNKNOWN.equals(status)) {
            this.resultCode = PROCESSING_RESULT_CODE_UNKNOWN;
        }
    }

    private ProcessingResult(T data, String status, String errorMessage, int resultCode) {
        this.status = status;
        this.datas = new ArrayList<>();
        if (data != null) {
            datas.add(data);
        }
        this.errorMessage = errorMessage;
        this.resultCode = resultCode;
    }

    private ProcessingResult(String status, List<T> datas, String errorMessage) {
        this.status = status;
        this.datas = datas;
        this.errorMessage = errorMessage;
        initResultCode();
    }

    private ProcessingResult(String status, List<T> datas, String errorMessage, int resultCode) {
        this.status = status;
        this.datas = datas;
        this.errorMessage = errorMessage;
        this.resultCode = resultCode;
    }

    public static ProcessingResult succeeded() {
        return new ProcessingResult(null, PROCESSING_RESULT_STATUS_SUCCESS, null);
    }

    public static ProcessingResult succeeded(Object data) {
        return succeeded(data, false);
    }

    public static ProcessingResult succeeded(Object data, boolean isNest) {
        if (data instanceof List && !isNest) {
            return succeeded((List) data);
        }
        return new ProcessingResult(data, PROCESSING_RESULT_STATUS_SUCCESS, null);
    }

    public static ProcessingResult succeeded(Object data, int conditionalResultCode) {
        return succeeded(data, conditionalResultCode, false);
    }

    public static ProcessingResult succeeded(Object data, int conditionalResultCode, boolean isNest) {
        if (data instanceof List && !isNest) {
            return succeeded((List) data, conditionalResultCode);
        }
        return new ProcessingResult(data, PROCESSING_RESULT_STATUS_SUCCESS, null, conditionalResultCode);
    }

    public static ProcessingResult succeeded(List<?> datas) {
        return new ProcessingResult(PROCESSING_RESULT_STATUS_SUCCESS, datas, null);
    }

    public static ProcessingResult succeeded(List<?> datas, int conditionalResultCode) {
        return new ProcessingResult(PROCESSING_RESULT_STATUS_SUCCESS, datas, null, conditionalResultCode);
    }

    public static ProcessingResult failed(String errorMessage) {
        return new ProcessingResult(null, PROCESSING_RESULT_STATUS_FAILURE, errorMessage);
    }

    public static ProcessingResult failed(String errorMessage, Object data) {
        return new ProcessingResult(data, PROCESSING_RESULT_STATUS_FAILURE, errorMessage);
    }

    public int getResultSize() {
        if (datas == null) {
            return 0;
        }
        return datas.size();
    }
}
