package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/12.
 */
public class UnknownAccountException extends PermissionException {

    public UnknownAccountException() {
        super("Account not exists.");
    }

    public UnknownAccountException(Throwable cause) {
        super("Account not exists.", cause);
    }
}
