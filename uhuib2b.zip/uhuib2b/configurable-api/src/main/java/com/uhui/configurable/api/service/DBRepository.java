package com.uhui.configurable.api.service;

import com.uhui.configurable.api.model.BaseModel;
import com.uhui.configurable.api.workflow.utils.Pagination;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/27.
 */
@Repository
public interface DBRepository {

    <T extends BaseModel> T getById(Class<T> clz, Long id);

    Long create(BaseModel model);

    Long create(String table, BaseModel model);

    int update(Long id, BaseModel model);

    int updateColumn(Long id, String tableName, String columnName, Object columnValue);

    int delete(Long id, String tableName);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, String[] orderBy);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, List<String> where, String[] orderBy);

    <T extends BaseModel> List<T> simpleQuery(Class<T> clz, String[] select, List<String> where, String[] orderBy);

    <T> Pagination<T> query(Pagination<T> page,
                            String table,
                            String[] select,
                            Map<String, String> leftJoin,
                            List<String> where,
                            String[] groupBy,
                            String[] orderBy);

    List<Map<String, Object>> executeQuery(String sql);

}
