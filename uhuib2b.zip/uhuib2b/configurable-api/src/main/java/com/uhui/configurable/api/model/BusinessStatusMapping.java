package com.uhui.configurable.api.model;

/**
 * Created by Fidel on 2017/4/18.
 */
public interface BusinessStatusMapping {
    /**
     * 产品状态 在线
     */
    Integer PRODUCT_STATUS_ONLINE = 100100;
    /**
     * 产品状态 已下线
     */
    Integer PRODUCT_STATUS_OFFLINE = 100101;

    /**
     * 产品类型 分期返现
     */
    Integer PRODUCT_TYPE_INSTALLMENT_CASH_BACK = 100110;
    /**
     * 货物交付方式 按月返现
     */
    Integer DELIVERY_TYPE_MONTHLY_CASH_BACK = 100150;
    /**
     * 支付方式 预付款
     */
    Integer PAY_TYPE_PREPAYMENT = 100200;
    /**
     * 支付方式 货到付款
     */
    Integer PAY_TYPE_PAY_ON_DELIVERY = 100201;
    /**
     * 支付方式 货到付现
     */
    Integer PAY_TYPE_CASH_ON_DELIVERY = 100202;
    /**
     * 帐期
     */
    Integer PAY_TYPE_CREDIT = 100203;
    /**
     * 线下支付
     */
    Integer PAY_TYPE_OFFLINE = 100204;
    /**
     * 余额支付
     */
    Integer PAY_TYPE_BALANCE = 100205;

    /**
     * 产品由管理员生成
     */
    Integer PRODUCT_SOURCE_TYPE_CREATED_BY_ADMIN = 0;
    /**
     * 产品由系统生成
     */
    Integer PRODUCT_SOURCE_TYPE_CREATED_BY_SYSTEM = 1;

    /**
     * 预付款返现
     */
    Integer ORDER_TYPE_PREPAYMENT_CASH_BACK = 100300;

    //订单状态
    /**
     * 已创建订单，代表买方已确认订单
     */
    Integer ORDER_STATUS_CREATED = 100350;
    /**
     * 待卖方确认订单
     */
    Integer ORDER_STATUS_WAIT_FOR_SUPPLIER_APPROVE_ORDER = 100351;
    /**
     * 待买方付款
     */
    Integer ORDER_STATUS_WAIT_FOR_PURCHASER_PAY = 100352;
    /**
     * 待卖方发货
     */
    Integer ORDER_STATUS_WAIT_FOR_SUPPLIER_DELIVERY = 100353;
    /**
     * 待买方收货
     */
    Integer ORDER_STATUS_WAIT_FOR_PURCHASER_RECEIVE = 100354;
    /**
     * 买方已收货
     */
    Integer ORDER_STATUS_PURCHASER_RECEIVED = 100355;
    /**
     * 待卖方收款
     */
    Integer ORDER_STATUS_WAIT_FOR_SUPPLIER_RECEIPT_OF_PAYMENT = 100356;
    /**
     * 待卖方收款
     */
    Integer ORDER_STATUS_SUPPLIER_RECEIPTED_OF_PAYMENT = 100357;
    /**
     * 订单完成
     */
    Integer ORDER_STATUS_FINISHED = 100358;
    /**
     * 退款中
     */
    Integer ORDER_STATUS_REFUND = 100359;
    /**
     * 待卖方确认退款
     */
    Integer ORDER_STATUS_WAIT_FOR_SUPPLIER_APPROVE_REFUND = 100360;
    /**
     * 已退款
     */
    Integer ORDER_STATUS_REFUNDED = 100361;
    /**
     * 交易关闭
     */
    Integer ORDER_STATUS_CLOSED = 100362;
    /**
     * 卖方取消
     */
    Integer ORDER_STATUS_SUPPLIER_CANCELED = 100363;
    /**
     * 买方取消
     */
    Integer ORDER_STATUS_PURCHASER_CANCELED = 100364;


    //付款状态
    /**
     * 已付款
     */
    Integer PAY_STATUS_PAID = 100400;
    /**
     * 未付款
     */
    Integer PAY_STATUS_NOPAY = 100401;
    /**
     * 正在处理
     */
    Integer PAY_STATUS_ING = 100402;
    /**
     * 已部分付款
     * 部分付款的状态变化为: NOPAY <-> ING -> PARTIALLY_PAID <-> ING -> PARTIALLY_PAID <-> ... <-> ING -> PAID
     * <->表示失败时回到前一状态
     */
    Integer PAY_STATUS_PARTIALLY_PAID = 100403;

    /**
     * 货物交付状态 未到交货时间，无法交货
     */
    Integer DELIVERY_STATUS_UNDELIVERABLE_BEFORE_DELIVERY_TIME_ARRIVED = 100500;

    /**
     * 货物交付状态 已发货
     */
    Integer DELIVERY_STATUS_DELIVERED = 100501;

    /**
     * 货物交付状态 已收货
     */
    Integer DELIVERY_STATUS_RECEIVED = 100502;

    /**
     * 加油卡类型 中国石化
     */
    Integer GAS_CARD_TYPE_SINOPEC = 100600;

    /**
     * 加油卡类型 中国石油
     */
    Integer GAS_CARD_TYPE_CNPC = 100601;

//
//    Integer PAY_TYPE_WECHAT_PAYMENT = 100200;
//    Integer PAY_TYPE_ALIPAY_PAYMENT = 100201;
}
