package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/3/31.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class GasStationPrice extends BaseModel {

    public static final String TABLE_NAME = "gas_station_price";

    private Long gasStationId;

    private Float gas92;
    private Float gas95;
    private Float diesel0;
    private Float diesel10;
    private Float diesel20;
    private Float diesel35;
    private Float gas89;
    private Float gas90;
    private Float gas93;
    private Float gas97;
    private Float E90;
    private Float E93;
    private Float E97;
    private Float E0;
    private Float CNG;
    private Float LNG;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
