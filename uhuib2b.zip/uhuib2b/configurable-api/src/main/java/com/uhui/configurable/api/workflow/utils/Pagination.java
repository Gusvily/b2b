package com.uhui.configurable.api.workflow.utils;

import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/4/1.
 */
@Data
public class Pagination<T> {

    public static final int DEFAULT_PAGE_SIZE = 20;

    @JsonIgnore
    private Class<T> clz;

    private List<T> datas;
    // 每页的记录数
    private int pageSize = DEFAULT_PAGE_SIZE;
    //当前页数
    private Integer currentPage;
    //总页数
    private Integer totalPage;
    // 总记录数
    private Long totalCount;

    public Pagination() {
    }

    private Pagination(Class<T> clz) {
        this.clz = clz;
    }

    private Pagination(Class<T> clz, Integer pageSize, Integer currentPage, Integer totalPage, Long totalCount) {
        this.clz = clz;
        if (pageSize != null) {
            this.pageSize = pageSize;
        }
        this.currentPage = currentPage;
        this.totalPage = totalPage;
        this.totalCount = totalCount;
    }

    public Pagination<? extends Map> buildPagination() {
        return new Pagination<>(HashMap.class);
    }

    public <T> Pagination<T> buildPagination(Class<T> clz) {
        return new Pagination<>(clz);
    }

    public <T> Pagination<T> buildPagination(Class<T> clz, Integer pageSize, Integer currentPage, Integer totalPage, Long totalCount) {
        return new Pagination<>(clz, pageSize, currentPage, totalPage, totalCount);
    }

    public boolean hasNext() {
        return currentPage < totalPage;
    }

    public Pagination<T> nextPagination() {
        if (this.currentPage >= this.totalPage) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Don't have next page.");
        }
        return buildPagination(this.clz, this.pageSize, this.currentPage + 1, totalPage, totalCount);
    }
}
