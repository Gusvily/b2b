package com.uhui.configurable.api.workflow.utils;

import com.uhui.configurable.api.workflow.ProcessingResult;

/**
 * Created by Fidel on 2017/4/10.
 */
public class ConditionUtils {

    public ProcessingResult equals(Object o1, Object o2) {
        if (o1 == null || o2 == null) {
            ProcessingResult.failed("ConditionUtils invokes equals method failed, all arguments should not be null");
        }
        int conditionalResultCode;
        if (o1.equals(o2)) {
            conditionalResultCode = 2;
        } else {
            conditionalResultCode = 3;
        }
        return ProcessingResult.succeeded(null, conditionalResultCode);
    }

    public ProcessingResult isTrue(Boolean b) {
        if (b == null) {
            ProcessingResult.failed("ConditionUtils invokes equals method failed, all arguments should not be null");
        }
        int conditionalResultCode;
        if (b) {
            conditionalResultCode = 2;
        } else {
            conditionalResultCode = 3;
        }
        return ProcessingResult.succeeded(null, conditionalResultCode);
    }

    public ProcessingResult isNotEmptyTrue(Boolean b) {
        int conditionalResultCode;
        if (b == null) {
            conditionalResultCode = 3;
        } else if (b) {
            conditionalResultCode = 2;
        } else {
            conditionalResultCode = 3;
        }
        return ProcessingResult.succeeded(null, conditionalResultCode);
    }

    public ProcessingResult isNull(Object o) {
        int conditionalResultCode;
        if (o == null) {
            conditionalResultCode = 2;
        } else {
            conditionalResultCode = 3;
        }
        return ProcessingResult.succeeded(null, conditionalResultCode);
    }
}
