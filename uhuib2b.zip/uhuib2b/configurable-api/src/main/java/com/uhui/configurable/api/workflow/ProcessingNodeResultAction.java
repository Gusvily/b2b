package com.uhui.configurable.api.workflow;

/**
 * Created by Fidel on 2017/3/17.
 */
public enum ProcessingNodeResultAction {

    STORE("store"),
    VARIABLE_STORE("variable_store"),
    SINGLE_VARIABLE_STORE("single_variable_store"),
    CONDITIONAL_SUCCESS("conditional_success"),
    VARIABLE_CONDITIONAL_SUCCESS("variable_conditional_success"),
    SINGLE_VARIABLE_CONDITIONAL_SUCCESS("single_variable_conditional_success"),
    RETURN("return");

    private String action;

    ProcessingNodeResultAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return this.action;
    }

}
