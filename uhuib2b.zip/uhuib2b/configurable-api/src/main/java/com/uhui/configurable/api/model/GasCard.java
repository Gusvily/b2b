package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/4/26.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class GasCard extends BaseModel {

    public static final String TABLE_NAME = "gas_card";

    private Long userId;
    private String cardNo;
    private Integer cardType;
    private String comments;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
