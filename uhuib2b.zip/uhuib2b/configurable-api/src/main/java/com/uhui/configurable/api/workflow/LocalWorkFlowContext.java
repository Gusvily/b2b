package com.uhui.configurable.api.workflow;

import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;

import java.util.HashMap;

/**
 * Created by Fidel on 2017/2/28.
 */
public class LocalWorkFlowContext {

    private HashMap<String, ProcessingResult> store;

    public LocalWorkFlowContext() {
        reset();
    }

    public void reset() {
        store = new HashMap<>();
    }

    public void setContext(String key, ProcessingResult value) {
        checkKey(key);
        store.put(key, value);
    }

    public ProcessingResult getContext(String key) {
        checkKey(key);
        return store.get(key);
    }

    private void checkKey(String key) {
        if (key == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Key of LocalWorkFlowContext must be not null.");
        }
    }
}
