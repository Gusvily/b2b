package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by Fidel on 2017/4/18.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order extends InportantModel {

    public static final String TABLE_NAME = "order";

    private Long productId;
    private String productSpecification;
    private Integer orderType;
    private Integer orderStatus;
    private BigDecimal orderAmount;
    private BigDecimal discountAmount;
    private Integer payType;
    private Integer payStatus;
    private Date payDate;
    private Long orderUserId;
    private Date orderDate;
    private String orderNo;
    private Long changeRequestId;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
