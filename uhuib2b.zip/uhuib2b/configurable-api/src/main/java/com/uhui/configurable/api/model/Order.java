package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by Fidel on 2017/4/18.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Order extends InportantModel {

    public static final String TABLE_NAME = "order";

    private String orderNo;
    private Long supplierId;
    private Long purchaserId;
    private String productSpecification;
    private Integer orderType;
    private Integer orderStatus;
    private Integer   totalPieceNumber;
    private BigDecimal totalOrderAmount;
    private BigDecimal totalDiscountAmount;
    private Integer payType;
    private Integer payStatus;
    private Date payDate;
    private Date orderDate;
    private Long changeRequestId;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
