package com.uhui.configurable.api.model;

/**
 * Created by Fidel on 2017/4/19.
 */
public abstract class InportantModel extends BaseModel{

    private Integer dataVersion;
    private Long creatorId;

    public void setDataVersion(Integer dataVersion) {
        this.dataVersion = dataVersion;
    }

    public void setCreatorId(Long creatorId) {
        this.creatorId = creatorId;
    }

    public Integer getDataVersion() {
        return dataVersion;
    }

    public Long getCreatorId() {
        return creatorId;
    }
}
