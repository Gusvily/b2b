package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Created by Fidel on 2017/4/17.
 */
@Path("product")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface ProductService {

    @POST
    @Path("lastProduct")
    ProcessingResult getLastProduct();
}
