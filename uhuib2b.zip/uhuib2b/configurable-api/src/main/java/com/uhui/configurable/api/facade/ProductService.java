package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.model.Product;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/4/17.
 */
@Path("product")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface ProductService {

//    @POST
//    @Path("lastProduct")
//    ProcessingResult getLastProduct();

    @POST
    @Path("create")
    ProcessingResult createProduct(@CookieParam("__token__") String token, Product product);

    @POST
    @Path("update/{id : \\d+}")
    ProcessingResult updateProduct(@CookieParam("__token__") String token, @PathParam("id") @Min(1L) Long id, Product product);

    @POST
    @Path("delete/{id : \\d+}")
    ProcessingResult deleteProduct(@CookieParam("__token__") String token, @PathParam("id") @Min(1L) Long id);

    @POST
    @Path("list")
    ProcessingResult listProduct(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("list/order/{orderId : \\d+}")
    ProcessingResult listProductByOrderId(@CookieParam("__token__") String token, @PathParam("orderId") @Min(1L) Long orderId);

    @POST
    @Path("online/{id : \\d+}")
    ProcessingResult onlineProduct(@CookieParam("__token__") String token, @PathParam("id") @Min(1L) Long id);

    @POST
    @Path("offline/{id : \\d+}")
    ProcessingResult offlineProduct(@CookieParam("__token__") String token, @PathParam("id") @Min(1L) Long id);

    @POST
    @Path("purchaser/list")
    ProcessingResult listProductForPurchaser(Map<String, Object> params);

    @POST
    @Path("view/supplier/{supplierId : \\d+}/product/{productId : \\d+}")
    ProcessingResult viewProduct(@PathParam("supplierId") @Min(1L) Long supplierId, @PathParam("productId") @Min(1L) Long productId);
}
