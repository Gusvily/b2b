package com.uhui.configurable.api.workflow;

import java.util.Map;
import java.util.Set;

/**
 * Created by Fidel on 2017/2/28.
 */
public interface ConfigurableWorkFlow extends WorkFlow {

    String CONFIGURABLE_WORKFLOW_KEY = "configurableWorkFlow";
    String CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG = "dubboConfig";
    String CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES = "dependencies";
    String CONFIGURABLE_WORKFLOW_KEY_METHODS = "methods";


    WorkFlowConfig initResource(String resourcePath);

    boolean checkInitSuccessful();

    void initField(String fieldName, String fieldValue);

    String getDubboConfigStringValue(String fieldName);

    int getDubboConfigIntValue(String fieldName);

    boolean getDubboConfigBooleanValue(String fieldName);

    String getDubboConfigReferenceValue(String fieldName);

    Set<Map.Entry<String, DubboConfigValue>> getAllFieldValue();

    void setWorkFlowDependencies(Map<String,SpringBean> dependencies);

    Map<String,SpringBean> getWorkFlowDependencies();

    void setWorkFlowMethods(Map<String, Processor> methods);

    Map<String, Processor> getWorkFlowMethods();

}
