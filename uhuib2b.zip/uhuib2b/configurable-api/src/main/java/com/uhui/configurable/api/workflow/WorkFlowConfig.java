package com.uhui.configurable.api.workflow;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/2/28.
 */
@Data
public class WorkFlowConfig {

    private String name;

    private Map<String, Processor> methods;

    private Map<String,SpringBean> dependencies;

    private List<SpringBean> properties;

    private List<SpringBean> refes;
}
