package com.uhui.configurable.api.workflow;

/**
 * Created by Fidel on 2017/3/10.
 */
public enum DubboConfigMapping {
    APPLICATION("application", DubboConfigType.REFERENCE),
    INTERFACE("interface", DubboConfigType.STRING),
    REGISTRY("registry", DubboConfigType.REFERENCE),
    REF("ref", DubboConfigType.REFERENCE),
    PROTOCOL("protocol", DubboConfigType.REFERENCE),

    VALIDATION("validation", DubboConfigType.STRING),

    VERSION("version", DubboConfigType.STRING),
    GROUP("group", DubboConfigType.STRING),
    PATH("path", DubboConfigType.STRING),
    DELAY("delay", DubboConfigType.INT),
    TIMEOUT("timeout", DubboConfigType.INT),
    RETRIES("retries", DubboConfigType.INT),
    CONNECTIONS("connections", DubboConfigType.INT),
    LOAD_BALANCE("loadbalance", DubboConfigType.STRING),
    ASYNC("async", DubboConfigType.BOOLEAN),
    STUB("stub", DubboConfigType.BOOLEAN),
    MOCK("mock", DubboConfigType.BOOLEAN),
    TOKEN("token", DubboConfigType.BOOLEAN),
    PROVIDER("provider", DubboConfigType.STRING),
    DEPRECATED("deprecated", DubboConfigType.BOOLEAN),
    DYNAMIC("dynamic", DubboConfigType.BOOLEAN),
    ACCESS_LOG("accesslog", DubboConfigType.BOOLEAN),
    OWNER("owner", DubboConfigType.STRING),
    DOCUMENT("document", DubboConfigType.STRING),
    WEIGHT("weight", DubboConfigType.INT),
    EXECUTES("executes", DubboConfigType.INT),
    ACTIVES("actives", DubboConfigType.INT),
    PROXY("proxy", DubboConfigType.STRING),
    CLUSTER("cluster", DubboConfigType.STRING),
    FILTER("filter", DubboConfigType.STRING),
    LISTENER("listener", DubboConfigType.STRING),
    LAYER("layer", DubboConfigType.STRING),
    REGISTER("register", DubboConfigType.BOOLEAN);

    private final String key;
    private final DubboConfigType type;

    DubboConfigMapping(String key, DubboConfigType type) {
        this.key = key;
        this.type = type;
    }

    public String key(){
        return this.key;
    }

    public DubboConfigType type() {
        return this.type;
    }

    public static DubboConfigMapping getMapping(String key) {
        for (DubboConfigMapping dubboConfigMapping : DubboConfigMapping.values()) {
            if (dubboConfigMapping.key.equals(key)) {
                return dubboConfigMapping;
            }
        }
        return null;
    }

    public static DubboConfigType getType(String key) {
        for (DubboConfigMapping dubboConfigMapping : DubboConfigMapping.values()) {
            if (dubboConfigMapping.key.equals(key)) {
                return dubboConfigMapping.type;
            }
        }
        return null;
    }


}
