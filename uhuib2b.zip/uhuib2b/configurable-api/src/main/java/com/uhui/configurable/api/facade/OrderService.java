package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.validation.constraints.Min;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/4/17.
 */
@Path("order")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface OrderService {

    @POST
    @Path("create/info")
    ProcessingResult createOrderInfo(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("create")
    ProcessingResult createOrder(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("list")
    ProcessingResult listOrder(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("statistics/view/supplier/{supplierId : \\d+}/purchaser/{productId : \\d+}")
    ProcessingResult viewPurchaserOrderStatistics(@CookieParam("__token__") String token, @PathParam("supplierId") @Min(1L) Long supplierId, @PathParam("productId") @Min(1L) Long productId);
}
