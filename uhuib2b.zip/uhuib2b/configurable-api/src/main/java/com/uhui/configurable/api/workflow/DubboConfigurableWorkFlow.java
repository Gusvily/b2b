package com.uhui.configurable.api.workflow;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by Fidel on 2017/3/9.
 */
public abstract class DubboConfigurableWorkFlow implements ConfigurableWorkFlow {

    private HashMap<String, DubboConfigValue> dubboConfigs = new HashMap<>();

    private WorkFlowConfig workFlowConfig = new WorkFlowConfig();

    private Map<String, Processor> processors = new HashMap<>();
    @Setter
    @Getter
    private String name;


    @Override
    public Processor findProcessor(String methodName) {
        return processors.get(methodName);
    }

    @Override
    public boolean checkInitSuccessful() {
        return StringUtils.isNotEmpty(dubboConfigs.get("applicationName").getValue().toString()) &&
                StringUtils.isNotEmpty(dubboConfigs.get("interfaceName").getValue().toString()) &&
                StringUtils.isNotEmpty(dubboConfigs.get("registryName").getValue().toString()) &&
                StringUtils.isNotEmpty(dubboConfigs.get("protocolName").getValue().toString());
    }

    @Override
    public void initField(String fieldName, String fieldValue) {
        dubboConfigs.put(fieldName, new DubboConfigValue(fieldName, fieldValue));
    }

    @Override
    public String getDubboConfigStringValue(String fieldName) {
        if (DubboConfigMapping.getType(fieldName) != DubboConfigType.STRING) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig get value failed, config name: %s.", fieldName));
        }
        return dubboConfigs.get(fieldName).getValue();
    }

    @Override
    public int getDubboConfigIntValue(String fieldName) {
        if (DubboConfigMapping.getType(fieldName) != DubboConfigType.INT) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig get value failed, config name: %s.", fieldName));
        }
        return Integer.parseInt(dubboConfigs.get(fieldName).getValue());
    }

    @Override
    public boolean getDubboConfigBooleanValue(String fieldName) {
        if (DubboConfigMapping.getType(fieldName) != DubboConfigType.BOOLEAN) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig get value failed, config name: %s.", fieldName));
        }
        return Boolean.parseBoolean(dubboConfigs.get(fieldName).getValue());
    }

    @Override
    public String getDubboConfigReferenceValue(String fieldName) {
        if (DubboConfigMapping.getType(fieldName) != DubboConfigType.REFERENCE) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig get value failed, config name: %s.", fieldName));
        }
        return dubboConfigs.get(fieldName).getValue();
    }

    @Override
    public Set<Map.Entry<String, DubboConfigValue>> getAllFieldValue() {
        return dubboConfigs.entrySet();
    }

    @Override
    public void setWorkFlowDependencies(Map<String, SpringBean> dependencies) {
        workFlowConfig.setDependencies(dependencies);
    }

    @Override
    public Map<String, SpringBean> getWorkFlowDependencies() {
        return workFlowConfig.getDependencies();
    }

    @Override
    public void setWorkFlowMethods(Map<String, Processor> methods) {
        workFlowConfig.setMethods(methods);
    }

    @Override
    public Map<String, Processor> getWorkFlowMethods() {
        return workFlowConfig.getMethods();
    }
}
