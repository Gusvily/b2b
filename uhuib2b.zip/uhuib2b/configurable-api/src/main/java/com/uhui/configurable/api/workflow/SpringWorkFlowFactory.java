package com.uhui.configurable.api.workflow;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ProtocolConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.ServiceConfig;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Setter;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.InvocationHandler;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import java.lang.reflect.Method;
import java.util.Map;

/**
 * Created by Fidel on 2017/2/28.
 */
public class SpringWorkFlowFactory implements ApplicationListener<ContextRefreshedEvent> {

    @Setter
    private String workFlowClassName;

    @Setter
    private String[] resources;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        Class workFlowClass;
        try {
            workFlowClass = Class.forName(workFlowClassName);
        } catch (ClassNotFoundException e) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("Workflow init failed, class name: %s.", workFlowClassName), e);
        }
        for (int i = 0; i < resources.length; i++) {
            DubboConfigurableWorkFlow configurableWorkFlow = null;
            try {
                configurableWorkFlow = (DubboConfigurableWorkFlow) workFlowClass.newInstance();
            } catch (Exception e) {
            }
            if (configurableWorkFlow == null) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                        "Workflow init failed, please ensure workflow class extends DubboConfigurableWorkFlow, current class name: %s.",
                        workFlowClassName));
            }
            configurableWorkFlow.initResource(resources[i]);
            ApplicationContext applicationContext = contextRefreshedEvent.getApplicationContext();
            BeanDefinitionBuilder beanDefinitionBuilder = buildServiceForSpring(applicationContext, configurableWorkFlow);
            registerBean(applicationContext, configurableWorkFlow.getName(), beanDefinitionBuilder.getBeanDefinition());
            applicationContext.getBean(configurableWorkFlow.getName(), ServiceConfig.class).export();
        }
    }

    private void registerBean(ApplicationContext applicationContext, String beanName, BeanDefinition bean) {
        DefaultListableBeanFactory fty = (DefaultListableBeanFactory) applicationContext.getAutowireCapableBeanFactory();
        fty.registerBeanDefinition(beanName, bean);
    }

    private BeanDefinitionBuilder buildServiceForSpring(ApplicationContext applicationContext, DubboConfigurableWorkFlow configurableWorkFlow) {

        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.rootBeanDefinition(ServiceConfig.class);

        initDependencies(applicationContext, configurableWorkFlow);

        beanDefinitionBuilder.addPropertyValue("ref", buildServiceImpl(configurableWorkFlow));

        for (Map.Entry<String, DubboConfigValue> configValueEntry : configurableWorkFlow.getAllFieldValue()) {
            String key = configValueEntry.getKey();
            switch (DubboConfigMapping.getType(key)) {
                case REFERENCE:
                    if (key.equals(DubboConfigMapping.APPLICATION.key())) {
                        ApplicationConfig application = getSpringRef(applicationContext, configurableWorkFlow, key, ApplicationConfig.class);
                        beanDefinitionBuilder.addPropertyValue(key, application);
                    } else if (key.equals(DubboConfigMapping.REGISTRY.key())) {
                        RegistryConfig registry = getSpringRef(applicationContext, configurableWorkFlow, key, RegistryConfig.class);
                        beanDefinitionBuilder.addPropertyValue(key, registry);
                    } else if (key.equals(DubboConfigMapping.PROTOCOL.key())) {
                        ProtocolConfig protocol = getSpringRef(applicationContext, configurableWorkFlow, key, ProtocolConfig.class);
                        beanDefinitionBuilder.addPropertyValue(key, protocol);
                    }
                    break;
                case STRING:
                    beanDefinitionBuilder.addPropertyValue(key, configurableWorkFlow.getDubboConfigStringValue(key));
                    break;
                case BOOLEAN:
                    beanDefinitionBuilder.addPropertyValue(key, configurableWorkFlow.getDubboConfigBooleanValue(key));
                    break;
                case INT:
                    beanDefinitionBuilder.addPropertyValue(key, configurableWorkFlow.getDubboConfigIntValue(key));
                    break;
            }
        }

        return beanDefinitionBuilder;
    }

    private void initDependencies(ApplicationContext applicationContext, DubboConfigurableWorkFlow configurableWorkFlow) {
        Map<String, SpringBean> dependencies = configurableWorkFlow.getWorkFlowDependencies();
        for (Map.Entry<String, SpringBean> dependencyEntry : dependencies.entrySet()) {
            SpringBean dependency = dependencyEntry.getValue();
            dependency.setBeanInstance(applicationContext.getBean(dependency.getBeanName(), dependency.getBeanClass()));
        }
    }

    private <T> T getSpringRef(ApplicationContext applicationContext, DubboConfigurableWorkFlow configurableWorkFlow, String configName, Class<T> clz) {
        return applicationContext.getBean(configurableWorkFlow.getDubboConfigReferenceValue(configName), clz);
    }

    private Object buildServiceImpl(final DubboConfigurableWorkFlow configurableWorkFlow) {
        String interfaceName = configurableWorkFlow.getDubboConfigStringValue(DubboConfigMapping.INTERFACE.key());
        Class interfaceClz;
        try {
            interfaceClz = Class.forName(interfaceName);
        } catch (ClassNotFoundException e) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("Build service impl failed,class name: %s.", interfaceName), e);
        }
        Enhancer en = new Enhancer();
        en.setSuperclass(interfaceClz);
        en.setCallback(new InvocationHandler() {
            private Map<String, SpringBean> dependencies = configurableWorkFlow.getWorkFlowDependencies();
            private Map<String, Processor> methods = configurableWorkFlow.getWorkFlowMethods();

            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                Processor processor = methods.get(method.getName());
                if (processor == null) {
                    throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("Method invoke failed, no matching method found, method name: %s",
                            method.getName()));
                }
                Object result;
                try {
                    result = processor.process(dependencies, args);
                    return result;
                } catch (Exception e) {
                    return ProcessingResult.failed(ExceptionUtils.getStackTrace(e));
                }
            }
        });
        return en.create();
    }

}
