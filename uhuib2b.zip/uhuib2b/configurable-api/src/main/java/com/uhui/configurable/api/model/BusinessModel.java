package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/5/22.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public abstract class BusinessModel extends BaseModel {

    private Long companyId;

    private Long groupId;
}
