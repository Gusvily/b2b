package com.uhui.configurable.api.model;

import com.uhui.configurable.api.workflow.utils.BeanUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public abstract class BaseModel implements Serializable {
    private Long id;
    private Date createDate;
    private Date updateDate;

    @JsonIgnore
    public abstract String getTable();

    public BaseModel() {
    }

    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if (!(getClass().equals(o.getClass()))) {
            return false;
        } else {
            BaseModel other = (BaseModel) o;

            Long this$id = this.getId();
            Long other$id = other.getId();
            if (this$id == null) {
                if (other$id != null) {
                    return false;
                }
            } else if (!this$id.equals(other$id)) {
                return false;
            }

            Date this$createDate = this.getCreateDate();
            Date other$createDate = other.getCreateDate();
            if (this$createDate == null) {
                if (other$createDate != null) {
                    return false;
                }
            } else if (!this$createDate.equals(other$createDate)) {
                return false;
            }

            Date this$updateDate = this.getUpdateDate();
            Date other$updateDate = other.getUpdateDate();
            if (this$updateDate == null) {
                if (other$updateDate != null) {
                    return false;
                }
            } else if (!this$updateDate.equals(other$updateDate)) {
                return false;
            }
            return true;
        }
    }

    public int hashCode() {
        byte result = 1;
        Long $id = this.getId();
        int result1 = result * 59 + ($id == null ? 0 : $id.hashCode());
        Date $createDate = this.getCreateDate();
        result1 = result1 * 59 + ($createDate == null ? 0 : $createDate.hashCode());
        Date $updateDate = this.getUpdateDate();
        result1 = result1 * 59 + ($updateDate == null ? 0 : $updateDate.hashCode());
        return result1;
    }

    public String toString() {
        return "BaseModel(id=" + this.getId() + ", createDate=" + this.getCreateDate() + ", updateDate=" + this.getUpdateDate() + ")";
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Long getId() {
        return this.id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public BaseModel fillInstance(Map<String, Object> values) {
        BeanUtils beanUtils = new BeanUtils();
        return beanUtils.mapToObject(values, this, BeanUtils.UNDERLINE);
    }
}
