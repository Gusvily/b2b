package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/6/2.
 */
@Path("company")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface CompanyService {

    @POST
    @Path("certificate/request")
    ProcessingResult certificateRequest(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("certificate/audit")
    ProcessingResult certificateAudit(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("certificate/list")
    ProcessingResult certificateList(@CookieParam("__token__") String token);

    @POST
    @Path("purchaser/list/supplier/{supplierId : \\d+}")
    ProcessingResult listPurchaserCompanyBySupplierId(@CookieParam("__token__") String token, @PathParam("supplierId") String supplierId);

    @POST
    @Path("purchaser/view/{purchaserId : \\d+}")
    ProcessingResult viewPurchaserById(@CookieParam("__token__") String token, @PathParam("purchaserId") String purchaserId);

    @POST
    @Path("supplier/view/{supplierId : \\d+}")
    ProcessingResult viewSupplierById(@CookieParam("__token__") String token, @PathParam("supplierId") String supplierId);

    @POST
    @Path("view/own")
    ProcessingResult viewOwnCompany(@CookieParam("__token__") String token);

    @POST
    @Path("logo/change")
    ProcessingResult changeCompanyLogo(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("nickname/change")
    ProcessingResult changeCompanyNickname(@CookieParam("__token__") String token, Map<String, Object> params);
}
