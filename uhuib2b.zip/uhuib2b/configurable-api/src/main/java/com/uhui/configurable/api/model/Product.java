package com.uhui.configurable.api.model;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * Created by Fidel on 2017/4/17.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Product extends BaseModel {

    public static final String TABLE_NAME = "product";

    private String name;
    private String title;
    private Integer productStatus;
    private String specification;
    private Date publishDate;
    private Long publisherId;
    private Integer productType;
    private String imageUrl;
    private Integer salePieceNum;
    private Long origin;
    private String sellArea;
    private String introduction;
    private Integer deliveryType;
    private Integer payType;
    private Integer sourceType;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }

    public Integer getCashBackFromSpecification(Integer selectedMouth, Integer selectedAmount) {
        if (StringUtils.isEmpty(this.specification) || selectedMouth == null || selectedAmount == null) {
            return null;
        }
        JSONObject jsonSpecification = JSON.parseObject(this.specification);
        JSONArray monthlyCashBacks = jsonSpecification.getJSONArray("productSpecification");
        for (int i = 0; i < monthlyCashBacks.size(); i++) {
            JSONObject monthlyCashBack = monthlyCashBacks.getJSONObject(i);
            if (monthlyCashBack.getInteger("mouth") == selectedMouth) {
                JSONObject amountObject = monthlyCashBack.getJSONObject("amount");
                return amountObject.getInteger(selectedAmount.toString());
            }
        }
        return null;
    }
}
