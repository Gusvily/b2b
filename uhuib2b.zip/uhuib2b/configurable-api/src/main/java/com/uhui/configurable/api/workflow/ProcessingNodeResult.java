package com.uhui.configurable.api.workflow;

import lombok.Getter;

/**
 * Created by Fidel on 2017/3/17.
 */
public class ProcessingNodeResult {

    public static final String PROCESSING_NODE_RESULT_ACTION_KEY = "action";
    public static final String PROCESSING_NODE_RESULT_NAME_KEY = "name";
    public static final String PROCESSING_NODE_RESULT_CODE_KEY = "code";
    @Getter
    private ProcessingNodeResultAction processingNodeResultAction;
    @Getter
    private String name;
    @Getter
    private Integer resultCode;

    public ProcessingNodeResult(ProcessingNodeResultAction processingNodeResultAction, String name) {
        this(processingNodeResultAction, name, null);
    }

    public ProcessingNodeResult(ProcessingNodeResultAction processingNodeResultAction, String name, Integer resultCode) {
        this.processingNodeResultAction = processingNodeResultAction;
        this.name = name;
        this.resultCode = resultCode;
    }
}
