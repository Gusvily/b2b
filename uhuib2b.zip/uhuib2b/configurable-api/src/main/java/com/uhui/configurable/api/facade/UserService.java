package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.workflow.ProcessingResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/7.
 */
@Path("user")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface UserService {

    @POST
    @Path("security/code/mobile")
    ProcessingResult requestSecurityCodeForMobile(Map<String, Object> params);


    @POST
    @Path("security/code/email")
    ProcessingResult requestSecurityCodeForEmail(Map<String, Object> params);

    @POST
    @Path("register")
    ProcessingResult<Integer> registerUserAndCompany(Map<String, Object> params);

    @POST
    @Path("login")
    ProcessingResult login(Map<String, Object> params);

    @POST
    @Path("logout")
    ProcessingResult logout(@CookieParam("__token__") String token);

    @POST
    @Path("info/current")
    ProcessingResult<User> getCurrentUserInfo(@CookieParam("__token__") String token);

    @POST
    @Path("purchaser/view/order/{orderId : \\d+}")
    ProcessingResult<User> viewPurchaserByOrderId(@CookieParam("__token__") String token, @PathParam("orderId") String orderId);

    @POST
    @Path("email/change")
    ProcessingResult changeEmail(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("password/change")
    ProcessingResult changePassword(@CookieParam("__token__") String token, Map<String, Object> params);

    @POST
    @Path("mobile/change")
    ProcessingResult changeMobile(@CookieParam("__token__") String token, Map<String, Object> params);

    //TODO 临时测试用方法，正式上线前删除
    @POST
    @Path("registerUserTemp")
    ProcessingResult registerUser( Map<String, Object> params);
}
