package com.uhui.configurable.api.Permission.checker;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.Permission.PermissionConstant;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Data;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.util.regex.Pattern;

/**
 * Created by Fidel on 2017/5/16.
 */
@Data
public class JsonResourcePermissionResolver implements ResourcePermissionResolver<String, String> {

    public static final String APPLICATION_PERMISSION_URL_MAPPING_KEY = "ApplicationPermissionUrlMapping";
    public static final String APPLICATION_PERMISSION_URL_MAPPING_URL_KEY = "url";
    public static final String APPLICATION_PERMISSION_URL_MAPPING_PERMISSION_KEY = "permission";

    private JSONObject resourcePermissionMapping;

    public JsonResourcePermissionResolver(String jsonResourcePermissionMappingPath) {
        try {
            InputStream resourceInputStream = this.getClass().getClassLoader().getResourceAsStream(jsonResourcePermissionMappingPath);
            String resourceContent = IOUtils.toString(resourceInputStream, "UTF-8");
            setResourcePermissionMapping(JSON.parseObject(resourceContent).getJSONObject(APPLICATION_PERMISSION_URL_MAPPING_KEY));
            if (getResourcePermissionMapping() == null) {
                BusinessException.throwBusinessException(BusinessExceptionType.RESOURCE, "JsonResourcePermissionResolver init failed.");
            }
        } catch (Exception e) {
            if (e instanceof BusinessException) {
                BusinessException be = (BusinessException) e;
                throw be;
            }
            BusinessException.throwBusinessException(BusinessExceptionType.RESOURCE, "JsonResourcePermissionResolver init failed.", e);
        }
    }

    @Override
    public String resolvePermission(String resource) {
        if (resource == null) {
            return null;
        }
        if (getResourcePermissionFromJSONArray(
                getResourcePermissionMapping().getJSONArray(PermissionConstant.PERMISSION_ANONYMOUS), resource)) {
            return PermissionConstant.PERMISSION_ANONYMOUS;
        }
        if (getResourcePermissionFromJSONArray(
                getResourcePermissionMapping().getJSONArray(PermissionConstant.PERMISSION_AUTHENTICATION), resource)) {
            return PermissionConstant.PERMISSION_AUTHENTICATION;
        }
        return getResourcePermissionFromMapping(
                getResourcePermissionMapping().getJSONObject(PermissionConstant.PERMISSIONS_AUTHORIZATION), resource);
    }

    private boolean getResourcePermissionFromJSONArray(JSONArray anonJson, String resource) {
        for (int i = 0; i < anonJson.size(); i++) {
            String anonResource = anonJson.getString(i);
            if (Pattern.compile(anonResource).matcher(resource).matches()) {
                return true;
            }
        }
        return false;
    }

    private String getResourcePermissionFromMapping(JSONObject mapping, String resource) {
        if (resource.equals(mapping.getString(APPLICATION_PERMISSION_URL_MAPPING_URL_KEY))) {
            return mapping.getString(APPLICATION_PERMISSION_URL_MAPPING_PERMISSION_KEY);
        }
        for (String key : mapping.keySet()) {
            try {
                JSONObject jsonObject = mapping.getJSONObject(key);
                String res = getResourcePermissionFromMapping(jsonObject, resource);
                if (res != null) {
                    return res;
                }
            } catch (Exception e) {
            }
        }
        return null;
    }
}
