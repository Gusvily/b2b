package com.uhui.configurable.api.service;

/**
 * Created by Fidel on 2017/4/25.
 */
public interface CardRechargeService {

    Boolean recharge(String cardId);

    Boolean queryRechargeInfo();

    Boolean checkSpStatus();

}
