package com.uhui.configurable.api.workflow;

import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import com.uhui.configurable.api.workflow.utils.CastUtils;
import com.uhui.configurable.api.workflow.utils.ParseUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/16.
 */
public class ProcessingNode {

    private static final Logger LOGGER = Logger.getLogger(ProcessingNode.class);

    public static final String PROCESSING_NODE_STATUS_READY = "ready";
    public static final String PROCESSING_NODE_STATUS_RUNNING = "running";
    public static final String PROCESSING_NODE_STATUS_FINISHED = "finished";

    public static final String PROCESSING_NODE_NAME_KEY = "name";
    public static final String PROCESSING_NODE_DEPENDENCY_KEY = "dependency";
    public static final String PROCESSING_NODE_INVOKE_KEY = "invoke";
    public static final String PROCESSING_NODE_ARGUMENTS_KEY = "arguments";
    public static final String PROCESSING_NODE_ARGUMENT_CLASSES_KEY = "argumentClasses";
    public static final String PROCESSING_NODE_RESULT_KEY = "result";
    public static final String PROCESSING_NODE_ALLOW_NULL_KEY = "allowNull";
    public static final String PROCESSING_NODE_SUB_NODE_KEY = "subNode";


    @Setter
    @Getter
    private String name;
    @Setter
    @Getter
    private ProcessingNode nextNode;
    @Getter
    private Map<Integer, ProcessingNode> subNodes;
    //    @Getter
//    private String status = PROCESSING_NODE_STATUS_READY;
    @Setter
    @Getter
    private String dependencyName;
    @Setter
    @Getter
    private String invokeName;
    @Setter
    @Getter
    private String[] arguments;
    @Setter
    @Getter
    private Class[] argumentClasses;
    @Setter
    @Getter
    private ProcessingNodeResult processingNodeResult;
    @Setter
    @Getter
    private boolean allowNull = false;

    public void setSubNode(int conditionalCode, ProcessingNode subNode) {
        if (subNodes == null) {
            subNodes = new HashMap<>();
        }
        subNodes.put(conditionalCode, subNode);
    }

    public ProcessingNode getSubNode(int conditionalCode) {
        if (subNodes != null) {
            return subNodes.get(conditionalCode);
        }
        return null;
    }

    public ProcessingResult invoke(final Map<String, SpringBean> dependencies, Map<String, Object> processingStack) {
//        if (status == PROCESSING_NODE_STATUS_READY) {
//            status = PROCESSING_NODE_STATUS_RUNNING;
//        } else if (status == PROCESSING_NODE_STATUS_RUNNING) {
//            LOGGER.warn("ProcessingNode status is running, please don't need invoke again.");
//            return null;
//        } else if (status == PROCESSING_NODE_STATUS_FINISHED) {
//            LOGGER.warn("ProcessingNode status is finished, please don't need invoke again.");
//            return null;
//        }
        LOGGER.info(String.format("ProcessingNode:%s Start.", name));
        ProcessingResult result = doInvoke(dependencies, processingStack);
        //TODO
        LOGGER.info(String.format("ProcessingNode:%s End.", name));
        return result;
    }

    private ProcessingResult doInvoke(final Map<String, SpringBean> dependencies, Map<String, Object> processingStack) {
        SpringBean dependencyBean = parseDependency(dependencies, dependencyName, processingStack);
        if (dependencyBean == null) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                    "Method invoke failed, dependency bean missed, invoke name: %s , dependency name: %s",
                    invokeName, dependencyName));
        }
        boolean needInitArgumentClasses = false;
        Object[] argumentInstances = null;
        if (arguments != null) {
            if (argumentClasses == null) {
                needInitArgumentClasses = true;
                argumentClasses = new Class[arguments.length];
            }
            argumentInstances = new Object[arguments.length];
            for (int i = 0; i < arguments.length; i++) {
                Object argumentInstance = parseArgument(processingStack, arguments[i]);
                if (!allowNull && argumentInstance == null) {
                    throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                            "Method invoke failed, missing input argument, invoke name: %s, argument name: %s", invokeName, arguments[i]));
                }
                if (needInitArgumentClasses) {
                    if (argumentInstance == null) {
                        argumentClasses[i] = Object.class;
                    } else {
                        argumentClasses[i] = argumentInstance.getClass();
                    }
                }
                argumentInstances[i] = argumentInstance;
            }
        }
        Method targetMethod = null;
        try {
            targetMethod = dependencyBean.getBeanClass().getMethod(invokeName, argumentClasses);
        } catch (Exception e) {
            for (Method method : dependencyBean.getBeanClass().getMethods()) {
                if (invokeName.equals(method.getName())) {
                    Class[] classes = method.getParameterTypes();
                    boolean assignable = true;
                    if (classes.length == argumentClasses.length) {
                        for (int i = 0; i < classes.length; i++) {
                            if (classes[i].isPrimitive()) {
                                try {
                                    if (classes[i] != argumentClasses[i].getField("TYPE").get(null)) {
                                        assignable = false;
                                        break;
                                    }
                                } catch (Exception e2) {
                                    assignable = false;
                                    break;
                                }
                            } else {
                                if (!classes[i].isAssignableFrom(argumentClasses[i])) {
                                    assignable = false;
                                    break;
                                }
                            }
                        }
                    } else {
                        assignable = false;
                    }
                    if (assignable) {
                        targetMethod = method;
                        break;
                    }
                }
            }
            if (targetMethod == null) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                        "Method invoke failed, processing node don't found target method via invoke name, invoke name: %s",
                        invokeName), e);
            }
        }
        ProcessingResult processingResult;
        try {
            if (argumentInstances != null) {
                if (argumentInstances.length != argumentClasses.length) {
                    throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                            "Method invoke failed, argument classes don't match type of argument instances, invoke name: %s",
                            invokeName));
                }
                CastUtils castUtils = new CastUtils();
                for (int i = 0; i < argumentClasses.length; i++) {
                    if (argumentInstances[i] != null && !argumentClasses[i].equals(argumentInstances[i].getClass())) {
                        if (argumentClasses[i].equals(String.class)) {
                            argumentInstances[i] = argumentInstances[i].toString();
                        } else {
                            argumentInstances[i] = castUtils.cast(argumentClasses[i], argumentInstances[i]);
                        }
                    }
                }
            }
            Object result = null;
            try {
                result = targetMethod.invoke(dependencyBean.getBeanInstance(), argumentInstances);
            } catch (InvocationTargetException ite) {
                throw new BusinessException(BusinessExceptionType.LOGIC, "Target method invoke failed.", ite.getTargetException());
            }
            if (result instanceof ProcessingResult) {
                processingResult = (ProcessingResult) result;
            } else {
                processingResult = ProcessingResult.succeeded(result);
            }
        } catch (Throwable t) {
            processingResult = ProcessingResult.failed(String.format(
                    "Method invoke failed, processing node invoke failed, dependency name: %s, invoke name: %s. %s %s",
                    dependencyBean.getBeanName(), invokeName, System.getProperty("line.separator"), ExceptionUtils.getStackTrace(t)));
        }
        if (processingNodeResult != null) {
            switch (processingNodeResult.getProcessingNodeResultAction()) {
                case STORE:
                    processingStack.put(processingNodeResult.getName(), processingResult);
                    break;
                case VARIABLE_STORE:
                    processingStack.put(processingNodeResult.getName(), processingResult.getDatas());
                    break;
                case SINGLE_VARIABLE_STORE:
                    if (processingResult.getResultSize() == 1) {
                        processingStack.put(processingNodeResult.getName(), processingResult.getDatas().get(0));
                    } else if (processingResult.getResultSize() == 0) {
                        processingStack.put(processingNodeResult.getName(), null);
                    } else {
                        throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                                "Method invoke failed, processing node must return only one result when processing node result action is SINGLE_VARIABLE_STORE, processing node name: %s, current result size: %s",
                                name, processingResult.getResultSize()));
                    }
                    break;
                case CONDITIONAL_SUCCESS:
                    processingResult.setResultCode(processingNodeResult.getResultCode());
                    processingStack.put(processingNodeResult.getName(), processingResult);
                    break;
                case VARIABLE_CONDITIONAL_SUCCESS:
                    processingResult.setResultCode(processingNodeResult.getResultCode());
                    processingStack.put(processingNodeResult.getName(), processingResult.getDatas());
                    break;
                case SINGLE_VARIABLE_CONDITIONAL_SUCCESS:
                    processingResult.setResultCode(processingNodeResult.getResultCode());
                    if (processingResult.getResultSize() == 1) {
                        processingStack.put(processingNodeResult.getName(), processingResult.getDatas().get(0));
                    } else if (processingResult.getResultSize() == 0) {
                        processingStack.put(processingNodeResult.getName(), null);
                    } else {
                        throw new BusinessException(BusinessExceptionType.RESOURCE, String.format(
                                "Method invoke failed, processing node must return only one result when processing node result action is SINGLE_VARIABLE_CONDITIONAL_SUCCESS, processing node name: %s, current result size: %s",
                                name, processingResult.getResultSize()));
                    }
                    break;
                default:
            }
        }
        return processingResult;
    }

    private SpringBean parseDependency(Map<String, SpringBean> dependencies, String dependencyName, Map<String, Object> processingStack) {
        SpringBean dependencyBean = dependencies.get(dependencyName);
        if (dependencyBean == null) {
            ParseUtils parseUtils = new ParseUtils();
            Object parseValue = parseUtils.parseSpecialField(dependencyName, processingStack);
            if (parseValue != null) {
                if (parseValue instanceof Class) {
                    Class parseClass = (Class) parseValue;
                    dependencyBean = new SpringBean();
                    dependencyBean.setBeanClass(parseClass);
                    dependencyBean.setBeanName(parseClass.getSimpleName());
                    Object instance = null;
                    try {
                        instance = parseClass.newInstance();
                    } catch (Exception e) {
                        LOGGER.error("Dependency bean instantiation failed.", e);
                    }
                    dependencyBean.setBeanInstance(instance);
                } else {
                    dependencyBean = new SpringBean();
                    dependencyBean.setBeanClass(parseValue.getClass());
                    dependencyBean.setBeanName(parseValue.getClass().getSimpleName());
                    dependencyBean.setBeanInstance(parseValue);
                }
            }
        }
        return dependencyBean;
    }

    private Object parseArgument(Map<String, Object> processingStack, String argument) {
        ParseUtils parseUtils = new ParseUtils();
        Object result = parseUtils.parseStaticField(argument);

        if (result == null) {
            result = parseUtils.parseSpecialField(argument, processingStack);
        }
        if (result == null) {
            result = parseUtils.parseObject(processingStack, argument);
        }
        return result;
    }

}
