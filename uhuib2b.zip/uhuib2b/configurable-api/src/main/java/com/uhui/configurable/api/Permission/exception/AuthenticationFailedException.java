package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/12.
 */
public class AuthenticationFailedException extends PermissionException {

    public AuthenticationFailedException() {
        super("Account password not match.");
    }

    public AuthenticationFailedException(Throwable cause) {
        super("Account password not match.", cause);
    }
}
