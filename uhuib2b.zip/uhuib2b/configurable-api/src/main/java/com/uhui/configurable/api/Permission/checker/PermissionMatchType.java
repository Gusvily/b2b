package com.uhui.configurable.api.Permission.checker;

/**
 * Created by Fidel on 2017/5/22.
 */
public enum PermissionMatchType {

    MATCHING("matching", "Fully match permission."),
    MISMATCHING("mismatching", "Don't match permission"),
    CONDITIONAL_MATCHING("conditional matching", "Conditional match permission, need to check data level permission.");

    private final String matchType;
    private final String description;

    PermissionMatchType(String matchType, String description) {
        this.matchType = matchType;
        this.description = description;
    }

    public static PermissionMatchType matchType(String matchType) {
        for (PermissionMatchType permissionMatchType : PermissionMatchType.values()) {
            if (permissionMatchType.matchType.equals(matchType)) {
                return permissionMatchType;
            }
        }
        return null;
    }
}
