package com.uhui.configurable.api.workflow;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import com.uhui.configurable.api.workflow.utils.ExcelUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/2/28.
 */
public class ExcelDubboConfigurableWorkFlow extends DubboConfigurableWorkFlow {

    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY = "configurableWorkFlow";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_NAME = "Name：";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG = "DubboConfig：";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES = "Dependencies：";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_METHODS = "Methods：";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_PROCESSING_CHAIN_STRUCTURE = "processingChainStructure";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_PROCESSING_CHAIN_NODE_ID = "processingChainNodeID";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_ACTION = "resultAction";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_NAME = "resultName";
    public static final String EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_CODE = "resultCode";
    public static final String EXCEL_LINE_SEPARATOR = "\\n";

    ExcelUtils excelUtils = new ExcelUtils();

    @Override
    public WorkFlowConfig initResource(String resourcePath) {
        if (resourcePath == null || resourcePath.length() == 0) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Resource path must be not null.");
        }
        try {
            InputStream resourceInputStream = this.getClass().getClassLoader().getResourceAsStream(resourcePath);
            Workbook workbook = WorkbookFactory.create(resourceInputStream);

            Sheet workflowSheet = workbook.getSheet(CONFIGURABLE_WORKFLOW_KEY);
            int lastRowNum = workflowSheet.getLastRowNum();
            Map<String, Integer> partsIndexMap = new HashMap<>();
            for (int i = 0; i < lastRowNum; i++) {
                Row row = workflowSheet.getRow(i);
                if (row == null) {
                    continue;
                }
                Cell cell = row.getCell(0);
                if (cell == null) {
                    continue;
                }
                switch (cell.getStringCellValue()) {
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_NAME:
                        partsIndexMap.put(EXCEL_CONFIGURABLE_WORKFLOW_KEY_NAME, i);
                        break;
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG:
                        partsIndexMap.put(EXCEL_CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG, i);
                        break;
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES:
                        partsIndexMap.put(EXCEL_CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES, i);
                        break;
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_METHODS:
                        partsIndexMap.put(EXCEL_CONFIGURABLE_WORKFLOW_KEY_METHODS, i);
                        break;
                }
            }
            int methodsIndex = partsIndexMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_METHODS);
            setName(excelUtils.getCellStringValue(workflowSheet, partsIndexMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_NAME), 1));
            initDubboConfig(workflowSheet, partsIndexMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_DUBBO_CONFIG));
            initDependencies(workflowSheet, partsIndexMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_DEPENDENCIES), methodsIndex - 1);
            initProcessors(workflowSheet, methodsIndex, lastRowNum);
        } catch (Exception e) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Resource init failed, resource path: " + resourcePath, e);
        }
        return null;
    }


    private void initProcessors(Sheet workflowSheet, int firstRowIndex, int lastRowIndex) {
        List<int[]> parts = new ArrayList<>();
        for (int i = firstRowIndex; i < lastRowIndex; i++) {
            int[] indexes = new int[2];
            indexes[0] = i;
            boolean caughtContent = false;
            while (true) {
                if (excelUtils.isNotEmptyCell(workflowSheet, i, 1)) {
                    i++;
                    caughtContent = true;
                } else {
                    if (caughtContent) {
                        indexes[1] = i;
                        break;
                    } else {
                        i++;
                        if (i < lastRowIndex) {
                            indexes[0] = i;
                        }else {
                            break;
                        }
                    }
                }
            }
            if (indexes[1] >= indexes[0]) {
                parts.add(indexes);
            }
        }
        if (parts.size() < 1) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, no method defined.");
        }
        Map<String, Processor> methods = new HashMap<>();
        for (int[] indexes : parts) {
            ConfigurableProcessor processor = new ConfigurableProcessor();
            String processingChainStructure = null;
            Map<String, ProcessingNode> processingNodesMap = new HashMap<>();
            for (int i = indexes[0]; i < indexes[1]; i++) {
                String colnumOneValue = excelUtils.getCellStringValue(workflowSheet, i, 1);
                if (colnumOneValue == null) {
                    continue;
                }
                switch (colnumOneValue) {
                    case "name":
                        processor.setName(excelUtils.getCellStringValue(workflowSheet, i, 2));
                        break;
                    case Processor.PROCESOR_INPUT_KEY:
                        processor.setInputNames(excelUtils.getCellStringArray(workflowSheet, i, 2, EXCEL_LINE_SEPARATOR));
                        break;
                    case Processor.PROCESOR_OUTPUT_KEY:
                        processor.setOutputName(excelUtils.getCellStringValue(workflowSheet, i, 2));
                        break;
                    case Processor.PROCESOR_JSONP_METHOD_KEY:
                        processor.setJsonpMethod(Boolean.parseBoolean(excelUtils.getCellStringValue(workflowSheet, i, 2)));
                        break;
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_PROCESSING_CHAIN_STRUCTURE:
                        processingChainStructure = excelUtils.getCellStringValue(workflowSheet, i, 2);
                        break;
                    case EXCEL_CONFIGURABLE_WORKFLOW_KEY_PROCESSING_CHAIN_NODE_ID:
                        Row titleRow = workflowSheet.getRow(i);
                        Map<Integer, String> processingNodeIndexMap = new HashMap<>();
                        for (int j = 1; j < titleRow.getLastCellNum(); j++) {
                            Cell titleCell = titleRow.getCell(j);
                            if (titleCell == null) {
                                continue;
                            }
                            String title = titleCell.getStringCellValue();
                            processingNodeIndexMap.put(j, title);
                        }
                        for (int j = i + 1; j < indexes[1]; j++) {
                            Map<String, String> processingNodeContentMap = new HashMap<>();
                            Row contentRow = workflowSheet.getRow(j);
                            for (int k = 1; k < contentRow.getLastCellNum(); k++) {
                                Cell contentCell = contentRow.getCell(k);
                                if (contentCell == null) {
                                    continue;
                                }
                                String content = contentCell.getStringCellValue();
                                processingNodeContentMap.put(processingNodeIndexMap.get(k), content);
                            }
                            String processingChainNodeId = processingNodeContentMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_PROCESSING_CHAIN_NODE_ID);
                            ProcessingNode processingNode = buildProcessingNode(processingNodeContentMap, processingChainNodeId);
                            processingNodesMap.put(processingChainNodeId, processingNode);
                        }

                }
            }
            if (processingChainStructure == null) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing chain structure do not defined.");
            }
            JSONArray processingChainStructureArray = getProcessingChainStructureArray(processingChainStructure);
            ProcessingChain processingChain = new ProcessingChain();
            for (int i = 0; i < processingChainStructureArray.size(); i++) {
                String singleProcessingNodeStructure = processingChainStructureArray.getString(i);
                ProcessingNode processingNode = linkSubNodes(processingNodesMap, singleProcessingNodeStructure);
                if (processingNode == null) {
                    throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing chain structure do not matched with processing nodes map.");
                }
                processingChain.setNode(processingNode);
            }
            processor.setProcessingChain(processingChain);
            methods.put(processor.getName(), processor);
        }
        setWorkFlowMethods(methods);
    }

    private JSONArray getProcessingChainStructureArray(String processingChainStructure) {
        return JSON.parseArray("["+processingChainStructure+"]");
    }

    private ProcessingNode linkSubNodes(Map<String, ProcessingNode> processingNodesMap, String singleProcessingNodeStructure) {
        ProcessingNode processingNode;
        int jsonStartIndex = singleProcessingNodeStructure.indexOf("{");
        if (jsonStartIndex < 0) {
            processingNode = processingNodesMap.get(singleProcessingNodeStructure);
        } else if (jsonStartIndex > 0) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing chain structure syntax error.");
        } else {
            JSONObject nodeJsonIndexes = JSON.parseObject(singleProcessingNodeStructure);
            String processingNodeKey = nodeJsonIndexes.getString("point");
            processingNode = processingNodesMap.get(processingNodeKey);
            JSONObject subNodeJsonIndexes = nodeJsonIndexes.getJSONObject("subNode");
            if (subNodeJsonIndexes != null) {
                for (String key : subNodeJsonIndexes.keySet()) {
                    String value = subNodeJsonIndexes.getString(key);
                    ProcessingNode subProcessingNode = linkSubNodes(processingNodesMap, value);
                    processingNode.setSubNode(Integer.parseInt(key), subProcessingNode);
                }
            }
        }
        return processingNode;
    }

    private ProcessingNode buildProcessingNode(Map<String, String> processingNodeContentMap, String indexSuffix) {
        ProcessingNode processingNode = new ProcessingNode();
        String processingNodeDependencyName = processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_DEPENDENCY_KEY);
        if (processingNodeDependencyName == null) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing node dependency init unsuccessfully.");
        }
        String processingNodeInvokeName = processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_INVOKE_KEY);
        if (processingNodeInvokeName == null) {
            throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, processing node invoke init unsuccessfully.");
        }
        String processingNodeName = processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_NAME_KEY);
        if (processingNodeName == null) {
            processingNodeName = generateDefaultProcessingNodeName(processingNodeDependencyName, processingNodeInvokeName, indexSuffix);
        }
        String[] argumentsArray = null;
        String argumentsString = processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_ARGUMENTS_KEY);
        if (StringUtils.isNotEmpty(argumentsString)) {
            argumentsArray = argumentsString.split(EXCEL_LINE_SEPARATOR);
        }
        String[] argumentClassesStringArray = null;
        String argumentClassesString = processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_ARGUMENT_CLASSES_KEY);
        if (StringUtils.isNotEmpty(argumentClassesString)) {
            argumentClassesStringArray = argumentClassesString.split(EXCEL_LINE_SEPARATOR);
        }
        processingNode.setName(processingNodeName);
        processingNode.setDependencyName(processingNodeDependencyName);
        processingNode.setInvokeName(processingNodeInvokeName);
        if (argumentsArray != null && argumentsArray.length > 0) {
            processingNode.setArguments(argumentsArray);
        }
        if (argumentClassesStringArray != null && argumentClassesStringArray.length > 0) {
            try {
                Class[] argumentClassesArray = new Class[argumentClassesStringArray.length];
                for (int j = 0; j < argumentClassesArray.length; j++) {
                    String className = argumentClassesStringArray[j];
                    argumentClassesArray[j] = Class.forName(className);
                }
                processingNode.setArgumentClasses(argumentClassesArray);
            } catch (Exception e) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, "Processors init failed, argument classes init unsuccessfully.", e);
            }
        }
        String resultAction = processingNodeContentMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_ACTION);
        String resultName = processingNodeContentMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_NAME);
        String resultCode = processingNodeContentMap.get(EXCEL_CONFIGURABLE_WORKFLOW_KEY_RESULT_CODE);
        if (StringUtils.isNotEmpty(resultAction) && StringUtils.isNotEmpty(resultName)) {
            ProcessingNodeResultAction processingNodeResultAction = ProcessingNodeResultAction.valueOf(resultAction.toUpperCase());
            String processingNodeResultName = resultName;
            Integer processingNodeCode = null;
            if (StringUtils.isNotEmpty(resultCode)) {
                processingNodeCode = Integer.parseInt(resultCode);
            }
            ProcessingNodeResult processingNodeResult =
                    new ProcessingNodeResult(processingNodeResultAction, processingNodeResultName, processingNodeCode);
            processingNode.setProcessingNodeResult(processingNodeResult);
        }
        Boolean allowNullJsonValue = Boolean.valueOf(processingNodeContentMap.get(ProcessingNode.PROCESSING_NODE_ALLOW_NULL_KEY));
        if (allowNullJsonValue != null) {
            processingNode.setAllowNull(allowNullJsonValue);
        }
        return processingNode;
    }


    private void initDependencies(Sheet workflowSheet, int firstRowIndex, int lastRowIndex) {
        Row titleRow = workflowSheet.getRow(firstRowIndex);
        Map<String, Integer> titleIndexMap = new HashMap<>();
        for (int i = 1; i < titleRow.getLastCellNum(); i++) {
            Cell titleCell = titleRow.getCell(i);
            if (titleCell == null) {
                continue;
            }
            String title = titleCell.getStringCellValue();
            if (SpringBean.STRING_BEAN_NAME_KEY.equals(title) || SpringBean.STRING_BEAN_CLASS_KEY.equals(title)) {
                titleIndexMap.put(title, i);
            }
        }
        Map<String, SpringBean> springBeans = new HashMap<>();
        for (int i = firstRowIndex + 1; i < lastRowIndex; i++) {
            Row contentRow = workflowSheet.getRow(i);
            String beanName = contentRow.getCell(titleIndexMap.get(SpringBean.STRING_BEAN_NAME_KEY)).getStringCellValue();
            String beanClass = contentRow.getCell(titleIndexMap.get(SpringBean.STRING_BEAN_CLASS_KEY)).getStringCellValue();
            Class beanClz;
            try {
                beanClz = Class.forName(beanClass);
            } catch (ClassNotFoundException e) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("Dependency init failed, bean name: %s, bean class: %s", beanName, beanClass), e);
            }
            SpringBean springBean = new SpringBean();
            springBean.setBeanName(beanName);
            springBean.setBeanClass(beanClz);
            springBeans.put(beanName, springBean);
        }
        setWorkFlowDependencies(springBeans);
    }

    private void initDubboConfig(Sheet workflowSheet, int firstRowIndex) {
        Row titleRow = workflowSheet.getRow(firstRowIndex);
        Row contentRow = workflowSheet.getRow(firstRowIndex + 1);
        for (int i = 1; i < titleRow.getLastCellNum(); i++) {
            Cell titleCell = titleRow.getCell(i);
            Cell contentCell = contentRow.getCell(i);
            if (titleCell == null || contentCell == null) {
                continue;
            }
            String title = titleCell.getStringCellValue();
            String value = contentCell.getStringCellValue();
            Class configType = DubboConfigMapping.getType(title).clz();
            if (configType == null) {
                throw new BusinessException(BusinessExceptionType.RESOURCE, String.format("DubboConfig init failed, config name: %s, config value: %s", title, value));
            }
            initField(title, value);
        }
    }


    private String generateDefaultProcessingNodeName(String processingNodeDependencyName, String processingNodeInvokeName, String indexSuffix) {
        return new StringBuffer(processingNodeDependencyName)
                .append("_").append(processingNodeInvokeName).append("__").append(indexSuffix).toString();
    }


}