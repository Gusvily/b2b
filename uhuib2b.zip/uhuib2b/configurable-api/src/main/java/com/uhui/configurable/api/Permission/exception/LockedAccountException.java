package com.uhui.configurable.api.Permission.exception;

/**
 * Created by Fidel on 2017/5/12.
 */
public class LockedAccountException extends PermissionException {

    public LockedAccountException() {
        super("Account inactive.");
    }

    public LockedAccountException(Throwable cause) {
        super("Account inactive.", cause);
    }
}
