package com.uhui.configurable.api.workflow.utils;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;

/**
 * Created by Fidel on 2017/5/27.
 */
public class ExcelUtils {

    public String getCellStringValue(Sheet workflowSheet, int rowIndex, int cellIndex) {
        try {
            return workflowSheet.getRow(rowIndex).getCell(cellIndex).getStringCellValue();
        } catch (Exception e) {
            return null;
        }
    }

    public String[] getCellStringArray(Sheet workflowSheet, int rowIndex, int cellIndex, String arraySeparator) {
        try {
            return workflowSheet.getRow(rowIndex).getCell(cellIndex).getStringCellValue().split(arraySeparator);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean isNotEmptyCell(Sheet workflowSheet, int rowIndex, int cellIndex) {
        try {
            Cell cell = workflowSheet.getRow(rowIndex).getCell(cellIndex);
            return !cell.getCellTypeEnum().equals(CellType.BLANK);
        } catch (Exception e) {
            return false;
        }
    }
}
