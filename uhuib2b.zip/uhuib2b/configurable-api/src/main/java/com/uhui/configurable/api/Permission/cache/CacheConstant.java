package com.uhui.configurable.api.Permission.cache;

/**
 * Created by Fidel on 2017/5/16.
 */
public interface CacheConstant {
    String PASSWORD_RETRY_CACHE_KEY = "passwordRetryCache";
    String USER_CACHE_PREFIX_KEY = "USER:";
    String REDIS_TOKEN_CACHE_KEY = "redisTokenCacheKey";
    String ALL_PERMISSIONS_CACHE_KEY = "allPermissionsCacheKey";
    String CACHE_CURRENT_USER_KEY =  "currentUser";
    String CACHE_CURRENT_ACTION_PERMISSION_KEY ="currentActionPermission";
    String CACHE_CURRENT_USER_PERMISSIONS_KEY ="currentUserPermissions";
    String CACHE_ALL_PERMISSIONS_KEY ="allPermissions";
}
