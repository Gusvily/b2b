package com.uhui.configurable.api.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by Fidel on 2017/5/15.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Privilege extends BaseModel {

    public static final String TABLE_NAME = "privilege";

    private String module;
    private String action;
    private String operation;
    private String operationDetails;
    private String description;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }
}
