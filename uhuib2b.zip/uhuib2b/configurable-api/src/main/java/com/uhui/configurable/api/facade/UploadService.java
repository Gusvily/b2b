package com.uhui.configurable.api.facade;

import com.alibaba.dubbo.rpc.protocol.rest.support.ContentType;
import com.uhui.configurable.api.workflow.ProcessingResult;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Created by Fidel on 2017/4/20.
 */
@Path("upload")
@Produces({ContentType.APPLICATION_JSON_UTF_8})
public interface UploadService {

    @POST
    @Path("user/image/{field : \\w+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    ProcessingResult userImage(@CookieParam("__token__") String token, @PathParam("field") String field, MultipartFormDataInput input);

    @POST
    @Path("company/logo/{field : \\w+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    ProcessingResult companyLogo(@CookieParam("__token__") String token, @PathParam("field") String field, MultipartFormDataInput input);

    @POST
    @Path("company/business/license/{field : \\w+}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    ProcessingResult companyBusinessLicense(@CookieParam("__token__") String token, @PathParam("field") String field, MultipartFormDataInput input);
}
