package com.uhui.configurable.api.workflow.utils;

import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/6/8.
 */
public class EmptyUtils {

    public boolean addNotEmpty(List list, String target) {
        return addNotEmpty(list, target, null);
    }

    public boolean addNotEmpty(List list, String target, String format) {
        if (list == null || target == null) {
            return false;
        }
        if (format == null) {
            list.add(target);
        } else {
            list.add(String.format(format, target));
        }
        return true;
    }

    public boolean addNotEmpty(Map map, String target, Object key) {
        return addNotEmpty(map, target, key, null);
    }

    public boolean addNotEmpty(Map map, String target, Object key, String format) {
        if (map == null || target == null) {
            return false;
        }
        if (format == null) {
            map.put(key, target);
        } else {
            map.put(key, String.format(format, target));
        }
        return true;
    }
}
