package com.uhui.configurable.api.workflow.utils;

import com.alibaba.fastjson.JSON;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Created by Fidel on 2017/4/18.
 */
public class CastUtils {

    public Object cast(Class clz, Object object) {
        if (clz == Long.class) {
            return Long.valueOf(object.toString());
        } else if (clz == Double.class) {
            return Double.valueOf(object.toString());
        } else if (clz == BigInteger.class) {
            return new BigInteger(object.toString());
        } else if (clz == BigDecimal.class) {
            return new BigDecimal(object.toString());
        } else {
            return clz.cast(object);
        }
    }

    public <T> T castJson(String jsonString, Class<T> clz) {
        return JSON.parseObject(jsonString, clz);
    }
}
