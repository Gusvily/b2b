package com.uhui.configurable.api.workflow.utils;

import com.alibaba.fastjson.JSON;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * Created by Fidel on 2017/4/18.
 */
public class CastUtils {

    public Object cast(Class clz, Object object) {
        if (clz == Long.class) {
            return Long.valueOf(object.toString());
        } else if (clz == Double.class) {
            return Double.valueOf(object.toString());
        } else if (clz == BigInteger.class) {
            return new BigInteger(object.toString());
        } else if (clz == BigDecimal.class) {
            return new BigDecimal(object.toString());
        } else {
            return clz.cast(object);
        }
    }

    public <T> T castJson(String jsonString, Class<T> clz) {
        return JSON.parseObject(jsonString, clz);
    }

    public <T> T[] listToArray(List list, Class<T> clz) {
        T[] array = (T[]) Array.newInstance(clz, list.size());
        for (int i = 0; i < array.length; i++) {
            array[i] = (T) list.get(i);
        }
        return array;
    }

    public String[] listToStringArray(List list) {
        String[] array = new String[list.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = list.get(i).toString();
        }
        return array;
    }

}
