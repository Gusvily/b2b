package com.uhui.configurable.api.workflow;

import java.util.Map;

/**
 * Created by Fidel on 2017/3/16.
 */
public class ProcessingChain {

    private ProcessingNode rootNode;
    private ProcessingNode currentNode;

    public ProcessingResult invoke(final Map<String, SpringBean> dependencies, Map<String, Object> processingStack) {
        return nodeInvoke(rootNode, dependencies, processingStack);
    }

    private ProcessingResult nodeInvoke(ProcessingNode node, final Map<String, SpringBean> dependencies, Map<String, Object> processingStack) {
        currentNode = node;
        ProcessingResult result = node.invoke(dependencies, processingStack);
        switch (result.getStatus()) {
            case ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS:
                int resultCode = result.getResultCode();
                if (resultCode >= ProcessingResult.PROCESSING_RESULT_CODE_FIRST_CONDITIONAL_SUCCESS &&
                        resultCode < ProcessingResult.PROCESSING_RESULT_CODE_UNKNOWN) {
                    ProcessingNode subNode = node.getSubNode(result.getResultCode());
                    if (subNode != null) {
                        result = nodeInvoke(subNode, dependencies, processingStack);
                    }
                }
                break;
            case ProcessingResult.PROCESSING_RESULT_STATUS_FAILURE:
                return result;
            case ProcessingResult.PROCESSING_RESULT_STATUS_UNKNOWN:
                //TODO
                break;
        }
        if (ProcessingResult.PROCESSING_RESULT_STATUS_SUCCESS.equals(result.getStatus())) {
            ProcessingNode nextNode = node.getNextNode();
            if (nextNode != null) {
                return nodeInvoke(nextNode, dependencies, processingStack);
            }
        }
        return result;
    }

    public void setNode(ProcessingNode node) {
        if (rootNode == null) {
            rootNode = node;
        } else {
            ProcessingNode currentLoopNode = rootNode;
            while (true) {
                if (currentLoopNode.getNextNode() != null) {
                    currentLoopNode = currentLoopNode.getNextNode();
                } else {
                    currentLoopNode.setNextNode(node);
                    break;
                }
            }
        }
    }
}
