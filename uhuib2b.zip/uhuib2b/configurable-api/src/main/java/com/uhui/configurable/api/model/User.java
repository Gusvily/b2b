package com.uhui.configurable.api.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.uhui.configurable.api.Permission.model.RoleModel;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Setter;
import org.apache.commons.codec.digest.DigestUtils;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Random;

@Data
@EqualsAndHashCode(callSuper = false)
public class User extends BusinessModel implements RoleModel {
    public static final String USERNAME_PATTERN = "^[\\u4E00-\\u9FA5\\uf900-\\ufa2d_a-zA-Z][\\u4E00-\\u9FA5\\uf900-\\ufa2d\\w]{1,19}$";
    public static final String EMAIL_PATTERN = "^((([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+(\\.([a-z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(\\\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|\\d|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.)+(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])|(([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])([a-z]|\\d|-|\\.|_|~|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])*([a-z]|[\\u00A0-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFEF])))\\.?";

    public static final Integer USER_STATUS_ACTIVE = 1;
    public static final Integer USER_STATUS_INACTIVE = 0;
    public static final Integer USER_STATUS_FROZEN = 2;

    public static final String TABLE_NAME = "user";

    public static final int PASSWORD_MIN_LENGTH = 6;
    public static final int PASSWORD_MAX_LENGTH = 20;

    public static final int MAX_RETRY_COUNT = 5;

    @JsonProperty("username")
    @NotNull
    @Pattern(regexp = USERNAME_PATTERN, message = "{user.username.not.valid}")
    private String name;
    @JsonIgnore
    private String pwd;

    @Pattern(regexp = EMAIL_PATTERN, message = "{user.email.not.valid}")
    private String email;

    private Boolean emailIsValidated;

    private String mobilePhone;

    private Boolean mobilePhoneIsValidated;

    private Integer status;

    @JsonIgnore
    @Setter(AccessLevel.PRIVATE)
    private String salt;

    private Boolean isCreator;

    private String imageUrl;

    private String imageUrlFileName;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }

    public void resetPwd(String pwd) {
        String nSalt = buildSalt(pwd);
        String nPwd = buildPwd(nSalt, pwd);
        this.salt = nSalt;
        this.pwd = nPwd;
    }

    /**
     * validate password
     *
     * @param pwd
     * @return true if the pwd is same with input
     */
    public boolean validatePassword(String pwd) {
        return this.pwd != null
                && this.pwd.equals(buildPwd(getSalt(), pwd));
    }

    public String buildToken() {
        Random random = new Random();
        String randomKey = String.valueOf(random.nextLong()) + String.valueOf(random.nextLong());
        String md5 = DigestUtils.md5Hex(randomKey);
        return DigestUtils.md5Hex(md5 + random.nextLong());
    }

    private String buildPwd(String salt, String pwd) {
        String md5 = DigestUtils.md5Hex(pwd);
        return DigestUtils.md5Hex(md5 + salt);
    }

    private String buildSalt(String specialId) {
        Random random = new Random();
        String saltKey = String.valueOf(random.nextLong()) + specialId + String.valueOf(random.nextLong());
        return DigestUtils.md5Hex(saltKey);
    }

    @JsonIgnore
    @Override
    public String getOwner() {
        return Long.toString(getId());
    }

    @JsonIgnore
    @Override
    public String getGroup() {
        return getGroupId() == null ? null : Long.toString(getGroupId());
    }
}
