package com.uhui.configurable.api.model;

import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.validation.constraints.NotNull;
import java.util.Random;

@Data
@EqualsAndHashCode(callSuper = false)
public class User extends BaseModel {

    public static final String TABLE_NAME = "user";

    @JsonProperty("username")
    @NotNull
    private String name;
    @JsonIgnore
    private String pwd;
    @NotNull
    private String mobilePhone;

    private Boolean mobilePhoneIsValidated;

    private Integer status;

    @JsonIgnore
    private String salt;

    private String imageUrl;

    private String imageUrlFileName;

    @Override
    public String getTable() {
        return TABLE_NAME;
    }

    public String resetToken(String specialId) {
        String nSalt = buildSalt(specialId);
        String nToken = buildToken(nSalt, specialId);
        this.salt = nSalt;
        return nToken;
    }

    public String buildToken(String specialId) {
        String salt = getSalt();
        if (StringUtils.isNotEmpty(salt)) {
            return buildToken(salt, specialId);
        } else {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Please use real user to build token.");
        }
    }

    private String buildToken(String salt, String specialId) {
        String md5 = DigestUtils.md5Hex(specialId);
        return DigestUtils.md5Hex(md5 + salt);
    }

    private String buildSalt(String specialId) {
        Random random = new Random();
        String saltKey = String.valueOf(random.nextLong()) + specialId + String.valueOf(random.nextLong());
        return DigestUtils.md5Hex(saltKey);
    }
}
