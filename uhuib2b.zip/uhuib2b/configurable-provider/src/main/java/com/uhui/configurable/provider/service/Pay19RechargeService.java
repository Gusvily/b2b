package com.uhui.configurable.provider.service;

import com.uhui.configurable.provider.utils.HttpsClientUtil;
import com.uhui.configurable.api.service.CardRechargeService;
import org.apache.commons.codec.digest.DigestUtils;

import java.net.URLEncoder;

/**
 * Created by Fidel on 2017/4/25.
 */
public class Pay19RechargeService implements CardRechargeService {
    //TODO 测试环境，上到生产环境之前请替换以下配置
    private static final String CHARSET_GBK = "GBK";
    private static final String PAY19_URL = "http://114.247.40.65:18030/game/gameEsalesServlet.do";
    private static final String MERCHANT_ID = "agenttest";
    private static final String MERCHANT_KEY = "123456789";


    @Override
    public Boolean recharge(String cardId) {
        String param = "?commandid=gamequery&protocolid=gmcard&merchantid=" + MERCHANT_ID + "&version=1";
        String sign = sign(param + "&key=123456789");
        String encodeStr = null;
        try {
            encodeStr = URLEncoder.encode(param + "&sign=" + sign, CHARSET_GBK);
            HttpsClientUtil clientUtil = new HttpsClientUtil();
            String result = clientUtil.doGet(PAY19_URL + encodeStr, CHARSET_GBK);
            System.out.println(result);
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public static void main(String[] args) {
        Pay19RechargeService service = new Pay19RechargeService();
        service.recharge(null);
    }

    @Override
    public Boolean queryRechargeInfo() {
//        return CHANGE_ME.queryRechargeInfo();
        return null;
    }

    @Override
    public Boolean checkSpStatus() {
//        return CHANGE_ME.checkSpStatus();
        return null;
    }

    private String sign(String str) {
        String md5 = DigestUtils.md5Hex(str + "&key=" + MERCHANT_KEY);
        return DigestUtils.md5Hex(MERCHANT_KEY + md5 + MERCHANT_KEY);
    }

    private String responseSign(String responseStr) {
        String md5 = DigestUtils.md5Hex(responseStr + "&" + MERCHANT_KEY);
        return DigestUtils.md5Hex(MERCHANT_KEY + md5 + MERCHANT_KEY);
    }
}
