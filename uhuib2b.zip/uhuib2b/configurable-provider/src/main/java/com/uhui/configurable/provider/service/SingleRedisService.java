package com.uhui.configurable.provider.service;

import com.uhui.configurable.api.service.RedisService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.BinaryClient;
import redis.clients.jedis.BitPosParams;
import redis.clients.jedis.GeoCoordinate;
import redis.clients.jedis.GeoRadiusResponse;
import redis.clients.jedis.GeoUnit;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.ScanParams;
import redis.clients.jedis.ScanResult;
import redis.clients.jedis.SortingParams;
import redis.clients.jedis.Tuple;
import redis.clients.jedis.params.geo.GeoRadiusParam;
import redis.clients.jedis.params.sortedset.ZAddParams;
import redis.clients.jedis.params.sortedset.ZIncrByParams;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by Fidel on 2017/3/20.
 */
@Service
public class SingleRedisService implements RedisService {

    private static final Logger LOGGER = Logger.getLogger(SingleRedisService.class);

    @Autowired
    private JedisPool jedisPool;

    @Override
    public Boolean addInsertLock(String specialId) {
        String res = setex(INSERT_LOCK_PREFIX + specialId, INSERT_LOCK_LIFECYCLE, "LOCKED");
        if ("OK".equals(res)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Boolean hasInsertLock(String specialId) {
        String res = get(INSERT_LOCK_PREFIX + specialId);
        if (res != null) {
            return true;
        }
        return false;
    }

    @Override
    public Boolean exists(byte[] key) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.exists(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String set(byte[] key, byte[] value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.set(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long expire(byte[] key, int seconds) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.expire(key, seconds);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public byte[] get(byte[] key) {
        byte[] res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.get(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String set(String key, String value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.set(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String set(String key, String value, String nxxx, String expx, long time) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.set(key, value, nxxx, expx, time);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String set(String key, String value, String nxxx) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.set(key, value, nxxx);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String get(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.get(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean exists(String key) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.exists(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long persist(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.persist(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String type(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.type(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long expire(String key, int seconds) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.expire(key, seconds);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long pexpire(String key, long milliseconds) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.pexpire(key, milliseconds);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long expireAt(String key, long unixTime) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.expireAt(key, unixTime);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long pexpireAt(String key, long millisecondsTimestamp) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.pexpireAt(key, millisecondsTimestamp);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long ttl(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.ttl(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long pttl(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.pttl(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean setbit(String key, long offset, boolean value) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.setbit(key, offset, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean setbit(String key, long offset, String value) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.setbit(key, offset, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean getbit(String key, long offset) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.getbit(key, offset);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long setrange(String key, long offset, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.setrange(key, offset, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String getrange(String key, long startOffset, long endOffset) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.getrange(key, startOffset, endOffset);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String getSet(String key, String value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.getSet(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long setnx(String key, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.setnx(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String setex(String key, int seconds, String value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.setex(key, seconds, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String psetex(String key, long milliseconds, String value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.psetex(key, milliseconds, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long decrBy(String key, long integer) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.decrBy(key, integer);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long decr(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.decr(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long incrBy(String key, long integer) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.incrBy(key, integer);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double incrByFloat(String key, double value) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.incrByFloat(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long incr(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.incr(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long append(String key, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.append(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String substr(String key, int start, int end) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.substr(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long hset(String key, String field, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hset(key, field, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String hget(String key, String field) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hget(key, field);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long hsetnx(String key, String field, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hsetnx(key, field, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String hmset(String key, Map<String, String> hash) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hmset(key, hash);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> hmget(String key, String... fields) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hmget(key, fields);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long hincrBy(String key, String field, long value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hincrBy(key, field, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double hincrByFloat(String key, String field, double value) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hincrByFloat(key, field, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean hexists(String key, String field) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hexists(key, field);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long hdel(String key, String... field) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hdel(key, field);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long hlen(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hlen(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> hkeys(String key) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hkeys(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> hvals(String key) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hvals(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Map<String, String> hgetAll(String key) {
        Map<String, String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hgetAll(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long rpush(String key, String... string) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.rpush(key, string);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long lpush(String key, String... string) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lpush(key, string);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long llen(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.llen(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> lrange(String key, long start, long end) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lrange(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String ltrim(String key, long start, long end) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.ltrim(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String lindex(String key, long index) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lindex(key, index);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String lset(String key, long index, String value) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lset(key, index, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long lrem(String key, long count, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lrem(key, count, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String lpop(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lpop(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String rpop(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.rpop(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long sadd(String key, String... member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sadd(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> smembers(String key) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.smembers(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long srem(String key, String... member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.srem(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String spop(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.spop(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> spop(String key, long count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.spop(key, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long scard(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.scard(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Boolean sismember(String key, String member) {
        Boolean res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sismember(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String srandmember(String key) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.srandmember(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> srandmember(String key, int count) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.srandmember(key, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long strlen(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.strlen(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zadd(String key, double score, String member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zadd(key, score, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zadd(String key, double score, String member, ZAddParams params) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zadd(key, score, member, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zadd(String key, Map<String, Double> scoreMembers) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zadd(key, scoreMembers);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zadd(String key, Map<String, Double> scoreMembers, ZAddParams params) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zadd(key, scoreMembers, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrange(String key, long start, long end) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrange(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zrem(String key, String... member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrem(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double zincrby(String key, double score, String member) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zincrby(key, score, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double zincrby(String key, double score, String member, ZIncrByParams params) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zincrby(key, score, member, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zrank(String key, String member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrank(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zrevrank(String key, String member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrank(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrange(String key, long start, long end) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrange(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrangeWithScores(String key, long start, long end) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeWithScores(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrevrangeWithScores(String key, long start, long end) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeWithScores(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zcard(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zcard(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double zscore(String key, String member) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zscore(key, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> sort(String key) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sort(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> sort(String key, SortingParams sortingParameters) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sort(key, sortingParameters);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zcount(String key, double min, double max) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zcount(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zcount(String key, String min, String max) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zcount(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByScore(String key, double min, double max) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScore(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByScore(String key, String min, String max) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScore(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByScore(String key, double max, double min) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScore(key, max, min);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByScore(String key, double min, double max, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScore(key, min, max, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByScore(String key, String max, String min) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScore(key, max, min);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByScore(String key, String min, String max, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScore(key, min, max, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByScore(String key, double max, double min, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScore(key, max, min, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScoreWithScores(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScoreWithScores(key, max, min);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrangeByScoreWithScores(String key, double min, double max, int offset, int count) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScoreWithScores(key, min, max, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByScore(String key, String max, String min, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScore(key, max, min, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScoreWithScores(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScoreWithScores(key, max, min);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrangeByScoreWithScores(String key, String min, String max, int offset, int count) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByScoreWithScores(key, min, max, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrevrangeByScoreWithScores(String key, double max, double min, int offset, int count) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScoreWithScores(key, max, min, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<Tuple> zrevrangeByScoreWithScores(String key, String max, String min, int offset, int count) {
        Set<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByScoreWithScores(key, max, min, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zremrangeByRank(String key, long start, long end) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zremrangeByRank(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zremrangeByScore(String key, double start, double end) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zremrangeByScore(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zremrangeByScore(String key, String start, String end) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zremrangeByScore(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zlexcount(String key, String min, String max) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zlexcount(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByLex(String key, String min, String max) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByLex(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrangeByLex(String key, String min, String max, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrangeByLex(key, min, max, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByLex(String key, String max, String min) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByLex(key, max, min);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Set<String> zrevrangeByLex(String key, String max, String min, int offset, int count) {
        Set<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zrevrangeByLex(key, max, min, offset, count);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long zremrangeByLex(String key, String min, String max) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zremrangeByLex(key, min, max);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long linsert(String key, BinaryClient.LIST_POSITION where, String pivot, String value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.linsert(key, where, pivot, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long lpushx(String key, String... string) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.lpushx(key, string);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long rpushx(String key, String... string) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.rpushx(key, string);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> blpop(String arg) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.blpop(arg);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> blpop(int timeout, String key) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.blpop(timeout, key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> brpop(String arg) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.brpop(arg);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> brpop(int timeout, String key) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.brpop(timeout, key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long del(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.del(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public String echo(String string) {
        String res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.echo(string);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long move(String key, int dbIndex) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.move(key, dbIndex);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long bitcount(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.bitcount(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long bitcount(String key, long start, long end) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.bitcount(key, start, end);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long bitpos(String key, boolean value) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.bitpos(key, value);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long bitpos(String key, boolean value, BitPosParams params) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.bitpos(key, value, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Map.Entry<String, String>> hscan(String key, int cursor) {
        ScanResult<Map.Entry<String, String>> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<String> sscan(String key, int cursor) {
        ScanResult<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Tuple> zscan(String key, int cursor) {
        ScanResult<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Map.Entry<String, String>> hscan(String key, String cursor) {
        ScanResult<Map.Entry<String, String>> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Map.Entry<String, String>> hscan(String key, String cursor, ScanParams params) {
        ScanResult<Map.Entry<String, String>> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.hscan(key, cursor, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<String> sscan(String key, String cursor) {
        ScanResult<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<String> sscan(String key, String cursor, ScanParams params) {
        ScanResult<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.sscan(key, cursor, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Tuple> zscan(String key, String cursor) {
        ScanResult<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zscan(key, cursor);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public ScanResult<Tuple> zscan(String key, String cursor, ScanParams params) {
        ScanResult<Tuple> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.zscan(key, cursor, params);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long pfadd(String key, String... elements) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.pfadd(key, elements);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public long pfcount(String key) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.pfcount(key);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long geoadd(String key, double longitude, double latitude, String member) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geoadd(key, longitude, latitude, member);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Long geoadd(String key, Map<String, GeoCoordinate> memberCoordinateMap) {
        Long res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geoadd(key, memberCoordinateMap);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double geodist(String key, String member1, String member2) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geodist(key, member1, member2);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public Double geodist(String key, String member1, String member2, GeoUnit unit) {
        Double res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geodist(key, member1, member2, unit);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<String> geohash(String key, String... members) {
        List<String> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geohash(key, members);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<GeoCoordinate> geopos(String key, String... members) {
        List<GeoCoordinate> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.geopos(key, members);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<GeoRadiusResponse> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit) {
        List<GeoRadiusResponse> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.georadius(key, longitude, latitude, radius, unit);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<GeoRadiusResponse> georadius(String key, double longitude, double latitude, double radius, GeoUnit unit, GeoRadiusParam param) {
        List<GeoRadiusResponse> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.georadius(key, longitude, latitude, radius, unit, param);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<GeoRadiusResponse> georadiusByMember(String key, String member, double radius, GeoUnit unit) {
        List<GeoRadiusResponse> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.georadiusByMember(key, member, radius, unit);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<GeoRadiusResponse> georadiusByMember(String key, String member, double radius, GeoUnit unit, GeoRadiusParam param) {
        List<GeoRadiusResponse> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.georadiusByMember(key, member, radius, unit, param);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }

    @Override
    public List<Long> bitfield(String key, String... arguments) {
        List<Long> res = null;
        Jedis jedis = null;
        try {
            jedis = jedisPool.getResource();
            res = jedis.bitfield(key, arguments);
        } catch (Exception e) {
            LOGGER.error("SingleRedisService execute failed.", e);
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
        return res;
    }
}
