package com.uhui.configurable.provider.repository.dao;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/3/27.
 */
public interface CommonDao {

//    int deleteById(Long id);

    Long create(@Param("table") String table, @Param("model") Map<String, Object> model);

    Map<String, Object> getById(@Param("table") String table, @Param("id") Long id);

    int update(@Param("id") Long id, @Param("model") Map<String, Object> model);

    int updateColumn(@Param("id") Long id, @Param("table") String tableName, @Param("column") String columnName, @Param("value") Object columnValue);

    List<Map<String, Object>> simpleQuery(@Param("table") String table, @Param("select") String[] select, @Param("where") List<String> where, @Param("orderBy") String[] orderBy);

    List<Map<String, Object>> query(@Param("table") String table,
                                    @Param("select") String[] select,
                                    @Param("leftJoin") Map<String, String> leftJoin,
                                    @Param("where") List<String> where,
                                    @Param("groupBy") String[] groupBy,
                                    @Param("orderBy") String[] orderBy,
                                    @Param("start") Integer start,
                                    @Param("end") Integer end);

    List<Map<String, Object>> executeQuery(@Param("sql") String sql);
}
