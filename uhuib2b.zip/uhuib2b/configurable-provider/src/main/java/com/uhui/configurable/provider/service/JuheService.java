package com.uhui.configurable.provider.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.uhui.configurable.api.model.GasStation;
import com.uhui.configurable.api.model.GasStationPrice;
import com.uhui.configurable.api.service.DBRepository;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import com.uhui.configurable.provider.service.model.OilGradeMapping;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Fidel on 2017/3/31.
 */
@Service
public class JuheService implements ApplicationListener<ContextRefreshedEvent> {
    public static final String DEF_CHATSET = "UTF-8";
    public static final int DEF_CONN_TIMEOUT = 30000;
    public static final int DEF_READ_TIMEOUT = 30000;
    public static String userAgent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36";

    private static final Logger LOGGER = Logger.getLogger(JuheService.class);
    @Autowired
    private DBRepository dbRepository;
    //配置您申请的KEY
    private static final String APPKEY = "27d78309cd7c00b554d2b474bfcc18e2";
    private static final String REQUEST_METHOD = "POST";

    private void updateJuheGasPrice() {
        LOGGER.info("Update gas station price start.");
        int currentPage = 1;
        int allpage = -1;
        while (true) {
            JSONObject jsonObject = getGasPriceByCity("云南", null, currentPage + "");
            if (jsonObject.getIntValue("error_code") == 0) {
                JSONObject jsonResult = jsonObject.getJSONObject("result");
                JSONObject pageInfo = jsonResult.getJSONObject("pageinfo");
                currentPage = pageInfo.getIntValue("current");
                allpage = pageInfo.getIntValue("allpage");
                handleGasStation(jsonResult);
                if (currentPage >= allpage) {
                    break;
                }
                currentPage++;
            } else {
                //TODO 此处需加日志和报警
                LOGGER.error("Update gas station  price failed." + jsonObject.toJSONString());
            }
        }
        LOGGER.info("Update gas station price end.");
    }

    private void handleGasStation(JSONObject jsonResult) {
        JSONArray data = jsonResult.getJSONArray("data");
        for (int i = 0; i < data.size(); i++) {
            JSONObject oneData = data.getJSONObject(i);
            LOGGER.info(oneData.toJSONString());
            GasStation gasStation = buildGasStation(oneData);
            List<String> where = new ArrayList<>();
            where.add("source = '" + gasStation.getSource() + "'");
            where.add("source_id = " + gasStation.getSourceId());
            Long gasStationId;
            List<GasStation> list = dbRepository.simpleQuery(GasStation.class, where);
            if (list.size() < 1) {
                gasStationId = dbRepository.create(gasStation);
            } else {
                GasStation dbGasStation = list.get(0);
                gasStationId = dbGasStation.getId();
                boolean equal = checkGasStationEqual(gasStation, dbGasStation);
                if (!equal) {
                    dbRepository.update(gasStationId, gasStation);
                }
            }
            GasStationPrice gasStationPrice = buildGasStationPrice(oneData);
            gasStationPrice.setGasStationId(gasStationId);
            List<String> gasStationPriceWhere = new ArrayList<>();
            gasStationPriceWhere.add("gas_station_id = " + gasStationId);
            List<GasStationPrice> gasStationPriceList = dbRepository.simpleQuery(GasStationPrice.class, gasStationPriceWhere);
            if (gasStationPriceList.size() < 1) {
                dbRepository.create(gasStationPrice);
            } else {
                GasStationPrice dbGasStationPrice = gasStationPriceList.get(0);
                dbRepository.update(dbGasStationPrice.getId(), gasStationPrice);
            }
            dbRepository.create("gas_station_price_history", gasStationPrice);
        }
    }


    //1.按城市检索加油站
    public JSONObject getGasPriceByCity(String city, String keywords, String page) {
        if (city == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "City name should not be empty!");
        }
        String url = "http://apis.juhe.cn/oil/region";//请求接口地址
        Map params = new HashMap();//请求参数
        params.put("city", city);//城市名urlencode utf8;
        if (keywords != null) {
            params.put("keywords", keywords);//关键字urlencode utf8;
        }
        if (page != null) {
            params.put("page", page);//页数，默认1
        }
        params.put("format", "1");//格式选择1或2，默认1
        params.put("key", APPKEY);//应用APPKEY(应用详细页查询)

        return request(url, params);
    }

    //2.检索周边加油站
    public JSONObject getGasPriceByPosition(String lon, String lat, String searchRange, String page) {
        if (lon == null || lat == null) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Search position should not be empty!");
        }
        String url = "http://apis.juhe.cn/oil/local";//请求接口地址
        Map params = new HashMap();//请求参数
        params.put("lon", lon);//经纬(如:121.538123)
        params.put("lat", lat);//纬度(如：31.677132)
        if (searchRange != null) {
            params.put("r", searchRange);//搜索范围，单位M，默认3000，最大10000
        }
        if (page != null) {
            params.put("page", page);//页数,默认1
        }
        params.put("format", "1");//格式选择1或2，默认1
        params.put("key", APPKEY);//应用APPKEY(应用详细页查询)

        return request(url, params);
    }

    private JSONObject request(String url, Map params) {
        String result;
        try {
            result = net(url, params, REQUEST_METHOD);
            JSONObject object = JSON.parseObject(result);
            return object;
        } catch (Exception e) {
            throw new BusinessException(BusinessExceptionType.LOGIC, "Get gas price failed!", e);
        }
    }

    /**
     * @param strUrl 请求地址
     * @param params 请求参数
     * @param method 请求方法
     * @return 网络请求字符串
     * @throws Exception
     */
    private String net(String strUrl, Map params, String method) throws IOException {
        HttpURLConnection conn = null;
        BufferedReader reader = null;
        String rs = null;
        try {
            StringBuffer sb = new StringBuffer();
            if (method == null || method.equals("GET")) {
                strUrl = strUrl + "?" + urlencode(params);
            }
            URL url = new URL(strUrl);
            conn = (HttpURLConnection) url.openConnection();
            if (method == null || method.equals("GET")) {
                conn.setRequestMethod("GET");
            } else {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
            }
            conn.setRequestProperty("User-agent", userAgent);
            conn.setUseCaches(false);
            conn.setConnectTimeout(DEF_CONN_TIMEOUT);
            conn.setReadTimeout(DEF_READ_TIMEOUT);
            conn.setInstanceFollowRedirects(false);
            conn.connect();
            if (params != null && method.equals("POST")) {
                try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
                    out.writeBytes(urlencode(params));
                }
            }
            InputStream is = conn.getInputStream();
            reader = new BufferedReader(new InputStreamReader(is, DEF_CHATSET));
            String strRead = null;
            while ((strRead = reader.readLine()) != null) {
                sb.append(strRead);
            }
            rs = sb.toString();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new BusinessException(BusinessExceptionType.LOGIC, "Reader close failed.", e);
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        return rs;
    }

    //将map型转为请求参数型
    private String urlencode(Map<String, Object> data) throws UnsupportedEncodingException {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry i : data.entrySet()) {
            sb.append(i.getKey()).append("=").append(URLEncoder.encode(i.getValue() + "", "UTF-8")).append("&");
        }
        return sb.toString();
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        //TODO 有正式聚合数据帐号后放开
//        updateJuheGasPrice();
    }

    private GasStation buildGasStation(JSONObject oneData) {
        GasStation gasStation = new GasStation();
        gasStation.setSource("Juhe");
        gasStation.setSourceId(oneData.getLong("id"));
        gasStation.setName(oneData.getString("name"));
        gasStation.setArea(oneData.getString("area"));
        gasStation.setAreaName(oneData.getString("areaname"));
        gasStation.setAddress(oneData.getString("address"));
        gasStation.setBrandName(oneData.getString("brandname"));
        gasStation.setType(oneData.getString("type"));
        gasStation.setDiscount(oneData.getString("discount"));
        gasStation.setExhaust(oneData.getString("exhaust"));
        gasStation.setLon(oneData.getDoubleValue("lon"));
        gasStation.setLat(oneData.getDoubleValue("lat"));


        gasStation.setFwlsmc(oneData.getString("fwlsmc"));
        return gasStation;
    }

    private boolean checkGasStationEqual(GasStation currentGasStation, GasStation dbGasStation) {
        if (!currentGasStation.getName().equals(dbGasStation.getName())) {
            return false;
        }
        if (!currentGasStation.getArea().equals(dbGasStation.getArea())) {
            return false;
        }
        if (!currentGasStation.getAreaName().equals(dbGasStation.getAreaName())) {
            return false;
        }
        if (!currentGasStation.getAddress().equals(dbGasStation.getAddress())) {
            return false;
        }
        if (!currentGasStation.getBrandName().equals(dbGasStation.getBrandName())) {
            return false;
        }
        if (!currentGasStation.getType().equals(dbGasStation.getType())) {
            return false;
        }
        if (!currentGasStation.getDiscount().equals(dbGasStation.getDiscount())) {
            return false;
        }
        if (!currentGasStation.getExhaust().equals(dbGasStation.getExhaust())) {
            return false;
        }
        if (!currentGasStation.getLon().equals(dbGasStation.getLon())) {
            return false;
        }
        if (!currentGasStation.getLat().equals(dbGasStation.getLat())) {
            return false;
        }
        if (!currentGasStation.getFwlsmc().equals(dbGasStation.getFwlsmc())) {
            return false;
        }
        return true;
    }

    private GasStationPrice buildGasStationPrice(JSONObject oneData) {
        GasStationPrice gasStationPrice = new GasStationPrice();
        JSONObject gastprice = oneData.getJSONObject("gastprice");
        if (gastprice != null) {
            gasStationPrice.setGas92(gastprice.getFloat(OilGradeMapping.GAS92.juheGrade()));
            gasStationPrice.setGas95(gastprice.getFloat(OilGradeMapping.GAS95.juheGrade()));
            gasStationPrice.setDiesel0(gastprice.getFloat(OilGradeMapping.DIESEL0.juheGrade()));
            gasStationPrice.setDiesel10(gastprice.getFloat(OilGradeMapping.DIESEL10.juheGrade()));
            gasStationPrice.setDiesel20(gastprice.getFloat(OilGradeMapping.DIESEL20.juheGrade()));
            gasStationPrice.setDiesel35(gastprice.getFloat(OilGradeMapping.DIESEL35.juheGrade()));
            gasStationPrice.setGas89(gastprice.getFloat(OilGradeMapping.GAS89.juheGrade()));
            gasStationPrice.setGas90(gastprice.getFloat(OilGradeMapping.GAS90.juheGrade()));
            gasStationPrice.setGas93(gastprice.getFloat(OilGradeMapping.GAS93.juheGrade()));
            gasStationPrice.setGas97(gastprice.getFloat(OilGradeMapping.GAS97.juheGrade()));
            gasStationPrice.setCNG(gastprice.getFloat(OilGradeMapping.CNG.juheGrade()));
            gasStationPrice.setLNG(gastprice.getFloat(OilGradeMapping.LNG.juheGrade()));
        }
        JSONObject price = oneData.getJSONObject("price");
        if (price != null) {
            gasStationPrice.setE90(price.getFloat(OilGradeMapping.E90.juheGrade()));
            gasStationPrice.setE93(price.getFloat(OilGradeMapping.E93.juheGrade()));
            gasStationPrice.setE97(price.getFloat(OilGradeMapping.E97.juheGrade()));
            gasStationPrice.setE0(price.getFloat(OilGradeMapping.E0.juheGrade()));
        }
        return gasStationPrice;
    }

}
