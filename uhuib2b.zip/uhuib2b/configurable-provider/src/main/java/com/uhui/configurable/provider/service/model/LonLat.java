package com.uhui.configurable.provider.service.model;

import lombok.Data;

/**
 * Created by Fidel on 2017/3/31.
 */
@Data
public class LonLat {
    private Double lon;
    private Double lat;
}
