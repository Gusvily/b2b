//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.uhui.configurable.provider.utils;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;
import java.util.List;

public class XmlUtil {
    private XmlUtil() {
    }

    public static String document2String(Document document) {
        return document.asXML().replaceAll("\n", "");
    }

    public static Document string2Document(String xmlString) throws ParserConfigurationException, IOException, SAXException, DocumentException {
        return DocumentHelper.parseText(xmlString);
    }

    public static Document createDocument() {
        return createDocument("UTF-8");
    }

    public static Document createDocument(String encoding) {
        Document document = DocumentHelper.createDocument();
        document.setXMLEncoding(encoding);
        return document;
    }

    public static Element createElement(String nodeName) {
        return DocumentHelper.createElement(nodeName);
    }

    public static Element addElement(String nodeName, Element parentNode) {
        return parentNode.addElement(nodeName);
    }

    public static Element addElement(String nodeName, String nodeText, Element parentNode) {
        Element newElement = parentNode.addElement(nodeName);
        newElement.setText(nodeText);
        return newElement;
    }

    public static String readElement(Document document, String nodePath) throws XPathExpressionException {
        List nodes = DocumentHelper.selectNodes(nodePath, document);
        return nodes.size() == 1?((Element)nodes.get(0)).getText():null;
    }

    public static List queryElements(Document document, String nodePath) {
        return DocumentHelper.selectNodes(nodePath, document);
    }
}
