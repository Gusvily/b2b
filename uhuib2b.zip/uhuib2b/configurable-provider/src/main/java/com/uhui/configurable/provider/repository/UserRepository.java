package com.uhui.configurable.provider.repository;

import com.uhui.configurable.provider.repository.dao.CommonDao;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.workflow.utils.BeanUtils;
import com.uhui.configurable.provider.repository.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by Fidel on 2017/2/23.
 */
@Repository
public class UserRepository {

    @Autowired
    private UserDao userDao;

    @Autowired
    private CommonDao commonDao;

    public User getUserById(Long uid) {
        return new BeanUtils().mapToObject(commonDao.getById(User.TABLE_NAME,uid),User.class,BeanUtils.UNDERLINE);
    }

    public int create(User user){
        return userDao.create(user);
    }
}
