package com.uhui.configurable.provider.launcher;

import com.alibaba.dubbo.container.Main;

public class StandaloneLauncher {

    public static void main(String[] args) {
//        new Thread(new Runnable() {
//            public void run() {
//                try {
//                    Thread.sleep(20000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                ProtocolConfig.destroyAll();
//            }
//        }).start();
        Main.main(args);
    }

}
