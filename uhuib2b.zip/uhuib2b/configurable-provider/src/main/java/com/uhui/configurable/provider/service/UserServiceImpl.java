package com.uhui.configurable.provider.service;

import com.uhui.configurable.api.Permission.cache.Cache;
import com.uhui.configurable.api.Permission.cache.CacheConstant;
import com.uhui.configurable.api.Permission.cache.CacheManager;
import com.uhui.configurable.api.Permission.exception.AuthenticationFailedException;
import com.uhui.configurable.api.Permission.exception.LockedAccountException;
import com.uhui.configurable.api.Permission.exception.PasswordNotMatchException;
import com.uhui.configurable.api.Permission.exception.PasswordRetryLimitExceedException;
import com.uhui.configurable.api.Permission.exception.PermissionException;
import com.uhui.configurable.api.Permission.exception.UnknownAccountException;
import com.uhui.configurable.api.facade.UserService;
import com.uhui.configurable.api.model.BusinessStatusMapping;
import com.uhui.configurable.api.model.Company;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.service.DBRepository;
import com.uhui.configurable.api.service.RedisService;
import com.uhui.configurable.api.workflow.ProcessingResult;
import com.uhui.configurable.api.workflow.exception.BusinessException;
import com.uhui.configurable.api.workflow.exception.BusinessExceptionType;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.ws.rs.CookieParam;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Created by Fidel on 2017/5/8.
 */
public class UserServiceImpl implements UserService {

    public static final String SECURITY_CODE_MOBILE_PREFIX = "SECURITY_CODE_MOBILE_";
    public static final String SECURITY_CODE_EMAIL_PREFIX = "SECURITY_CODE_EMAIL_";
    @Autowired
    private PermissionProvider permissionProvider;
    @Autowired
    private RedisService redisService;
    @Autowired
    private MessageService messageService;
    @Autowired
    private MailService mailService;
    @Autowired
    private DBRepository dbRepository;
    @Autowired
    private CacheManager cacheManager;

    @Override
    public ProcessingResult requestSecurityCodeForMobile(Map<String, Object> params) {
        String mobilePhoneNumber = (String) params.get("mobilePhoneNumber");
        String securityCode = permissionProvider.generateSecurityCode();
        redisService.setex(SECURITY_CODE_MOBILE_PREFIX + mobilePhoneNumber, 600, securityCode);
        boolean result = messageService.sendSmsSecurityCode(mobilePhoneNumber, securityCode);
        return ProcessingResult.succeeded(result);
    }

    @Override
    public ProcessingResult requestSecurityCodeForEmail(Map<String, Object> params) {
        String emailAddress = (String) params.get("emailAddress");
        String securityCode = permissionProvider.generateSecurityCode();
        redisService.setex(SECURITY_CODE_EMAIL_PREFIX + emailAddress, 600, securityCode);
        boolean result = mailService.sendMailSecurityCode(emailAddress, securityCode);
        return ProcessingResult.succeeded(result);
    }

    @Override
    public ProcessingResult<Integer> registerUserAndCompany(Map<String, Object> params) {
        String name = (String) params.get("name");
        String pwd = (String) params.get("pwd");
        String email = (String) params.get("email");
        String emailSecurityCode = (String) params.get("emailSecurityCode");
        String mobilePhone = (String) params.get("mobilePhone");
        String mobilePhoneSecurityCode = (String) params.get("mobilePhoneSecurityCode");
        String companyLogoImageUrl = (String) params.get("companyLogoImageUrl");
        if (!checkMobileSecurityCode(mobilePhone, mobilePhoneSecurityCode)) {
            BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Mobile phone security code don't match.");
        }
        if (!checkEmailSecurityCode(email, emailSecurityCode)) {
            BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Email security code don't match.");
        }
        List<String> where = new ArrayList<>();
        where.add(String.format("(name = '%s' or email = '%s' or mobile_phone = '%s')", name, email, mobilePhone));
        List<User> checkResult = dbRepository.simpleQuery(User.class, where);
        if (checkResult.size() > 0) {
            BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Name or mobile or email of user is not available.");
        }
        List<String> companyWhere = new ArrayList<>();
        where.add(String.format("(name = '%s' or nickname = '%s')", name, name));
        List<Company> checkCompanyResult = dbRepository.simpleQuery(Company.class, companyWhere);
        if (checkCompanyResult.size() > 0) {
            BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "Name or nickname of company is not available.");
        }
        Company company = new Company();
        company.setName(name);
        company.setNickname(name);
        company.setDisabled(false);
        company.setStatus(BusinessStatusMapping.COMPANY_STATUS_CLOSED);
        company.setCertificateStatus(BusinessStatusMapping.COMPANY_CERTIFICATE_STATUS_NOT_CERT);
        company.setLogoImageUrl(companyLogoImageUrl);
        Long companyId = dbRepository.create(company);
        User user = new User();
        user.setName(name);
        user.resetPwd(pwd);
        user.setEmail(email);
        user.setEmailIsValidated(true);
        user.setMobilePhone(mobilePhone);
        user.setMobilePhoneIsValidated(true);
        user.setStatus(BusinessStatusMapping.USER_STATUS_ACTIVE);
        user.setIsCreator(true);
        user.setCompanyId(companyId);
        Long userId = dbRepository.create(user);
        user.setId(userId);
        return ProcessingResult.succeeded(user);
    }

    private boolean checkMobileSecurityCode(String mobilePhoneNumber, String mobilePhoneSecurityCode) {
        if (StringUtils.isEmpty(mobilePhoneSecurityCode)) {
            return false;
        }
        String realSecurityCode = redisService.get(SECURITY_CODE_MOBILE_PREFIX + mobilePhoneNumber);
        return mobilePhoneSecurityCode.equals(realSecurityCode);
    }

    private boolean checkEmailSecurityCode(String email, String emailSecurityCode) {
        if (StringUtils.isEmpty(emailSecurityCode)) {
            return false;
        }
        String realSecurityCode = redisService.get(SECURITY_CODE_EMAIL_PREFIX + email);
        return emailSecurityCode.equals(realSecurityCode);
    }

    @Override
    public ProcessingResult login(Map<String, Object> params) {
        ProcessingResult result = null;
        try {
            String username = (String) params.get("username");
            String password = (String) params.get("password");
            User user = dologin(username, password);
            Cache cache = cacheManager.getCache(CacheConstant.USER_CACHE_PREFIX_KEY + user.getId());
            cache.put(CacheConstant.CACHE_CURRENT_USER_KEY, user);
            List<String> permissions = doLoadPermission(user.getId());
            cache.put(CacheConstant.CACHE_CURRENT_USER_PERMISSIONS_KEY, permissions);
            result = ProcessingResult.succeeded(user);
        } catch (Throwable t) {
            result = ProcessingResult.failed(String.format(
                    "User login failed. %s %s", System.getProperty("line.separator"), ExceptionUtils.getStackTrace(t)));
        }
        return result;
    }

    @Override
    public ProcessingResult logout(String mobilePhoneNumber) {
        //TODO
        return ProcessingResult.succeeded("User logout successful.");
    }


    @Override
    public ProcessingResult<User> getCurrentUserInfo(@CookieParam("special_id") String specialId) {
//        return CHANGE_ME.getCurrentUserInfo();
        return null;
    }

    @Override
    public ProcessingResult<User> viewPurchaserByOrderId(@CookieParam("__token__") String token, String orderId) {
//        return CHANGE_ME.viewPurchaserByOrderId();
        return null;
    }

    @Override
    public ProcessingResult changeEmail(@CookieParam("__token__") String token, Map<String, Object> params) {
//        return CHANGE_ME.changeEmail();
        return null;
    }

    @Override
    public ProcessingResult changePassword(@CookieParam("__token__") String token, Map<String, Object> params) {
//        return CHANGE_ME.changePassword();
        return null;
    }

    @Override
    public ProcessingResult changeMobile(@CookieParam("__token__") String token, Map<String, Object> params) {
//        return CHANGE_ME.changeMobile();
        return null;
    }

    @Override
    public ProcessingResult registerUser(Map<String, Object> params) {
        User user = new User();
        user.setName((String) params.get("username"));
        user.setCompanyId(Long.parseLong((String) params.get("companyId")));
        user.resetPwd((String) params.get("password"));
        dbRepository.create(user);
        BusinessException.throwBusinessException(BusinessExceptionType.LOGIC, "test");
        return ProcessingResult.succeeded(user);
    }


    private List<String> doLoadPermission(Long userId) {
        List<String> result = new ArrayList();
        String sql = "select " +
                "concat(p.module,':',p.action,':',p.operation,':',p.operation_details) as permission " +
                "from user as u " +
                "inner join user_role ur on u.id = ur.user_id " +
                "inner join role r on ur.role_id = r.id " +
                "inner join role_privilege rp on r.id = rp.role_id " +
                "inner join privilege p on rp.privilege_id = p.id " +
                "where u.logic_deleted = 0 " +
                "and ur.logic_deleted = 0 " +
                "and r.logic_deleted = 0 " +
                "and rp.logic_deleted = 0 " +
                "and p.logic_deleted = 0 " +
                "and u.id = " + userId;
        List<Map<String, Object>> queryRes = dbRepository.executeQuery(sql);
        for (Map<String, Object> row : queryRes) {
            result.add((String) row.get("permission"));
        }
        return result;
    }

    private User dologin(String username, String password) throws PermissionException {
        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
            throw new UnknownAccountException();
        }
        //密码如果不在指定范围内 肯定错误
        if (password.length() < User.PASSWORD_MIN_LENGTH || password.length() > User.PASSWORD_MAX_LENGTH) {
            throw new PasswordNotMatchException();
        }

        User user = getUserByName(username);

        if (user == null) {
            user = getUserByEmail(username);
        }

        if (user == null) {
            user = getUserByMobilePhoneNumber(username);
        }

        if (user == null || Boolean.TRUE.equals(user.getLogicDeleted())) {
            throw new UnknownAccountException();
        }

        validate(user, password);

        if (User.USER_STATUS_INACTIVE.equals(user.getStatus())) {
            throw new LockedAccountException();
        }

        if (User.USER_STATUS_FROZEN.equals(user.getStatus())) {
            throw new LockedAccountException();
        }
        return user;
    }

    private User getUserByName(String username) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`name` = '%s'", username)));
    }

    private User getUserByEmail(String email) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`email` = '%s'", email)));
    }

    private User getUserByMobilePhoneNumber(String mobilePhoneNumber) {
        return dbRepository.getByOthers(User.class, Arrays.asList(String.format("`mobile_phone` = '%s'", mobilePhoneNumber)));
    }

    private void validate(User user, String password) throws AuthenticationFailedException {
        String username = user.getName();

        int retryCount = 0;


        Cache loginRecordCache = cacheManager.getCache(CacheConstant.PASSWORD_RETRY_CACHE_KEY);

        Object cacheRetryCount = loginRecordCache.get(username);
        if (cacheRetryCount != null) {
            retryCount = (Integer) cacheRetryCount;
            if (retryCount >= User.MAX_RETRY_COUNT) {
                throw new PasswordRetryLimitExceedException(User.MAX_RETRY_COUNT);
            }
        }

        if (!user.validatePassword(password)) {
            loginRecordCache.put(username, ++retryCount);
            throw new PasswordNotMatchException();
        } else {
            loginRecordCache.remove(username);
        }
    }

}
