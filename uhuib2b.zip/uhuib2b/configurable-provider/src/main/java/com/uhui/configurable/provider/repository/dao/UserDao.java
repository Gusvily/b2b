package com.uhui.configurable.provider.repository.dao;

import com.uhui.configurable.api.model.User;
import org.apache.ibatis.annotations.Param;

public interface UserDao {
    int deleteById(Long id);

    int create(User user);

    User getById(Long id);

    int update(@Param("id") Long id, @Param("user") User user);

}