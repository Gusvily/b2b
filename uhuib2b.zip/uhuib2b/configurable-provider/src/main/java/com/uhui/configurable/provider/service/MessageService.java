package com.uhui.configurable.provider.service;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * Created by Fidel on 2017/4/7.
 */
@Service
public class MessageService {

    public static final String ALI_DAYU_SMS_URL = "https://eco.taobao.com/router/rest";
    public static final String ALI_DAYU_APPKEY_TEST = "23741436";
    public static final String ALI_DAYU_SECRET_TEST = "152c4f83726cd58d72567bb3fa66e9c9";

    private static final Logger LOGGER = Logger.getLogger(MessageService.class);

    public boolean sendSmsMessage(String templateCode, String signName, String receiveNumber, String param) {
        //TODO 需要在公司执照下来后申请正式帐号去替换测试帐号
        TaobaoClient client = new DefaultTaobaoClient(ALI_DAYU_SMS_URL, ALI_DAYU_APPKEY_TEST, ALI_DAYU_SECRET_TEST);

        AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();

        req.setSmsType("normal");

        req.setSmsFreeSignName(signName);

        req.setSmsParamString(param);

        req.setRecNum(receiveNumber);

        req.setSmsTemplateCode(templateCode);

        AlibabaAliqinFcSmsNumSendResponse rsp = null;
        try {
            rsp = client.execute(req);
            String res = rsp.getBody();
            JSONObject resJson = JSON.parseObject(res);
            if (resJson.getJSONObject("alibaba_aliqin_fc_sms_num_send_response").getJSONObject("result").getString("err_code").equals("0")) {
                LOGGER.info("Send ali dayu SMS message successful.");
                return true;
            } else {
                LOGGER.error("Send ali dayu SMS message failed. Please check detail:" + res);
                return false;
            }
        } catch (Exception e) {
            LOGGER.error("Send ali dayu SMS message failed.", e);
            return false;
        }

    }

    public boolean sendSmsSecurityCode(String receiveNumber, String securityCode) {
        return sendSmsMessage("SMS_60300485", "焕雅石油", receiveNumber, String.format("{\"securityCode\":\"%s\"}", securityCode));
    }
}
