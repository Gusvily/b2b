package com.uhui.configurable.provider.service;

import com.alibaba.fastjson.JSON;
import com.uhui.configurable.api.extension.AuthenticationFilter;
import com.uhui.configurable.api.model.User;
import com.uhui.configurable.api.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * Created by Fidel on 2017/4/7.
 */
@Service
public class PermissionProvider {

    private static Random RANDOM = new Random();

    @Autowired
    private RedisService redisService;

    public String generateSecurityCode() {
        int result = RANDOM.nextInt(999999);
        while (result < 100000) {
            result = RANDOM.nextInt(999999);
        }
        return result + "";
    }

    public String resetToken(User user, String specialId) {
        return user.resetToken(specialId);
    }

    public void loadUserSession(User user, String userToken, String specialId) {
        if (userToken == null) {
            userToken = user.buildToken(specialId);
        }
        redisService.set(specialId, JSON.toJSONString(user));
        redisService.set(AuthenticationFilter.TOKEN_PREFIX + specialId, userToken);
        System.out.println("loaded user session." + user);
    }

    public static void main(String[] args) {
        for (int i = 0; i < 20; i++) {
            System.out.println(new PermissionProvider().generateSecurityCode());
        }
        SingleRedisService redisService = new SingleRedisService();
        redisService.setex("mykey", 100, "myvalue");
    }
}
