package com.uhui.configurable.provider.service;

import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Service;

/**
 * Created by Fidel on 2017/3/28.
 */
@Service
public class JsonProvider {

    public <T> T parseObject(String jsonString, Class<T> clz) {
        return JSON.parseObject(jsonString, clz);
    }

    public String toJSONString(Object object) {
        return JSON.toJSONString(object);
    }

}
