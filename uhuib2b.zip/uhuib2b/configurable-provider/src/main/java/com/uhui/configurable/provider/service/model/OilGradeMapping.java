package com.uhui.configurable.provider.service.model;

/**
 * Created by Fidel on 2017/4/1.
 */
public enum OilGradeMapping {

    GAS92("gas92", "92#"),
    GAS95("gas95", "95#"),
    DIESEL0("diesel0", "0#车柴"),
    DIESEL10("diesel10", "-10#车柴"),
    DIESEL20("diesel20", "-20#车柴"),
    DIESEL35("diesel35", "-35#车柴"),
    GAS89("gas89", "89#"),
    GAS90("gas90", "90#"),
    GAS93("gas93", "93#"),
    GAS97("gas97", "97#"),
    E90("E90", "E90"),
    E93("E93", "E93"),
    E97("E97", "E97"),
    E0("E0", "E0"),
    CNG("CNG", "CNG"),
    LNG("LNG", "LNG");

    private final String grade;
    private final String juheGrade;

    OilGradeMapping(String grade, String juheGrade) {
        this.grade = grade;
        this.juheGrade = juheGrade;
    }

    public String grade() {
        return grade;
    }

    public static String grade(String juheGrade) {
        for (OilGradeMapping oilGradeMapping : OilGradeMapping.values()) {
            if (oilGradeMapping.juheGrade.equals(juheGrade)) {
                return oilGradeMapping.grade;
            }
        }
        return null;
    }

    public String juheGrade() {
        return juheGrade;
    }

    public static String juheGrade(String grade) {
        for (OilGradeMapping oilGradeMapping : OilGradeMapping.values()) {
            if (oilGradeMapping.grade.equals(grade)) {
                return oilGradeMapping.juheGrade;
            }
        }
        return null;
    }
}
