package com.uhui.configurable.provider.service;

import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Service;

/**
 * Created by Fidel on 2017/3/24.
 */
@Service
public class JsonpProvider {

    public String jsonp(String callbackFunctionName, Object object) {
        String jsonString = JSON.toJSONString(object);
        return callbackFunctionName + "(" + jsonString + ")";
    }
}
