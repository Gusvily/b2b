CREATE DATABASE IF NOT EXISTS `uhuib2b`  DEFAULT CHARACTER SET utf8;
USE `uhuib2b`;

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `company_id` bigint(20) NOT NULL COMMENT '所属公司ID',
  `group_id` bigint(20) NULL COMMENT '发布部门编号',
  `name` varchar(45) NOT NULL,
  `pwd` char(32) NOT NULL,
  `email`  varchar(100) NOT NULL COMMENT '邮箱',
  `email_is_validated` tinyint(1) NOT NULL DEFAULT '0' COMMENT '邮箱是否验证: 0-否， 1-是',
  `mobile_phone` varchar(20) NOT NULL,
  `mobile_phone_is_validated` tinyint(1) NOT NULL DEFAULT '0' COMMENT '手机是否验证: 0-否， 1-是',
  `status` int(11) NOT NULL DEFAULT '100900' COMMENT '用户状态： 100900-未激活， 100901-正常， 100902-禁用',
  `salt` char(32) NOT NULL,
  `is_creator` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否为公司主帐号： 0-不是， 1-是',
  `image_url` VARCHAR(512) NULL COMMENT '用户头像',
  `image_url_file_name` VARCHAR(256) NULL COMMENT '用户头像文件名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  UNIQUE KEY `idx_email` (`email`),
  UNIQUE KEY `idx_mobile_phone` (`mobile_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `company_id` bigint(20) NOT NULL COMMENT '所属公司ID',
  `name` varchar(45) NOT NULL COMMENT '角色名',
  `description`  varchar(512) NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `privilege`;
CREATE TABLE `privilege` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `module` varchar(45) NOT NULL COMMENT '模块',
  `action` varchar(45) NULL COMMENT '动作',
  `operation` varchar(45) NULL COMMENT '操作',
  `operation_details` varchar(200) NULL COMMENT '操作描述',
  `description` varchar(512) NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `status` tinyint(4) NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `role_privilege`;
CREATE TABLE `role_privilege` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `privilege_id` bigint(20) NOT NULL COMMENT '用户ID',
  `status` tinyint(4) NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `approval_date` datetime DEFAULT NULL COMMENT '审核通过时间',
  `approval_user_id` bigint(20) DEFAULT NULL COMMENT '审核人ID',
  `name` varchar(45) NOT NULL COMMENT '公司全称',
  `nickname` varchar(45) NOT NULL COMMENT '公司简称',
  `type` int(10) DEFAULT NULL COMMENT '公司类型',
  `business_scope` varchar(128) DEFAULT NULL COMMENT '经营范围',
  `disabled` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态:0正常,1无效公司',
  `status` int(10) NOT NULL DEFAULT 100800 COMMENT '公司状态： 100800-开市，100801-闭市',
  `legal_person` varchar(45) DEFAULT NULL COMMENT '公司法人',
  `business_license_no` varchar(45) DEFAULT NULL COMMENT '统一社会信用代码',
  `registered_capital` DECIMAL(15,2) DEFAULT NULL COMMENT '注册资本',
  `operation_person` varchar(45) DEFAULT NULL COMMENT '运营者姓名',
  `opening_bank` varchar(128) DEFAULT NULL COMMENT '开户行',
  `account_name` varchar(128) DEFAULT NULL COMMENT '账户名称',
  `account` varchar(128) DEFAULT NULL COMMENT '账号',
  `address_city` bigint(20) DEFAULT NULL COMMENT '公司所在地',
  `address_detail` varchar(128) DEFAULT NULL COMMENT '公司所在地详细地址',
  `zip_code` varchar(45) DEFAULT NULL COMMENT '邮政编码',
  `certificate_status` int(10) NOT NULL DEFAULT '100850' COMMENT '公司审核状态： 100850-未审核，100851-审核中，100852-审核通过，100853-审核未通过',
  `logo_image_url` varchar(128) DEFAULT NULL COMMENT '公司logo存放地址',
  `business_license_image_url` varchar(128) DEFAULT NULL COMMENT '营业执照存放地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  UNIQUE KEY `idx_nickname` (`nickname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `company_id` bigint(20) NOT NULL COMMENT '发布公司编号',
  `group_id` bigint(20) NULL COMMENT '发布部门编号',
  `data_version` int(11) NOT NULL COMMENT '数据版本',
  `name` varchar(45) NOT NULL COMMENT '商品名称',
  `product_no` varchar(45) NOT NULL DEFAULT 'PDN'COMMENT '商品编码,以PDN开头',
  `title` varchar(500) DEFAULT NULL COMMENT '商品标题',
  `product_status` int(11) NOT NULL COMMENT '商品状态',
  `specification` text DEFAULT NULL COMMENT '规格类型',
  `publish_date` date NULL DEFAULT NULL COMMENT '发布时间',
  `publisher_id` bigint(20) NOT NULL COMMENT '发布人编号',
  `product_type` int(11) DEFAULT NULL COMMENT '商品类型',
  `image_url` varchar(200) DEFAULT NULL COMMENT '图片地址',
  `price` DECIMAL(15,2) DEFAULT NULL COMMENT '商品单价',
  `per_price` DECIMAL(15,2) DEFAULT NULL COMMENT '单件商品单价',
  `online_stock` INT(11) NULL COMMENT '上架库存',
  `sale_piece_num` INT(11) NOT NULL DEFAULT 0 COMMENT '已销售件数',
  `origin` bigint(20) DEFAULT NULL COMMENT '原产地',
  `sell_area` varchar(45) DEFAULT NULL COMMENT '销售区域',
  `storage_location` varchar(200) DEFAULT NULL COMMENT '货物存放地点',
  `lon` DOUBLE DEFAULT NULL COMMENT '经度',
  `lat` DOUBLE DEFAULT NULL COMMENT '纬度',
  `introduction` varchar(1000) DEFAULT NULL COMMENT '介绍',
  `delivery_type` int(11) DEFAULT NULL COMMENT '发货类型',
  `pay_type` int(11) DEFAULT NULL COMMENT '支付类型',
  `last_online_date` date NULL DEFAULT NULL COMMENT '最后一次上线的时间',
  `last_offline_date` date NULL DEFAULT NULL COMMENT '最后一次下线的时间',
  `source_type` smallint(6) NOT NULL DEFAULT '0' COMMENT '商品创建来源: (0: 由管理员创建, 1: 由系统自动生成)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品表';

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `data_version` int(11) NOT NULL COMMENT '数据版本',
  `creator_id` bigint(20) NOT NULL COMMENT '创建者编号',
  `order_no` varchar(45) NOT NULL COMMENT '订单编码,以ODN开头',
  `supplier_id` bigint(20) unsigned NOT NULL COMMENT '供应商编号',
  `purchaser_id` bigint(20) unsigned NOT NULL COMMENT '采购商编号',
  `product_specification` text DEFAULT NULL COMMENT '产品规格',
  `order_type` int(11) NOT NULL COMMENT '订单类型',
  `order_status` int(11) NOT NULL COMMENT '订单状态',
  `total_piece_number` int(11) DEFAULT NULL COMMENT '商品总件数',
  `total_order_amount` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额',
  `total_discount_amount` decimal(15,2) DEFAULT '0.00' COMMENT '折扣总金额、优惠总金额',
  `pay_type` int(11) DEFAULT NULL COMMENT '支付方式',
  `pay_status` int(11) DEFAULT NULL COMMENT '支付状态',
  `pay_date` datetime DEFAULT NULL,
  `order_date` datetime DEFAULT NULL COMMENT '下单时间',
  `change_request_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'order_change_request.id，如果为0则说明订单当前没有修改申请，如果不为0则说明订单当前有修改申请未处理',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';

DROP TABLE IF EXISTS `order_product`;
CREATE TABLE `order_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `order_id` bigint(20) unsigned NOT NULL COMMENT '订单ID',
  `product_id` bigint(20) unsigned NOT NULL COMMENT '商品ID',
  `piece_number` int(11) DEFAULT NULL COMMENT '件数',
  `price` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `price_discount_amount` decimal(15,2) DEFAULT '0.00' COMMENT '价格优惠金额',
  `product_amount` decimal(15,2) DEFAULT '0.00' COMMENT '商品总金额',
  `discount_amount` decimal(15,2) DEFAULT '0.00' COMMENT '优惠金额',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单商品信息';

DROP TABLE IF EXISTS `delivery_order`;
CREATE TABLE `delivery_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `order_id` bigint(20) NOT NULL COMMENT '订单编号',
  `delivery_type` int(11) NOT NULL COMMENT '出货类型',
  `delivery_status` int(11) NOT NULL COMMENT '出货状态',
  `delivery_target_id` bigint(20) NOT NULL COMMENT '出货目标',
  `delivery_number` int(11) NOT NULL COMMENT '出货数量',
  `delivery_date` datetime DEFAULT NULL COMMENT '出货时间',
  `vehicle` varchar(45) NOT NULL COMMENT '运载工具',
  `driver` varchar(45) NOT NULL COMMENT '驾驶员',
  `driver_mobile_phone` varchar(45) NOT NULL COMMENT '驾驶员联系方式',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='出货表';

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `order_id` bigint(20) NOT NULL COMMENT '订单编号',
  `payer_id` varchar(45) NOT NULL COMMENT '付款人编号',
  `payer_no` varchar(45) NOT NULL COMMENT '付款人账号',
  `payer_transaction_serial_number` varchar(45) DEFAULT NULL COMMENT '付款人银行交易流水号',
  `payee_id` varchar(45) NOT NULL COMMENT '收款人编号',
  `payee_no` varchar(45) NOT NULL COMMENT '收款人账号',
  `payee_transaction_serial_number` varchar(45) DEFAULT NULL COMMENT '收款人银行交易流水号',
  `amount` decimal(15,2) NOT NULL COMMENT '金额',
  `payment_no` varchar(45) DEFAULT NULL COMMENT '系统付款编号',
  `payment_method` int(11) NOT NULL COMMENT '付款方式',
  `payment_status` int(11) NOT NULL DEFAULT '1' COMMENT '付款状态',
  `comments` varchar(45) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT '付款表';

DROP TABLE IF EXISTS `order_payment`;
CREATE TABLE `order_payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT 0 COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `order_id` bigint(20) NOT NULL COMMENT '订单ID',
  `payment_id` bigint(20) NOT NULL COMMENT '付款表ID',
  `status` tinyint(4) NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*
DROP TABLE IF EXISTS `gas_station`;
CREATE TABLE `gas_station` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `create_date` DATETIME NOT NULL,
  `update_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `source` VARCHAR(20) NOT NULL COMMENT '数据采集来源',
  `source_id` BIGINT(20) NOT NULL COMMENT '数据采集来源ID',
  `name` VARCHAR(45) NOT NULL COMMENT '加油站名称',
  `area` VARCHAR(20) NOT NULL COMMENT '城市区域',
  `area_name` VARCHAR(30) NOT NULL COMMENT '城市区域名称',
  `address` VARCHAR(100) NOT NULL COMMENT '加油站地址',
  `brand_name` VARCHAR(20) NOT NULL COMMENT '运营商类型 ',
  `type` VARCHAR(20) NOT NULL COMMENT '加油站类型',
  `discount` VARCHAR(20) NOT NULL COMMENT '是否打折加油站',
  `exhaust` VARCHAR(10) NOT NULL COMMENT '尾气排放标准',
  `lon` DOUBLE NOT NULL COMMENT '经度',
  `lat` DOUBLE NOT NULL COMMENT '纬度',
  `fwlsmc` VARCHAR(100) NULL COMMENT '加油卡信息 ',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_source_and_source_id` (`source`(5) ASC,`source_id` ASC)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
COMMENT = '加油站信息表';

DROP TABLE IF EXISTS `gas_station_price`;
CREATE TABLE `gas_station_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `gas_station_id` bigint(20) NOT NULL COMMENT '加油站ID',
  `gas92` float DEFAULT NULL COMMENT '92号汽油',
  `gas95` float DEFAULT NULL COMMENT '95号汽油',
  `diesel0` float DEFAULT NULL COMMENT '0号柴油',
  `diesel10` float DEFAULT NULL COMMENT '-10号柴油',
  `diesel20` float DEFAULT NULL COMMENT '-20号柴油',
  `diesel35` float DEFAULT NULL COMMENT '-35号柴油',
  `gas89` float DEFAULT NULL COMMENT '89号汽油(旧标准)',
  `gas90` float DEFAULT NULL COMMENT '90号汽油(旧标准)',
  `gas93` float DEFAULT NULL COMMENT '93号汽油(旧标准)',
  `gas97` float DEFAULT NULL COMMENT '97号汽油(旧标准)',
  `E90` float DEFAULT NULL COMMENT '90号汽油(省控基准油价)',
  `E93` float DEFAULT NULL COMMENT '93号汽油(省控基准油价)',
  `E97` float DEFAULT NULL COMMENT '97号汽油(省控基准油价)',
  `E0` float DEFAULT NULL COMMENT '0号柴油(省控基准油价)',
  `CNG` float DEFAULT NULL COMMENT '压缩天燃气',
  `LNG` float DEFAULT NULL COMMENT '液化天燃气',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='加油站油价信息表';

DROP TABLE IF EXISTS `gas_station_price_history`;
CREATE TABLE `gas_station_price_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `gas_station_id` bigint(20) NOT NULL COMMENT '加油站ID',
  `gas92` float DEFAULT NULL COMMENT '92号汽油',
  `gas95` float DEFAULT NULL COMMENT '95号汽油',
  `diesel0` float DEFAULT NULL COMMENT '0号柴油',
  `diesel10` float DEFAULT NULL COMMENT '-10号柴油',
  `diesel20` float DEFAULT NULL COMMENT '-20号柴油',
  `diesel35` float DEFAULT NULL COMMENT '-35号柴油',
  `gas89` float DEFAULT NULL COMMENT '89号汽油(旧标准)',
  `gas90` float DEFAULT NULL COMMENT '90号汽油(旧标准)',
  `gas93` float DEFAULT NULL COMMENT '93号汽油(旧标准)',
  `gas97` float DEFAULT NULL COMMENT '97号汽油(旧标准)',
  `E90` float DEFAULT NULL COMMENT '90号汽油(省控基准油价)',
  `E93` float DEFAULT NULL COMMENT '93号汽油(省控基准油价)',
  `E97` float DEFAULT NULL COMMENT '97号汽油(省控基准油价)',
  `E0` float DEFAULT NULL COMMENT '0号柴油(省控基准油价)',
  `CNG` float DEFAULT NULL COMMENT '压缩天燃气',
  `LNG` float DEFAULT NULL COMMENT '液化天燃气',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='加油站油价历史表';
*/

/*
DROP TABLE IF EXISTS `gas_card`;
CREATE TABLE `gas_card` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logic_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '数据是否已被逻辑删除： 0-未删除， 1-已删除',
  `user_id` bigint(20) NOT NULL COMMENT '用户编号',
  `card_no` varchar(45) NOT NULL COMMENT '加油卡号',
  `card_type` int(11) NOT NULL COMMENT '加油卡类型',
  `comments` varchar(100) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT '加油卡表';

 TODO uhuiapp上线前需要修改为真实充值赠送的数据
INSERT INTO `product`(`create_date`,`name`,`title`,`product_status`,`specification`,`publish_date`,`publisher_id`,`product_type`,`delivery_type`,`pay_type`)
VALUES( now(),'油惠分期方案','油惠分期方案',100100,
'{"productSpecification": [
    {"mouth": 1,"amount": {"100":0,"300":0,"500":0,"800":5,"1000":5,"1500":10,"2000":10,"3000":20}},
    {"mouth": 2,"amount": {"100":5,"300":10,"500":10,"800":20,"1000":20,"1500":30,"2000":30,"3000":50}},
    {"mouth": 3,"amount": {"100":10,"300":30,"500":50,"800":100,"1000":150,"1500":200,"2000":300,"3000":400}},
    {"mouth": 4,"amount": {"100":15,"300":45,"500":75,"800":150,"1000":225,"1500":300,"2000":450,"3000":600}},
    {"mouth": 5,"amount": {"100":20,"300":60,"500":100,"800":200,"1000":300,"1500":400,"2000":600,"3000":800}},
    {"mouth": 6,"amount": {"100":25,"300":75,"500":125,"800":250,"1000":375,"1500":500,"2000":750,"3000":1000}},
    {"mouth": 7,"amount": {"100":30,"300":90,"500":150,"800":300,"1000":450,"1500":600,"2000":900,"3000":1200}},
    {"mouth": 8,"amount": {"100":35,"300":105,"500":175,"800":350,"1000":525,"1500":700,"2000":1050,"3000":1400}},
    {"mouth": 9,"amount": {"100":40,"300":120,"500":200,"800":400,"1000":600,"1500":800,"2000":1200,"3000":1600}},
    {"mouth": 10,"amount": {"100":45,"300":135,"500":225,"800":450,"1000":675,"1500":900,"2000":1350,"3000":1800}},
    {"mouth": 11,"amount": {"100":50,"300":150,"500":250,"800":500,"1000":750,"1500":1000,"2000":1500,"3000":2000}},
    {"mouth": 12,"amount": {"100":60,"300":180,"500":300,"800":600,"1000":900,"1500":1200,"2000":1800,"3000":2400}}
  ]}', now(),1,100110,100150,100200);
*/